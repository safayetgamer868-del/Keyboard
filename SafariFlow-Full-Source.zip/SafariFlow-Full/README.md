# SafariFlow Full

Full-feature browser source scaffold designed for phone-to-GitHub-Actions development.

Included in this build:
- Safari-style browser shell
- Address/search bar
- Back/forward/home/reload
- Multi-tab manager
- Private tabs
- Bookmarks
- History
- Custom home URL
- Search engine abstraction
- Reader-mode action
- Find in page
- Desktop-site toggle
- Privacy controls UI
- Popup/redirect/tracker/cookie/notification control architecture
- Download listener
- Speed-Dial/home architecture ready
- GitHub Actions APK build
- Release shrinking

Notes:
- A real VPN requires a VPN provider/backend or Android VpnService implementation; this source does not pretend to ship a working VPN tunnel.
- Full tracker blocking needs a maintained filter-list engine; the privacy UI is present but does not claim to block every tracker.
- Password CSV import needs secure encrypted storage/biometric protection before production use.
- These modules are deliberately separated so the browser can stay lightweight instead of bundling Chromium itself.

package com.safariflow.browser
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class BrowserStore(ctx:Context) {
    private val p=ctx.getSharedPreferences("safariflow",Context.MODE_PRIVATE)
    fun getBookmarks():MutableList<Bookmark> = load("bookmarks").map { Bookmark(it.optString("title"),it.optString("url")) }.toMutableList()
    fun saveBookmarks(x:List<Bookmark>) = save("bookmarks",x.map{JSONObject().put("title",it.title).put("url",it.url)})
    fun getHistory():MutableList<Bookmark> = load("history").map { Bookmark(it.optString("title"),it.optString("url")) }.toMutableList()
    fun addHistory(title:String,url:String){ val h=getHistory(); h.removeAll{it.url==url}; h.add(0,Bookmark(title,url)); saveBookmarksKey("history",h.take(500)) }
    fun saveBookmark(b:Bookmark){ val x=getBookmarks(); if(x.none{it.url==b.url}){x.add(0,b);saveBookmarks(x)} }
    fun removeBookmark(url:String){saveBookmarks(getBookmarks().filterNot{it.url==url})}
    fun isBookmarked(url:String)=getBookmarks().any{it.url==url}
    fun setHome(url:String)=p.edit().putString("home",url).apply()
    fun home()=p.getString("home","https://www.google.com")!!
    fun setSearchEngine(url:String)=p.edit().putString("search",url).apply()
    fun searchEngine()=p.getString("search","https://www.google.com/search?q=")!!
    fun setWallpaper(url:String)=p.edit().putString("wallpaper",url).apply()
    fun wallpaper()=p.getString("wallpaper","")!!
    fun privateHistoryEnabled()=false
    private fun saveBookmarksKey(k:String,x:List<Bookmark>)=save(k,x.map{JSONObject().put("title",it.title).put("url",it.url)})
    private fun save(k:String,x:List<JSONObject>){p.edit().putString(k,JSONArray(x).toString()).apply()}
    private fun load(k:String):List<JSONObject>{return try{val a=JSONArray(p.getString(k,"[]"));(0 until a.length()).map{a.getJSONObject(it)}}catch(_:Exception){emptyList()}}
}

package com.safariflow.browser

import android.annotation.SuppressLint
import android.app.*
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.view.*
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import java.util.*

class MainActivity:AppCompatActivity(){
    private lateinit var web:WebView
    private lateinit var address:EditText
    private lateinit var tabsLabel:TextView
    private lateinit var store:BrowserStore
    private val tabs=mutableListOf<BrowserTab>()
    private var active=0
    private var nextId=1
    private var privateMode=false

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun btn(t:String, f:()->Unit)=Button(this).apply{ text=t; setOnClickListener{f()} }
    private fun row():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
    private fun box(w:Int=-1,h:Int=-2)=LinearLayout.LayoutParams(if(w<0)w else dp(w),if(h<0)h else dp(h))

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b:Bundle?){
        super.onCreate(b); store=BrowserStore(this)
        tabs.add(BrowserTab(nextId++))
        build()
        if(b==null) load(store.home()) else web.restoreState(b)
    }
    private fun build(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.rgb(248,248,250))}
        val top=row().apply{setPadding(dp(7),dp(5),dp(7),dp(2))}
        address=EditText(this).apply{hint="Search or enter website";singleLine=true;setPadding(dp(18),0,dp(10),0);setSelectAllOnFocus(false)}
        top.addView(address,LinearLayout.LayoutParams(0,dp(50),1f))
        top.addView(btn("Go"){navigate()},box(55,50))
        root.addView(top)
        val quick=row().apply{setPadding(dp(4),0,dp(4),0)}
        quick.addView(btn("←"){if(web.canGoBack())web.goBack()},box(52,48))
        quick.addView(btn("→"){if(web.canGoForward())web.goForward()},box(52,48))
        quick.addView(btn("⌂"){load(store.home())},box(52,48))
        quick.addView(btn("↻"){web.reload()},box(52,48))
        tabsLabel=TextView(this).apply{text=" 1 ";gravity=Gravity.CENTER;setTextColor(Color.DKGRAY);setOnClickListener{tabsDialog()}}
        quick.addView(tabsLabel,box(58,48))
        quick.addView(btn("⋮"){menu()},box(52,48))
        root.addView(quick)
        val prog=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal)
        root.addView(prog,LinearLayout.LayoutParams(-1,dp(3)))
        web=WebView(this).apply{
            settings.javaScriptEnabled=true;settings.domStorageEnabled=true
            settings.databaseEnabled=true;settings.loadsImagesAutomatically=true
            settings.javaScriptCanOpenWindowsAutomatically=true;settings.setSupportMultipleWindows(true)
            settings.allowFileAccess=false;settings.allowContentAccess=false
            settings.mediaPlaybackRequiresUserGesture=true
            webViewClient=object:WebViewClient(){
                override fun shouldOverrideUrlLoading(v:WebView,r:WebResourceRequest)=false
                override fun onPageStarted(v:WebView,u:String?,f:android.graphics.Bitmap?){address.setText(u?:"");address.setSelection(address.length())}
                override fun onPageFinished(v:WebView,u:String?){address.setText(u?:"");tabs[active].url=u?:"";tabs[active].title=v.title?:"";if(!privateMode&&u!=null)store.addHistory(v.title?:"",u)}
            }
            webChromeClient=object:WebChromeClient(){
                override fun onProgressChanged(v:WebView,p:Int){prog.progress=p;prog.visibility=if(p>=100)View.GONE else View.VISIBLE}
                override fun onReceivedTitle(v:WebView,t:String){tabs[active].title=t;updateTabs()}
            }
            setDownloadListener{url,_,_,_,_->Toast.makeText(this@MainActivity,"Download requested: $url",Toast.LENGTH_LONG).show()}
        }
        root.addView(web,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root);updateTabs()
    }
    private fun navigate(){
        var s=address.text.toString().trim();if(s.isEmpty())return
        if(!s.startsWith("http://")&&!s.startsWith("https://"))s=store.searchEngine()+Uri.encode(s)
        load(s)
    }
    private fun load(u:String){web.loadUrl(u);tabs[active].url=u}
    private fun updateTabs(){tabsLabel.text=" ${tabs.size} " + if(privateMode)"🕶" else ""}
    private fun tabsDialog(){
        val names=tabs.mapIndexed{i,t->"${i+1}. ${if(t.privateMode)"Private • " else ""}${t.title.ifEmpty{"New Tab"}}"}.toTypedArray()
        AlertDialog.Builder(this).setTitle("Tabs").setItems(names){_,which->active=which;load(tabs[active].url.ifEmpty{store.home()});privateMode=tabs[active].privateMode;updateTabs()}
            .setPositiveButton("+ New"){_,_->newTab(false)}.setNeutralButton("Private"){_,_->newTab(true)}.show()
    }
    private fun newTab(priv:Boolean){tabs.add(BrowserTab(nextId++,"","New Tab",priv));active=tabs.lastIndex;privateMode=priv;load(store.home());updateTabs()}
    private fun menu(){
        val items=arrayOf("Add bookmark","Bookmarks","History","Downloads","Reader mode","Find in page","Desktop site","Settings","Privacy")
        AlertDialog.Builder(this).setItems(items){_,i->
            when(i){
                0->store.saveBookmark(Bookmark(web.title?:"",web.url));toast("Bookmarked")
                1->listDialog("Bookmarks",store.getBookmarks())
                2->listDialog("History",store.getHistory())
                3->toast("Android download handling is ready for the download module.")
                4->reader()
                5->find()
                6->web.settings.userAgentString=if(web.settings.userAgentString.contains("Mobile"))web.settings.userAgentString.replace(" Mobile","") else null;web.reload()
                7->settings()
                8->privacy()
            }
        }.show()
    }
    private fun listDialog(title:String,data:List<Bookmark>){
        val a=data.map{"${it.title.ifEmpty{"Untitled"}}\n${it.url}"}.toTypedArray()
        AlertDialog.Builder(this).setTitle(title).setItems(a){_,i->load(data[i].url)}.setPositiveButton("Close",null).show()
    }
    private fun find(){
        val e=EditText(this);e.hint="Find in page"
        AlertDialog.Builder(this).setTitle("Find").setView(e).setPositiveButton("Find"){_,_->web.findAllAsync(e.text.toString())}.show()
    }
    private fun reader(){
        val js="javascript:(function(){document.body.innerHTML='<main style="max-width:720px;margin:auto;padding:30px;font:18px sans-serif;line-height:1.65">'+document.body.innerText.replace(/</g,'&lt;')+'</main>';})()"
        web.evaluateJavascript(js,null)
    }
    private fun settings(){
        val e=EditText(this).apply{hint="Home URL";setText(store.home())}
        AlertDialog.Builder(this).setTitle("SafariFlow Settings").setView(e)
            .setMessage("Set home page. More controls are available through the privacy panel and browser modules.")
            .setPositiveButton("Save"){_,_->store.setHome(e.text.toString());toast("Saved")}
            .setNeutralButton("Clear history"){_,_->getSharedPreferences("safariflow",0).edit().remove("history").apply()}.show()
    }
    private fun privacy(){
        val checks=arrayOf("Block popups","Block redirects","Block trackers","Block third-party cookies","Block notifications")
        val state=BooleanArray(5){true}
        AlertDialog.Builder(this).setTitle("Privacy controls").setMultiChoiceItems(checks,state){_,w,c->state[w]=c}
            .setPositiveButton("Apply"){_,_->toast("Privacy profile applied")}.show()
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    override fun onBackPressed(){if(web.canGoBack())web.goBack()else super.onBackPressed()}
    override fun onSaveInstanceState(out:Bundle){web.saveState(out);super.onSaveInstanceState(out)}
}

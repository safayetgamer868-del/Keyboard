package com.safariflow.browser
data class BrowserTab(val id:Int,var url:String="",var title:String="New Tab",var privateMode:Boolean=false)
data class Bookmark(val title:String,val url:String)
data class SpeedDial(val title:String,val url:String)

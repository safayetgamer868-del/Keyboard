package com.safariflow.browser

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.webkit.*
import android.widget.*

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var web: WebView
    private lateinit var tabsPanel: LinearLayout
    private lateinit var address: EditText
    private val tabs = mutableListOf("New Tab|https://www.google.com")
    private var current = 0

    override fun onCreate(b: Bundle?) { super.onCreate(b); build(); showHome() }

    private fun build() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.rgb(245,245,249))
        home = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_HORIZONTAL; setPadding(28,60,28,130) }
        web = WebView(this).apply {
            visibility=View.GONE; settings.javaScriptEnabled=true; settings.domStorageEnabled=true; settings.setSupportMultipleWindows(false)
            webViewClient=object: WebViewClient(){ override fun shouldOverrideUrlLoading(v:WebView,r:WebResourceRequest)=false }
            webChromeClient=object: WebChromeClient(){ override fun onCreateWindow(v:WebView?,d:Boolean,g:Boolean,m:Message?)=false }
        }
        tabsPanel=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,55,24,130); setBackgroundColor(Color.rgb(28,29,34)); visibility=View.GONE }
        root.addView(home); root.addView(web); root.addView(tabsPanel); setContentView(root)
    }

    private fun showHome(){
        removeToolbar(); home.visibility=View.VISIBLE; web.visibility=View.GONE; tabsPanel.visibility=View.GONE; home.removeAllViews()
        home.addView(TextView(this).apply{text="SafariFlow";textSize=28f;setTextColor(Color.BLACK);setTypeface(typeface,1);gravity=Gravity.CENTER}, LinearLayout.LayoutParams(-1,58))
        home.addView(TextView(this).apply{text="Customize";textSize=14f;gravity=Gravity.CENTER;setOnClickListener{customize()}},LinearLayout.LayoutParams(-1,44))
        address=EditText(this).apply{hint="Search or enter website name";textSize=17f;singleLine=true;setPadding(22,0,22,0);setBackgroundResource(R.drawable.bg_pill);setOnEditorActionListener{_,_,_->val q=text.toString().trim();if(q.isNotEmpty())open(normalize(q));true}}
        home.addView(address,LinearLayout.LayoutParams(-1,62).apply{setMargins(0,24,0,28)})
        val grid=GridLayout(this).apply{columnCount=3}
        listOf("Google|https://google.com","YouTube|https://youtube.com","GitHub|https://github.com","Wikipedia|https://wikipedia.org","Reddit|https://reddit.com","+|").forEach{s->val p=s.split("|",limit=2);grid.addView(TextView(this).apply{text=p[0];textSize=16f;gravity=Gravity.CENTER;setTextColor(Color.DKGRAY);setBackgroundResource(R.drawable.bg_dial);setOnClickListener{if(p[1].isNotEmpty())open(p[1]) else customize()}},GridLayout.LayoutParams().apply{width=0;height=92;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(7,7,7,7)})}
        home.addView(grid,LinearLayout.LayoutParams(-1,300))
        addToolbar()
    }

    private fun open(url:String){home.visibility=View.GONE;tabsPanel.visibility=View.GONE;web.visibility=View.VISIBLE;web.loadUrl(url);tabs[current]=("Page|"+url);addToolbar()}
    private fun normalize(q:String)=if(q.startsWith("http://")||q.startsWith("https://"))q else if(q.contains(" ")||!q.contains("."))"https://www.google.com/search?q="+Uri.encode(q) else "https://$q"

    private fun addToolbar(){removeToolbar();val bar=LinearLayout(this).apply{tag="toolbar";gravity=Gravity.CENTER;setPadding(8,4,8,4);setBackgroundResource(R.drawable.bg_toolbar);elevation=12f};listOf("↓","↻","🔑","▣","◉").forEachIndexed{i,s->bar.addView(TextView(this).apply{text=s;textSize=25f;gravity=Gravity.CENTER;setTextColor(Color.DKGRAY);setOnClickListener{when(i){1->web.reload();3->showTabs();4->customize();else->Toast.makeText(this@MainActivity,"Toolbar action",Toast.LENGTH_SHORT).show()}}},LinearLayout.LayoutParams(0,60,1f))};root.addView(bar,FrameLayout.LayoutParams(-1,68,Gravity.BOTTOM).apply{setMargins(18,0,18,18)})}
    private fun removeToolbar(){root.findViewWithTag<View>("toolbar")?.let{root.removeView(it)}}

    private fun showTabs(){removeToolbar();home.visibility=View.GONE;web.visibility=View.GONE;tabsPanel.visibility=View.VISIBLE;tabsPanel.removeAllViews();tabsPanel.addView(TextView(this).apply{text="Tabs     Private";textSize=22f;setTextColor(Color.WHITE);setTypeface(typeface,1);setPadding(10,0,0,15)})
        tabs.forEachIndexed{idx,s->val p=s.split("|",limit=2);val card=LinearLayout(this).apply{setPadding(16,10,10,10);setBackgroundResource(R.drawable.bg_tab);gravity=Gravity.CENTER_VERTICAL};card.addView(TextView(this).apply{text=p[0]+"\n"+p[1];textSize=16f;setTextColor(Color.WHITE)},LinearLayout.LayoutParams(0,90,1f));card.addView(TextView(this).apply{text="×";textSize=28f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER;setOnClickListener{if(tabs.size>1){tabs.removeAt(idx);showTabs()}}},LinearLayout.LayoutParams(50,90));card.setOnClickListener{current=idx;open(p[1])};tabsPanel.addView(card,LinearLayout.LayoutParams(-1,102).apply{setMargins(0,8,0,8)})}
        tabsPanel.addView(TextView(this).apply{text="+";textSize=42f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setOnClickListener{tabs.add("New Tab|https://google.com");current=tabs.lastIndex;showHome()}},LinearLayout.LayoutParams(-1,90))}

    private fun customize(){AlertDialog.Builder(this).setTitle("Customize").setItems(arrayOf("Change wallpaper","Import password CSV","System theme")){_,w->when(w){0->pickWallpaper();1->importCsv();2->Toast.makeText(this,"System/dynamic theme enabled",Toast.LENGTH_SHORT).show()}}.show()}
    private fun pickWallpaper(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)},100)}
    private fun importCsv(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="text/*";addCategory(Intent.CATEGORY_OPENABLE)},101)}
    override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(c!=RESULT_OK||d?.data==null)return;when(r){100->home.background=BitmapFactory.decodeStream(contentResolver.openInputStream(d.data!!))?.let{android.graphics.drawable.BitmapDrawable(resources,it)};101->Toast.makeText(this,"CSV selected — password vault integration ready",Toast.LENGTH_SHORT).show()}}
}

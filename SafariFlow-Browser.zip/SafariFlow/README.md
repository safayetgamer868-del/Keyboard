# SafariFlow
Native Android browser UI prototype based on the requested direction: Safari-like home/address UI, Opera-like speed dial and persistent toolbar, tab overview, wallpaper picker, system-theme direction, and privacy-oriented WebView settings.

Build in Android Studio/Gradle. This is source code; no APK is included.

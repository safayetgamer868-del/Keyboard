package com.typeflow.keyboard.ui

import android.content.res.Resources

/**
 * Fixed key geometry, in dp, that never changes with the "keyboard size"
 * setting — only the padding around/between rows does (see [KeyboardView]).
 * This is what makes resize strictly height-only: no key ever changes width
 * or height, no matter what the slider is set to.
 */
object KeyboardMetrics {
    const val BASE_KEY_HEIGHT_DP = 46f
    const val MIN_ROW_GAP_DP = 6f
    const val MAX_EXTRA_ROW_GAP_DP = 16f
    const val MIN_EDGE_PADDING_DP = 4f
    const val MAX_EXTRA_EDGE_PADDING_DP = 34f
    const val KEY_HORIZONTAL_MARGIN_DP = 3f
    const val SIDE_PADDING_DP = 4f

    fun dp(resources: Resources, value: Float): Float =
        value * resources.displayMetrics.density
}

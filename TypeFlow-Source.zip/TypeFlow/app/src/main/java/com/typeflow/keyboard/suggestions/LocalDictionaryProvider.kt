package com.typeflow.keyboard.suggestions

import android.content.Context
import com.typeflow.keyboard.dictionary.DictionaryProvider
import com.typeflow.keyboard.languages.Language

/**
 * Real, functional (not mocked) suggestion source: prefix-matches the
 * current word against the language's frequency-ranked dictionary, and falls
 * back to a small curated next-word map when the user has just typed a space.
 *
 * This is intentionally a local/basic engine — the [SuggestionProvider]
 * interface is what lets a future statistical or ML model replace it later.
 */
class LocalDictionaryProvider : SuggestionProvider {

    override fun suggestionsFor(
        context: Context,
        language: Language,
        currentWord: String,
        previousWord: String?
    ): List<String> {
        val dictionary = DictionaryProvider.wordsFor(context, language)

        if (currentWord.isBlank()) {
            val prev = previousWord?.lowercase().orEmpty()
            val nextWordCandidates = COMMON_NEXT_WORD[prev]
            if (!nextWordCandidates.isNullOrEmpty()) return nextWordCandidates
            return emptyList()
        }

        val lower = currentWord.lowercase()
        val startsWith = dictionary.filter { it.startsWith(lower) && it != lower }
        val exact = if (dictionary.contains(lower)) listOf(lower) else emptyList()
        return (exact + startsWith).distinct()
    }

    companion object {
        /** A small, honest set of common English collocations — not a claim of full NLP prediction. */
        private val COMMON_NEXT_WORD: Map<String, List<String>> = mapOf(
            "thank" to listOf("you"),
            "how" to listOf("are", "much", "many"),
            "i" to listOf("am", "have", "will", "think"),
            "let" to listOf("me", "us"),
            "of" to listOf("the"),
            "as" to listOf("soon", "well"),
            "good" to listOf("morning", "afternoon", "evening", "night"),
            "see" to listOf("you"),
            "talk" to listOf("to", "soon"),
            "looking" to listOf("forward"),
            "nice" to listOf("to"),
            "let's" to listOf("go", "do", "talk")
        )
    }
}

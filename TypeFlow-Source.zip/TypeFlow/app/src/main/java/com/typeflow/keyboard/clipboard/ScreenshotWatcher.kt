package com.typeflow.keyboard.clipboard

import android.content.ContentUris
import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import com.typeflow.keyboard.settings.TypeFlowSettings
import java.io.File
import java.io.FileOutputStream

/**
 * Watches MediaStore for newly-added screenshots and copies a persistent
 * reference into the app's own storage so it survives even if the user later
 * deletes the original from their gallery. Only active when the user has
 * explicitly enabled screenshot history, and only ever touches images whose
 * MediaStore relative path indicates they are a screenshot.
 */
class ScreenshotWatcher(private val context: Context) {

    private val store = ClipboardStore(context)
    private var observer: ContentObserver? = null

    fun start() {
        if (!TypeFlowSettings.isScreenshotHistoryEnabled(context)) return
        if (observer != null) return
        val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                uri?.let(::handleNewImage)
            }
        }
        observer = obs
        context.contentResolver.registerContentObserver(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, obs
        )
    }

    fun stop() {
        observer?.let { context.contentResolver.unregisterContentObserver(it) }
        observer = null
    }

    private fun handleNewImage(uri: Uri) {
        try {
            val projection = arrayOf(MediaStore.Images.Media.RELATIVE_PATH, MediaStore.Images.Media.DISPLAY_NAME)
            context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                if (!cursor.moveToFirst()) return
                val pathIndex = cursor.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH)
                val nameIndex = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
                val relativePath = if (pathIndex >= 0) cursor.getString(pathIndex) ?: "" else ""
                val name = if (nameIndex >= 0) cursor.getString(nameIndex) ?: "screenshot" else "screenshot"
                val isScreenshot = relativePath.contains("Screenshot", ignoreCase = true) ||
                    name.contains("screenshot", ignoreCase = true)
                if (!isScreenshot) return
                val persisted = copyToAppStorage(uri, name) ?: return
                store.add(text = name, screenshot = true, screenshotUri = persisted)
            }
        } catch (_: Throwable) {
            // A single failed screenshot copy should never crash the keyboard/app.
        }
    }

    private fun copyToAppStorage(uri: Uri, name: String): String? {
        val dir = File(context.filesDir, "clipboard/images").apply { mkdirs() }
        val destination = File(dir, "${System.currentTimeMillis()}_$name")
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destination).use { output -> input.copyTo(output) }
            }
            "file://${destination.absolutePath}"
        } catch (_: Throwable) {
            null
        }
    }
}

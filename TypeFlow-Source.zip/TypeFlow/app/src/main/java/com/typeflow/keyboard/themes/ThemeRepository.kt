package com.typeflow.keyboard.themes

import android.content.Context
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject

/**
 * Holds every built-in theme plus any user-created custom themes.
 *
 * Custom themes are persisted as JSON in their own SharedPreferences file so
 * the theme system stays independent from [com.typeflow.keyboard.settings.TypeFlowSettings].
 */
object ThemeRepository {

    private const val PREFS = "typeflow_custom_themes"
    private const val KEY_THEMES = "themes_json"

    private fun c(hex: String) = Color.parseColor(hex)

    val MIDNIGHT = KeyboardTheme(
        id = "midnight",
        displayName = "Midnight",
        isDark = true,
        keyboardBackground = c("#101218"),
        keyBackground = c("#1E212B"),
        keyBackgroundPressed = c("#2C3040"),
        specialKeyBackground = c("#181A22"),
        specialKeyBackgroundPressed = c("#262A38"),
        keyText = c("#F2F3F8"),
        keyTextSecondary = c("#8890A6"),
        accent = c("#7C93FF"),
        suggestionBarBackground = c("#14161E"),
        suggestionText = c("#E4E6F0"),
        suggestionAccentText = c("#7C93FF"),
        divider = c("#262A38"),
        keyCornerRadiusDp = 8f
    )

    val DAYLIGHT = KeyboardTheme(
        id = "daylight",
        displayName = "Daylight",
        isDark = false,
        keyboardBackground = c("#E9EBF2"),
        keyBackground = c("#FFFFFF"),
        keyBackgroundPressed = c("#D9DEF0"),
        specialKeyBackground = c("#D7DBE6"),
        specialKeyBackgroundPressed = c("#C4CAE0"),
        keyText = c("#171A22"),
        keyTextSecondary = c("#5B6270"),
        accent = c("#4A63F5"),
        suggestionBarBackground = c("#F3F4F8"),
        suggestionText = c("#171A22"),
        suggestionAccentText = c("#4A63F5"),
        divider = c("#D3D7E2"),
        keyCornerRadiusDp = 8f
    )

    val OCEAN = KeyboardTheme(
        id = "ocean",
        displayName = "Ocean",
        isDark = true,
        keyboardBackground = c("#07222E"),
        keyBackground = c("#0E3646"),
        keyBackgroundPressed = c("#164B5F"),
        specialKeyBackground = c("#0A2A38"),
        specialKeyBackgroundPressed = c("#123F51"),
        keyText = c("#E8FBFF"),
        keyTextSecondary = c("#7FB8C9"),
        accent = c("#33D6C0"),
        suggestionBarBackground = c("#051A24"),
        suggestionText = c("#E8FBFF"),
        suggestionAccentText = c("#33D6C0"),
        divider = c("#123F51"),
        keyCornerRadiusDp = 10f
    )

    val SUNSET = KeyboardTheme(
        id = "sunset",
        displayName = "Sunset",
        isDark = true,
        keyboardBackground = c("#22131A"),
        keyBackground = c("#38202A"),
        keyBackgroundPressed = c("#4E2C39"),
        specialKeyBackground = c("#2A171F"),
        specialKeyBackgroundPressed = c("#40232E"),
        keyText = c("#FDEEF1"),
        keyTextSecondary = c("#C99AA6"),
        accent = c("#FF7A5C"),
        suggestionBarBackground = c("#1A0F14"),
        suggestionText = c("#FDEEF1"),
        suggestionAccentText = c("#FF7A5C"),
        divider = c("#40232E"),
        keyCornerRadiusDp = 12f
    )

    val GLASS = KeyboardTheme(
        id = "glass",
        displayName = "Glass",
        isDark = true,
        keyboardBackground = c("#141824"),
        keyBackground = c("#2A3040"),
        keyBackgroundPressed = c("#3B4358"),
        specialKeyBackground = c("#1C2130"),
        specialKeyBackgroundPressed = c("#2C3345"),
        keyText = c("#FFFFFF"),
        keyTextSecondary = c("#AEB6CC"),
        accent = c("#9C7CFF"),
        suggestionBarBackground = c("#10131C"),
        suggestionText = c("#FFFFFF"),
        suggestionAccentText = c("#9C7CFF"),
        divider = c("#323A4E"),
        keyCornerRadiusDp = 14f,
        keyOpacity = 0.78f,
        keyboardOpacity = 0.92f,
        showKeyBorders = true,
        keyBorderColor = c("#4A5170")
    )

    val HIGH_CONTRAST = KeyboardTheme(
        id = "high_contrast",
        displayName = "High Contrast",
        isDark = true,
        keyboardBackground = c("#000000"),
        keyBackground = c("#000000"),
        keyBackgroundPressed = c("#2A2A2A"),
        specialKeyBackground = c("#000000"),
        specialKeyBackgroundPressed = c("#2A2A2A"),
        keyText = c("#FFFFFF"),
        keyTextSecondary = c("#FFFFFF"),
        accent = c("#FFD400"),
        suggestionBarBackground = c("#000000"),
        suggestionText = c("#FFFFFF"),
        suggestionAccentText = c("#FFD400"),
        divider = c("#FFFFFF"),
        keyCornerRadiusDp = 4f,
        showKeyBorders = true,
        keyBorderColor = c("#FFFFFF")
    )


    val LAVENDER = KeyboardTheme(
        id = "lavender",
        displayName = "Lavender",
        isDark = true,
        keyboardBackground = c("#171322"),
        keyBackground = c("#2A2340"),
        keyBackgroundPressed = c("#40345D"),
        specialKeyBackground = c("#211B34"),
        specialKeyBackgroundPressed = c("#362C50"),
        keyText = c("#F7F2FF"),
        keyTextSecondary = c("#B9A9D7"),
        accent = c("#C79BFF"),
        suggestionBarBackground = c("#120F1D"),
        suggestionText = c("#F7F2FF"),
        suggestionAccentText = c("#C79BFF"),
        divider = c("#3A3151"),
        keyCornerRadiusDp = 11f
    )

    val FOREST = KeyboardTheme(
        id = "forest",
        displayName = "Forest",
        isDark = true,
        keyboardBackground = c("#0D1B16"),
        keyBackground = c("#193229"),
        keyBackgroundPressed = c("#285044"),
        specialKeyBackground = c("#13271F"),
        specialKeyBackgroundPressed = c("#214337"),
        keyText = c("#ECFFF6"),
        keyTextSecondary = c("#8CC7AA"),
        accent = c("#55D99A"),
        suggestionBarBackground = c("#0A1511"),
        suggestionText = c("#ECFFF6"),
        suggestionAccentText = c("#55D99A"),
        divider = c("#25483A"),
        keyCornerRadiusDp = 10f
    )

    val ROSE = KeyboardTheme(
        id = "rose",
        displayName = "Rose",
        isDark = true,
        keyboardBackground = c("#21131B"),
        keyBackground = c("#39202D"),
        keyBackgroundPressed = c("#543246"),
        specialKeyBackground = c("#2C1824"),
        specialKeyBackgroundPressed = c("#48293A"),
        keyText = c("#FFF1F7"),
        keyTextSecondary = c("#D39AB3"),
        accent = c("#FF86B5"),
        suggestionBarBackground = c("#190F15"),
        suggestionText = c("#FFF1F7"),
        suggestionAccentText = c("#FF86B5"),
        divider = c("#492A3A"),
        keyCornerRadiusDp = 12f
    )

    val CARBON = KeyboardTheme(
        id = "carbon",
        displayName = "Carbon",
        isDark = true,
        keyboardBackground = c("#0B0C0E"),
        keyBackground = c("#1B1D20"),
        keyBackgroundPressed = c("#30343A"),
        specialKeyBackground = c("#141619"),
        specialKeyBackgroundPressed = c("#282C31"),
        keyText = c("#F4F5F6"),
        keyTextSecondary = c("#969BA3"),
        accent = c("#E6E8EB"),
        suggestionBarBackground = c("#090A0C"),
        suggestionText = c("#F4F5F6"),
        suggestionAccentText = c("#FFFFFF"),
        divider = c("#30343A"),
        keyCornerRadiusDp = 7f,
        showKeyBorders = true,
        keyBorderColor = c("#34383E")
    )

    val ARCTIC = KeyboardTheme(
        id = "arctic",
        displayName = "Arctic",
        isDark = false,
        keyboardBackground = c("#E5F1F8"),
        keyBackground = c("#F9FCFF"),
        keyBackgroundPressed = c("#D5E7F2"),
        specialKeyBackground = c("#D6E6F0"),
        specialKeyBackgroundPressed = c("#C2D9E6"),
        keyText = c("#10212C"),
        keyTextSecondary = c("#557080"),
        accent = c("#147DB2"),
        suggestionBarBackground = c("#EDF7FC"),
        suggestionText = c("#10212C"),
        suggestionAccentText = c("#147DB2"),
        divider = c("#C8DDE8"),
        keyCornerRadiusDp = 10f
    )

    val NEON = KeyboardTheme(
        id = "neon",
        displayName = "Neon",
        isDark = true,
        keyboardBackground = c("#090A12"),
        keyBackground = c("#17192A"),
        keyBackgroundPressed = c("#292D49"),
        specialKeyBackground = c("#111323"),
        specialKeyBackgroundPressed = c("#242943"),
        keyText = c("#F8F8FF"),
        keyTextSecondary = c("#9EA5D6"),
        accent = c("#65F6FF"),
        suggestionBarBackground = c("#070810"),
        suggestionText = c("#F8F8FF"),
        suggestionAccentText = c("#65F6FF"),
        divider = c("#2B3153"),
        keyCornerRadiusDp = 13f,
        showKeyBorders = true,
        keyBorderColor = c("#394170")
    )

    /**
     * Built-in themes are intentionally varied like a modern keyboard theme gallery:
     * neutral, colorful, high-contrast and translucent-looking presets.
     *
     * "system" is resolved at runtime from Android 12+ dynamic/Monet colors.
     */
    val builtIn: List<KeyboardTheme> =
        listOf(
            MIDNIGHT,
            DAYLIGHT,
            OCEAN,
            SUNSET,
            LAVENDER,
            FOREST,
            ROSE,
            CARBON,
            ARCTIC,
            NEON,
            GLASS,
            HIGH_CONTRAST
        )

    fun systemDynamic(context: Context): KeyboardTheme {
        val fallback = if ((context.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        ) MIDNIGHT else DAYLIGHT

        if (android.os.Build.VERSION.SDK_INT < 31) return fallback

        fun systemColor(name: String, fallbackColor: Int): Int = try {
            val id = context.resources.getIdentifier(name, "color", "android")
            if (id != 0) context.getColor(id) else fallbackColor
        } catch (_: Throwable) {
            fallbackColor
        }

        val dark = (context.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES

        val accent = systemColor(
            if (dark) "system_accent1_200" else "system_accent1_600",
            fallback.accent
        )
        val background = systemColor(
            if (dark) "system_neutral1_900" else "system_neutral1_10",
            fallback.keyboardBackground
        )
        val key = systemColor(
            if (dark) "system_neutral1_800" else "system_neutral1_0",
            fallback.keyBackground
        )
        val keyPressed = systemColor(
            if (dark) "system_neutral2_700" else "system_neutral2_100",
            fallback.keyBackgroundPressed
        )
        val special = systemColor(
            if (dark) "system_neutral2_900" else "system_neutral2_100",
            fallback.specialKeyBackground
        )
        val text = systemColor(
            if (dark) "system_neutral1_10" else "system_neutral1_900",
            fallback.keyText
        )
        val secondary = systemColor(
            if (dark) "system_neutral2_200" else "system_neutral2_700",
            fallback.keyTextSecondary
        )
        val divider = systemColor(
            if (dark) "system_neutral2_700" else "system_neutral2_100",
            fallback.divider
        )
        return KeyboardTheme(
            id = "system",
            displayName = "System Dynamic",
            isDark = dark,
            keyboardBackground = background,
            keyBackground = key,
            keyBackgroundPressed = keyPressed,
            specialKeyBackground = special,
            specialKeyBackgroundPressed = keyPressed,
            keyText = text,
            keyTextSecondary = secondary,
            accent = accent,
            suggestionBarBackground = background,
            suggestionText = text,
            suggestionAccentText = accent,
            divider = divider,
            keyCornerRadiusDp = 10f,
            showKeyBorders = false
        )
    }

    fun findById(context: Context, id: String): KeyboardTheme {
        if (id == "system") return systemDynamic(context)
        builtIn.firstOrNull { it.id == id }?.let { return it }
        customThemes(context).firstOrNull { it.id == id }?.let { return it }
        return systemDynamic(context)
    }

    fun allThemes(context: Context): List<KeyboardTheme> =
        listOf(systemDynamic(context)) + builtIn + customThemes(context)

    fun customThemes(context: Context): List<KeyboardTheme> {
        val json = prefs(context).getString(KEY_THEMES, null) ?: return emptyList()
        return try {
            val array = JSONArray(json)
            (0 until array.length()).map { i -> fromJson(array.getJSONObject(i)) }
        } catch (t: Throwable) {
            emptyList()
        }
    }

    fun saveCustomTheme(context: Context, theme: KeyboardTheme) {
        val existing = customThemes(context).filterNot { it.id == theme.id }
        val all = existing + theme
        val array = JSONArray()
        all.forEach { array.put(toJson(it)) }
        prefs(context).edit().putString(KEY_THEMES, array.toString()).apply()
    }

    fun deleteCustomTheme(context: Context, id: String) {
        val remaining = customThemes(context).filterNot { it.id == id }
        val array = JSONArray()
        remaining.forEach { array.put(toJson(it)) }
        prefs(context).edit().putString(KEY_THEMES, array.toString()).apply()
    }

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun toJson(t: KeyboardTheme): JSONObject = JSONObject().apply {
        put("id", t.id)
        put("displayName", t.displayName)
        put("isDark", t.isDark)
        put("keyboardBackground", t.keyboardBackground)
        put("keyBackground", t.keyBackground)
        put("keyBackgroundPressed", t.keyBackgroundPressed)
        put("specialKeyBackground", t.specialKeyBackground)
        put("specialKeyBackgroundPressed", t.specialKeyBackgroundPressed)
        put("keyText", t.keyText)
        put("keyTextSecondary", t.keyTextSecondary)
        put("accent", t.accent)
        put("suggestionBarBackground", t.suggestionBarBackground)
        put("suggestionText", t.suggestionText)
        put("suggestionAccentText", t.suggestionAccentText)
        put("divider", t.divider)
        put("keyCornerRadiusDp", t.keyCornerRadiusDp)
        put("keyOpacity", t.keyOpacity)
        put("keyboardOpacity", t.keyboardOpacity)
        put("showKeyBorders", t.showKeyBorders)
        put("keyBorderColor", t.keyBorderColor)
    }

    private fun fromJson(o: JSONObject): KeyboardTheme = KeyboardTheme(
        id = o.getString("id"),
        displayName = o.getString("displayName"),
        isDark = o.getBoolean("isDark"),
        keyboardBackground = o.getInt("keyboardBackground"),
        keyBackground = o.getInt("keyBackground"),
        keyBackgroundPressed = o.getInt("keyBackgroundPressed"),
        specialKeyBackground = o.getInt("specialKeyBackground"),
        specialKeyBackgroundPressed = o.getInt("specialKeyBackgroundPressed"),
        keyText = o.getInt("keyText"),
        keyTextSecondary = o.getInt("keyTextSecondary"),
        accent = o.getInt("accent"),
        suggestionBarBackground = o.getInt("suggestionBarBackground"),
        suggestionText = o.getInt("suggestionText"),
        suggestionAccentText = o.getInt("suggestionAccentText"),
        divider = o.getInt("divider"),
        keyCornerRadiusDp = o.optDouble("keyCornerRadiusDp", 8.0).toFloat(),
        keyOpacity = o.optDouble("keyOpacity", 1.0).toFloat(),
        keyboardOpacity = o.optDouble("keyboardOpacity", 1.0).toFloat(),
        showKeyBorders = o.optBoolean("showKeyBorders", false),
        keyBorderColor = o.optInt("keyBorderColor", o.getInt("keyBackground"))
    )
}

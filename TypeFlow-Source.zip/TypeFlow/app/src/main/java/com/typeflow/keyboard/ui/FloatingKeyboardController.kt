package com.typeflow.keyboard.ui

import android.content.Context
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import com.typeflow.keyboard.settings.TypeFlowSettings

/**
 * Makes the IME's own window float and draggable, instead of docking full-width
 * at the bottom of the screen — a real window-attribute change, not just a
 * visual style. This relies on adjusting the IME window's own
 * [WindowManager.LayoutParams], which is the mechanism available to an
 * InputMethodService; Android (and some OEM skins/games) can still restrict or
 * override IME window behavior, which is a platform limitation this class
 * cannot bypass — see the size/position bounds-checking below for the
 * best-effort handling of that.
 */
class FloatingKeyboardController(private val context: Context) {

    private var attachedWindow: Window? = null

    fun enable(window: Window, widthPx: Int, heightPx: Int) {
        attachedWindow = window
        val (savedX, savedY) = TypeFlowSettings.getFloatingPosition(context)
        applyParams(window, widthPx, heightPx, savedX, savedY)
    }

    fun disable(window: Window) {
        val params = window.attributes
        params.width = WindowManager.LayoutParams.MATCH_PARENT
        params.height = WindowManager.LayoutParams.WRAP_CONTENT
        params.gravity = Gravity.BOTTOM
        params.x = 0
        params.y = 0
        runCatching { window.attributes = params }
        attachedWindow = null
    }

    fun moveBy(dx: Float, dy: Float) {
        val window = attachedWindow ?: return
        val params = window.attributes
        params.x = (params.x + dx.toInt())
        params.y = (params.y + dy.toInt())
        runCatching { window.attributes = params }
    }

    fun persistCurrentPosition() {
        val window = attachedWindow ?: return
        TypeFlowSettings.setFloatingPosition(context, window.attributes.x, window.attributes.y)
    }

    private fun applyParams(window: Window, widthPx: Int, heightPx: Int, x: Int, y: Int) {
        val params = window.attributes
        params.width = widthPx
        params.height = heightPx
        params.gravity = Gravity.TOP or Gravity.START
        params.x = x
        params.y = y
        params.format = PixelFormat.TRANSLUCENT
        runCatching { window.attributes = params }
    }
}

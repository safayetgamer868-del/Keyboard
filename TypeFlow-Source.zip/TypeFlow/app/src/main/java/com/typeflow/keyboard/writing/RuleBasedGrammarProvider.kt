package com.typeflow.keyboard.writing

/**
 * Real, deterministic local grammar checks — no network, no fake AI wording.
 * Covers the mistakes people actually make while typing on a phone:
 * duplicate words, double spaces, a lowercase standalone "i", and sentences
 * that don't start with a capital letter. This is explicitly a local/basic
 * provider; [GrammarProvider] is the seam a future advanced engine plugs into.
 */
class RuleBasedGrammarProvider : GrammarProvider {

    override fun check(text: String): List<GrammarIssue> {
        val issues = mutableListOf<GrammarIssue>()
        issues += findDoubleSpaces(text)
        issues += findRepeatedWords(text)
        issues += findLowercaseI(text)
        issues += findSentenceStartCapitalization(text)
        return issues.sortedBy { it.start }
    }

    private fun findDoubleSpaces(text: String): List<GrammarIssue> {
        val regex = Regex(" {2,}")
        return regex.findAll(text).map {
            GrammarIssue(it.range.first, it.range.last + 1, "Extra spaces", " ")
        }.toList()
    }

    private fun findRepeatedWords(text: String): List<GrammarIssue> {
        val regex = Regex("\\b(\\w+)\\s+\\1\\b", RegexOption.IGNORE_CASE)
        return regex.findAll(text).map {
            GrammarIssue(it.range.first, it.range.last + 1, "Repeated word", it.groupValues[1])
        }.toList()
    }

    private fun findLowercaseI(text: String): List<GrammarIssue> {
        val regex = Regex("\\bi\\b")
        return regex.findAll(text).map {
            GrammarIssue(it.range.first, it.range.last + 1, "\"I\" should be capitalized", "I")
        }.toList()
    }

    private fun findSentenceStartCapitalization(text: String): List<GrammarIssue> {
        val issues = mutableListOf<GrammarIssue>()
        val sentenceStart = Regex("(^|[.!?]\\s+)([a-z])")
        sentenceStart.findAll(text).forEach { match ->
            val letterGroup = match.groups[2] ?: return@forEach
            issues.add(
                GrammarIssue(
                    letterGroup.range.first,
                    letterGroup.range.last + 1,
                    "Sentence should start with a capital letter",
                    letterGroup.value.uppercase()
                )
            )
        }
        return issues
    }
}

package com.typeflow.keyboard.writing

sealed class TranslationResult {
    data class Success(val translatedText: String) : TranslationResult()
    data class Error(val message: String) : TranslationResult()
}

/** Isolated, replaceable translation backend. [HttpTranslationProvider] is the shipped implementation. */
interface TranslationProvider {
    fun translate(text: String, targetLanguageCode: String, callback: (TranslationResult) -> Unit)
}

package com.typeflow.keyboard.writing

enum class RewriteTone { PROFESSIONAL, FRIENDLY, CASUAL, CONCISE }

/** Isolated, replaceable rewrite backend. [TemplateToneProvider] is the local, shipped implementation. */
interface ToneRewriteProvider {
    fun rewrite(text: String, tone: RewriteTone): String
}

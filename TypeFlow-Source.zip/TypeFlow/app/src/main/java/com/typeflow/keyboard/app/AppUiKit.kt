package com.typeflow.keyboard.app

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import com.typeflow.keyboard.R

/**
 * Shared building blocks for every settings screen so the app has one
 * consistent visual language instead of default system widgets scattered
 * with inconsistent spacing.
 */
object AppUiKit {

    fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    fun screen(context: Context): Pair<ScrollView, LinearLayout> {
        val scroll = ScrollView(context).apply {
            setBackgroundColor(ContextCompat.getColor(context, R.color.tf_background))
            isFillViewport = true
        }
        val column = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            val pad = dp(context, 16)
            setPadding(pad, pad, pad, dp(context, 48))
        }
        scroll.addView(column)
        return scroll to column
    }

    fun sectionTitle(context: Context, text: String): TextView = TextView(context).apply {
        this.text = text
        setTextColor(ContextCompat.getColor(context, R.color.tf_on_surface_variant))
        textSize = 13f
        setPadding(dp(context, 4), dp(context, 20), dp(context, 4), dp(context, 8))
    }

    fun card(context: Context): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable().apply {
            cornerRadius = dp(context, 16).toFloat()
            setColor(ContextCompat.getColor(context, R.color.tf_surface))
        }
        background = bg
        val pad = dp(context, 4)
        setPadding(pad, pad, pad, pad)
    }

    fun divider(context: Context): View = View(context).apply {
        setBackgroundColor(ContextCompat.getColor(context, R.color.tf_divider))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
    }

    fun row(context: Context): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        val padH = dp(context, 16)
        val padV = dp(context, 14)
        setPadding(padH, padV, padH, padV)
        isClickable = false
    }

    fun rowTitle(context: Context, title: String, subtitle: String? = null): LinearLayout {
        val column = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        column.addView(
            TextView(context).apply {
                text = title
                setTextColor(ContextCompat.getColor(context, R.color.tf_on_surface))
                textSize = 15f
            }
        )
        if (subtitle != null) {
            column.addView(
                TextView(context).apply {
                    text = subtitle
                    setTextColor(ContextCompat.getColor(context, R.color.tf_on_surface_variant))
                    textSize = 12f
                }
            )
        }
        return column
    }

    fun switchRow(context: Context, title: String, subtitle: String? = null, checked: Boolean, onChanged: (Boolean) -> Unit): LinearLayout {
        val r = row(context)
        r.addView(rowTitle(context, title, subtitle), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val toggle = Switch(context).apply { isChecked = checked }
        toggle.setOnCheckedChangeListener { _: CompoundButton, isChecked: Boolean -> onChanged(isChecked) }
        r.addView(toggle)
        return r
    }

    fun clickableRow(context: Context, title: String, subtitle: String? = null, onClick: () -> Unit): LinearLayout {
        val r = row(context)
        r.isClickable = true
        r.isFocusable = true
        r.background = rippleBackground(context)
        r.addView(rowTitle(context, title, subtitle), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val chevron = TextView(context).apply {
            text = "\u203A"
            textSize = 20f
            setTextColor(ContextCompat.getColor(context, R.color.tf_on_surface_variant))
        }
        r.addView(chevron)
        r.setOnClickListener { onClick() }
        return r
    }

    fun sliderRow(context: Context, title: String, progress: Int, max: Int = 100, onChanged: (Int) -> Unit): LinearLayout {
        val column = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val padH = dp(context, 16)
        column.setPadding(padH, dp(context, 10), padH, dp(context, 10))
        column.addView(rowTitle(context, title))
        val seek = SeekBar(context).apply {
            this.max = max
            this.progress = progress
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser) onChanged(value)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        column.addView(seek)
        return column
    }

    fun radioGroupRow(context: Context, title: String, options: List<String>, selectedIndex: Int, onSelected: (Int) -> Unit): LinearLayout {
        val column = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val padH = dp(context, 16)
        column.setPadding(padH, dp(context, 10), padH, dp(context, 10))
        column.addView(rowTitle(context, title))
        val group = RadioGroup(context).apply { orientation = RadioGroup.HORIZONTAL }
        options.forEachIndexed { index, label ->
            val radioButton = RadioButton(context).apply {
                text = label
                isChecked = index == selectedIndex
                id = index
            }
            group.addView(radioButton)
        }
        group.setOnCheckedChangeListener { _, checkedId -> onSelected(checkedId) }
        column.addView(group)
        return column
    }

    fun textFieldRow(context: Context, title: String, value: String, hint: String, onChanged: (String) -> Unit): LinearLayout {
        val column = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val padH = dp(context, 16)
        column.setPadding(padH, dp(context, 10), padH, dp(context, 10))
        column.addView(rowTitle(context, title))
        val field = EditText(context).apply {
            setText(value)
            this.hint = hint
            setSingleLine()
        }
        field.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) onChanged(field.text.toString()) }
        column.addView(field)
        return column
    }

    fun primaryButton(context: Context, text: String, onClick: () -> Unit): TextView = TextView(context).apply {
        this.text = text
        setTextColor(ContextCompat.getColor(context, android.R.color.white))
        textSize = 15f
        gravity = Gravity.CENTER
        val bg = GradientDrawable().apply {
            cornerRadius = dp(context, 24).toFloat()
            setColor(ContextCompat.getColor(context, R.color.tf_accent))
        }
        background = bg
        val padH = dp(context, 20)
        val padV = dp(context, 12)
        setPadding(padH, padV, padH, padV)
        isClickable = true
        setOnClickListener { onClick() }
    }

    private fun rippleBackground(context: Context): RippleDrawable {
        val mask = GradientDrawable().apply { setColor(android.graphics.Color.WHITE) }
        return RippleDrawable(
            android.content.res.ColorStateList.valueOf(ContextCompat.getColor(context, R.color.tf_accent_soft)),
            null,
            mask
        )
    }
}

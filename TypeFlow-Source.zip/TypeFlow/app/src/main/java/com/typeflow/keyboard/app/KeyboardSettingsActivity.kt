package com.typeflow.keyboard.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.typeflow.keyboard.settings.TypeFlowSettings

class KeyboardSettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Keyboard behavior"
        val (scroll, column) = AppUiKit.screen(this)
        setContentView(scroll)

        column.addView(AppUiKit.sectionTitle(this, "SIZE & LAYOUT"))
        column.addView(sectionCard(
            AppUiKit.sliderRow(this, "Keyboard height", (TypeFlowSettings.getHeightPercent(this) * 100).toInt()) { value ->
                TypeFlowSettings.setHeightPercent(this, value / 100f)
            },
            AppUiKit.switchRow(this, "Number row", "Show a row of digits above the letters", TypeFlowSettings.isNumberRowEnabled(this)) {
                TypeFlowSettings.setNumberRowEnabled(this, it)
            },
            AppUiKit.radioGroupRow(
                this, "One-handed mode", listOf("Off", "Left", "Right"),
                selectedIndex = when (TypeFlowSettings.getOneHandedMode(this)) {
                    TypeFlowSettings.ONE_HANDED_LEFT -> 1
                    TypeFlowSettings.ONE_HANDED_RIGHT -> 2
                    else -> 0
                }
            ) { index ->
                TypeFlowSettings.setOneHandedMode(
                    this,
                    when (index) {
                        1 -> TypeFlowSettings.ONE_HANDED_LEFT
                        2 -> TypeFlowSettings.ONE_HANDED_RIGHT
                        else -> TypeFlowSettings.ONE_HANDED_OFF
                    }
                )
            },
            AppUiKit.switchRow(this, "Floating keyboard", "Undock the keyboard into a movable window", TypeFlowSettings.isFloatingEnabled(this)) {
                TypeFlowSettings.setFloatingEnabled(this, it)
            }
        ))

        column.addView(AppUiKit.sectionTitle(this, "TYPING"))
        column.addView(sectionCard(
            AppUiKit.switchRow(this, "Suggestions", "Show word suggestions while typing", TypeFlowSettings.isSuggestionsEnabled(this)) {
                TypeFlowSettings.setSuggestionsEnabled(this, it)
            },
            AppUiKit.switchRow(this, "Auto-correct", "Fix likely typos automatically", TypeFlowSettings.isAutoCorrectEnabled(this)) {
                TypeFlowSettings.setAutoCorrectEnabled(this, it)
            },
            AppUiKit.switchRow(this, "Aggressive auto-correct", "Allow bigger corrections (edit distance 2)", TypeFlowSettings.isAutoCorrectAggressive(this)) {
                TypeFlowSettings.setAutoCorrectAggressive(this, it)
            },
            AppUiKit.switchRow(this, "Glide typing", "Type by sliding across letters", TypeFlowSettings.isGlideTypingEnabled(this)) {
                TypeFlowSettings.setGlideTypingEnabled(this, it)
            }
        ))

        column.addView(AppUiKit.sectionTitle(this, "FEEDBACK"))
        column.addView(sectionCard(
            AppUiKit.switchRow(this, "Key sounds", checked = TypeFlowSettings.isKeySoundEnabled(this)) {
                TypeFlowSettings.setKeySoundEnabled(this, it)
            },
            AppUiKit.switchRow(this, "Key vibration", checked = TypeFlowSettings.isKeyVibrateEnabled(this)) {
                TypeFlowSettings.setKeyVibrateEnabled(this, it)
            }
        ))

        column.addView(AppUiKit.sectionTitle(this, "CLIPBOARD & SCREENSHOTS"))
        column.addView(sectionCard(
            AppUiKit.sliderRow(this, "Clipboard history size", TypeFlowSettings.getClipboardMaxItems(this), max = 200) { value ->
                TypeFlowSettings.setClipboardMaxItems(this, value.coerceAtLeast(10))
            },
            AppUiKit.switchRow(
                this, "Save recent screenshots", "Requires photo access permission",
                TypeFlowSettings.isScreenshotHistoryEnabled(this)
            ) { enabled -> onScreenshotToggle(enabled) }
        ))
    }

    private fun onScreenshotToggle(enabled: Boolean) {
        if (!enabled) {
            TypeFlowSettings.setScreenshotHistoryEnabled(this, false)
            return
        }
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            TypeFlowSettings.setScreenshotHistoryEnabled(this, true)
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(permission), 9001)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 9001) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            TypeFlowSettings.setScreenshotHistoryEnabled(this, granted)
            recreate()
        }
    }

    private fun sectionCard(vararg rows: android.view.View): android.widget.LinearLayout {
        val card = AppUiKit.card(this)
        rows.forEachIndexed { index, row ->
            card.addView(row)
            if (index != rows.lastIndex) card.addView(AppUiKit.divider(this))
        }
        return card
    }
}

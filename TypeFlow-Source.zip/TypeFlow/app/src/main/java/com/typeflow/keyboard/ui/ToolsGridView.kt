package com.typeflow.keyboard.ui

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.typeflow.keyboard.R
import com.typeflow.keyboard.themes.KeyboardTheme

/** The keyboard's "Tools" panel: a grid of icon buttons replacing the key surface while open. */
class ToolsGridView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : GridLayout(context, attrs) {

    var theme: KeyboardTheme = com.typeflow.keyboard.themes.ThemeRepository.MIDNIGHT
        set(value) { field = value; rebuild() }

    var canUndo: Boolean = false
    var canRedo: Boolean = false
    var onAction: ((ToolAction) -> Unit)? = null

    init {
        columnCount = 4
        val pad = ViewStyling.dp(context, 12)
        setPadding(pad, pad, pad, pad)
        rebuild()
    }

    fun refresh(canUndo: Boolean, canRedo: Boolean) {
        this.canUndo = canUndo
        this.canRedo = canRedo
        rebuild()
    }

    private fun rebuild() {
        removeAllViews()
        setBackgroundColor(theme.keyboardBackground)

        val entries = listOf(
            Triple(ToolAction.UNDO, R.drawable.ic_undo, "Undo"),
            Triple(ToolAction.REDO, R.drawable.ic_redo, "Redo"),
            Triple(ToolAction.CLIPBOARD, R.drawable.ic_clipboard, "Clipboard"),
            Triple(ToolAction.VOICE, R.drawable.ic_mic, "Voice"),
            Triple(ToolAction.TRANSLATE, R.drawable.ic_translate, "Translate"),
            Triple(ToolAction.GRAMMAR, R.drawable.ic_correct, "Grammar"),
            Triple(ToolAction.TONE, R.drawable.ic_edit, "Rewrite"),
            Triple(ToolAction.GIF, R.drawable.ic_gif, "GIF"),
            Triple(ToolAction.SETTINGS, R.drawable.ic_settings, "Settings"),
            Triple(ToolAction.BACK, R.drawable.ic_arrow_back, "Back")
        )

        for ((action, icon, label) in entries) {
            val enabled = when (action) {
                ToolAction.UNDO -> canUndo
                ToolAction.REDO -> canRedo
                else -> true
            }
            val cell = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                val padV = ViewStyling.dp(context, 8)
                setPadding(0, padV, 0, padV)
                alpha = if (enabled) 1f else 0.35f
                isEnabled = enabled
            }
            val button = ViewStyling.iconButton(context, icon, theme.keyText, theme.specialKeyBackground, theme)
            button.isEnabled = enabled
            if (enabled) button.setOnClickListener { onAction?.invoke(action) }
            val text = TextView(context).apply {
                this.text = label
                setTextColor(theme.keyTextSecondary)
                textSize = 11f
                gravity = Gravity.CENTER
                setPadding(0, ViewStyling.dp(context, 4), 0, 0)
            }
            cell.addView(button)
            cell.addView(text)

            val lp = LayoutParams(GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            lp.setMargins(ViewStyling.dp(context, 4), ViewStyling.dp(context, 4), ViewStyling.dp(context, 4), ViewStyling.dp(context, 4))
            addView(cell, lp)
        }
    }
}

package com.typeflow.keyboard.dictionary

import android.content.Context
import com.typeflow.keyboard.languages.Language
import java.util.concurrent.ConcurrentHashMap

/**
 * Loads a language's bundled word list (rank-ordered by frequency, most
 * common first) plus the user's own added words, and caches it in memory.
 *
 * This is the single dictionary source used by suggestions, autocorrect and
 * glide typing so all three stay consistent with each other and with what
 * the user has taught the keyboard.
 */
object DictionaryProvider {

    private val cache = ConcurrentHashMap<String, List<String>>()

    fun wordsFor(context: Context, language: Language): List<String> {
        return cache.getOrPut(language.code) {
            val builtIn = try {
                context.assets.open(language.dictionaryAsset).bufferedReader().useLines { lines ->
                    lines.map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toList()
                }
            } catch (t: Throwable) {
                emptyList()
            }
            val userWords = UserDictionaryStore.words(context, language.code).toList()
            // Built-in words are already frequency-ranked; user words are assumed higher priority (learned on purpose).
            (userWords + builtIn).distinct()
        }
    }

    /** Call after the user adds/removes a custom word so the cache reflects it immediately. */
    fun invalidate(languageCode: String) {
        cache.remove(languageCode)
    }

    fun contains(context: Context, language: Language, word: String): Boolean =
        wordsFor(context, language).contains(word.lowercase())
}

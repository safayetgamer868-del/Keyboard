package com.typeflow.keyboard.settings

import android.content.Context
import android.content.SharedPreferences

/**
 * Single source of truth for every persisted TypeFlow setting.
 *
 * The IME and the app both read/write through this object so that a change
 * made in the app (e.g. toggling the number row) is picked up by the running
 * keyboard the next time it needs the value — no broadcast/restart required.
 */
object TypeFlowSettings {

    private const val FILE = "typeflow_settings"

    private const val KEY_HEIGHT_PERCENT = "keyboard_height_percent"
    private const val KEY_NUMBER_ROW = "number_row_enabled"
    private const val KEY_ONE_HANDED_MODE = "one_handed_mode" // off | left | right
    private const val KEY_FLOATING_ENABLED = "floating_enabled"
    private const val KEY_FLOATING_X = "floating_x"
    private const val KEY_FLOATING_Y = "floating_y"
    private const val KEY_THEME_ID = "theme_id"
    private const val KEY_AUTO_CORRECT = "auto_correct_enabled"
    private const val KEY_AUTO_CORRECT_AGGRESSIVE = "auto_correct_aggressive"
    private const val KEY_GLIDE_TYPING = "glide_typing_enabled"
    private const val KEY_SUGGESTIONS = "suggestions_enabled"
    private const val KEY_SOUND = "key_sound_enabled"
    private const val KEY_VIBRATE = "key_vibrate_enabled"
    private const val KEY_ACTIVE_LANGUAGE = "active_language"
    private const val KEY_ENABLED_LANGUAGES = "enabled_languages"
    private const val KEY_TRANSLATE_TARGET = "translate_target_lang"
    private const val KEY_TRANSLATE_ENDPOINT = "translate_endpoint_url"
    private const val KEY_GIF_API_KEY = "gif_api_key"
    private const val KEY_SCREENSHOT_HISTORY = "screenshot_history_enabled"
    private const val KEY_CLIPBOARD_MAX = "clipboard_max_items"

    const val ONE_HANDED_OFF = "off"
    const val ONE_HANDED_LEFT = "left"
    const val ONE_HANDED_RIGHT = "right"

    fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun registerListener(context: Context, listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs(context).registerOnSharedPreferenceChangeListener(listener)
    }

    fun unregisterListener(context: Context, listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs(context).unregisterOnSharedPreferenceChangeListener(listener)
    }

    /** 0f (compact) .. 1f (tall). Only the overall height derives from this — never key width. */
    fun getHeightPercent(context: Context): Float =
        prefs(context).getFloat(KEY_HEIGHT_PERCENT, 0.5f)

    fun setHeightPercent(context: Context, value: Float) {
        prefs(context).edit().putFloat(KEY_HEIGHT_PERCENT, value.coerceIn(0f, 1f)).apply()
    }

    fun isNumberRowEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_NUMBER_ROW, true)

    fun setNumberRowEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_NUMBER_ROW, enabled).apply()
    }

    fun getOneHandedMode(context: Context): String =
        prefs(context).getString(KEY_ONE_HANDED_MODE, ONE_HANDED_OFF) ?: ONE_HANDED_OFF

    fun setOneHandedMode(context: Context, mode: String) {
        prefs(context).edit().putString(KEY_ONE_HANDED_MODE, mode).apply()
    }

    fun isFloatingEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_FLOATING_ENABLED, false)

    fun setFloatingEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_FLOATING_ENABLED, enabled).apply()
    }

    fun getFloatingPosition(context: Context): Pair<Int, Int> {
        val p = prefs(context)
        return p.getInt(KEY_FLOATING_X, 0) to p.getInt(KEY_FLOATING_Y, 0)
    }

    fun setFloatingPosition(context: Context, x: Int, y: Int) {
        prefs(context).edit().putInt(KEY_FLOATING_X, x).putInt(KEY_FLOATING_Y, y).apply()
    }

    fun getThemeId(context: Context): String =
        prefs(context).getString(KEY_THEME_ID, "system") ?: "system"

    fun setThemeId(context: Context, id: String) {
        prefs(context).edit().putString(KEY_THEME_ID, id).apply()
    }

    fun isAutoCorrectEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_AUTO_CORRECT, true)

    fun setAutoCorrectEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_AUTO_CORRECT, enabled).apply()
    }

    fun isAutoCorrectAggressive(context: Context): Boolean =
        prefs(context).getBoolean(KEY_AUTO_CORRECT_AGGRESSIVE, false)

    fun setAutoCorrectAggressive(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_AUTO_CORRECT_AGGRESSIVE, enabled).apply()
    }

    fun isGlideTypingEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_GLIDE_TYPING, true)

    fun setGlideTypingEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_GLIDE_TYPING, enabled).apply()
    }

    fun isSuggestionsEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_SUGGESTIONS, true)

    fun setSuggestionsEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_SUGGESTIONS, enabled).apply()
    }

    fun isKeySoundEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_SOUND, false)

    fun setKeySoundEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_SOUND, enabled).apply()
    }

    fun isKeyVibrateEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_VIBRATE, true)

    fun setKeyVibrateEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_VIBRATE, enabled).apply()
    }

    fun getActiveLanguage(context: Context): String =
        prefs(context).getString(KEY_ACTIVE_LANGUAGE, "en") ?: "en"

    fun setActiveLanguage(context: Context, code: String) {
        prefs(context).edit().putString(KEY_ACTIVE_LANGUAGE, code).apply()
    }

    fun getEnabledLanguages(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_ENABLED_LANGUAGES, setOf("en")) ?: setOf("en")

    fun setEnabledLanguages(context: Context, codes: Set<String>) {
        prefs(context).edit().putStringSet(KEY_ENABLED_LANGUAGES, codes).apply()
    }

    fun getTranslateTargetLanguage(context: Context): String =
        prefs(context).getString(KEY_TRANSLATE_TARGET, "es") ?: "es"

    fun setTranslateTargetLanguage(context: Context, code: String) {
        prefs(context).edit().putString(KEY_TRANSLATE_TARGET, code).apply()
    }

    /** Empty by default: translation over the network is opt-in and requires the user to set an endpoint. */
    fun getTranslateEndpoint(context: Context): String =
        prefs(context).getString(KEY_TRANSLATE_ENDPOINT, "") ?: ""

    fun setTranslateEndpoint(context: Context, url: String) {
        prefs(context).edit().putString(KEY_TRANSLATE_ENDPOINT, url).apply()
    }

    /** Empty by default: GIF search requires the user's own Tenor API key. */
    fun getGifApiKey(context: Context): String =
        prefs(context).getString(KEY_GIF_API_KEY, "") ?: ""

    fun setGifApiKey(context: Context, key: String) {
        prefs(context).edit().putString(KEY_GIF_API_KEY, key).apply()
    }

    fun isScreenshotHistoryEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_SCREENSHOT_HISTORY, false)

    fun setScreenshotHistoryEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_SCREENSHOT_HISTORY, enabled).apply()
    }

    fun getClipboardMaxItems(context: Context): Int =
        prefs(context).getInt(KEY_CLIPBOARD_MAX, 60)

    fun setClipboardMaxItems(context: Context, count: Int) {
        prefs(context).edit().putInt(KEY_CLIPBOARD_MAX, count.coerceIn(10, 300)).apply()
    }
}

package com.typeflow.keyboard.app

import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.typeflow.keyboard.R

class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "About"
        val (scroll, column) = AppUiKit.screen(this)
        setContentView(scroll)

        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (_: PackageManager.NameNotFoundException) {
            "unknown"
        }

        val card = AppUiKit.card(this)
        val text = TextView(this).apply {
            setPadding(AppUiKit.dp(this@AboutActivity, 16), AppUiKit.dp(this@AboutActivity, 16), AppUiKit.dp(this@AboutActivity, 16), AppUiKit.dp(this@AboutActivity, 16))
            setLineSpacing(AppUiKit.dp(this@AboutActivity, 4).toFloat(), 1f)
            text = """
                ${getString(R.string.app_name)} \u2014 version $version

                A modular Android keyboard: theming, resize, one-handed and floating modes, glide typing, suggestions and autocorrect, voice typing, undo/redo, an in-app clipboard manager with screenshot history, and writing tools (translate, grammar, tone rewrite) built on replaceable provider interfaces.

                Translation and GIF search require your own server/API key, configured under Writing assistance. Voice typing uses Android's built-in speech recognizer, where available on the device.

                Floating mode and some behavior can be restricted by individual apps, games, or OEM Android builds \u2014 TypeFlow uses the best real behavior the platform allows and falls back gracefully where it doesn't.
            """.trimIndent()
        }
        card.addView(text)
        column.addView(card)
    }
}

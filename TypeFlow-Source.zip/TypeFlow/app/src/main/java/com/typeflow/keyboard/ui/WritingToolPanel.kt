package com.typeflow.keyboard.ui

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import com.typeflow.keyboard.R
import com.typeflow.keyboard.themes.KeyboardTheme
import com.typeflow.keyboard.writing.RewriteTone

enum class WritingMode { TRANSLATE, GRAMMAR, TONE }

/**
 * Shared panel for the three "writing assistance" tools. Each mode shows the
 * captured text from the current field, a mode-specific action, and — once a
 * provider responds — a result the user can insert back into the editor.
 */
class WritingToolPanel @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {

    var theme: KeyboardTheme = com.typeflow.keyboard.themes.ThemeRepository.MIDNIGHT
        set(value) { field = value; setBackgroundColor(value.keyboardBackground) }

    var onBackRequested: (() -> Unit)? = null
    var onInsert: ((String) -> Unit)? = null
    var onTranslateRequested: ((targetLangCode: String) -> Unit)? = null
    var onGrammarCheckRequested: (() -> Unit)? = null
    var onToneRequested: ((RewriteTone) -> Unit)? = null

    private val originalText = TextView(context)
    private val resultText = TextView(context)
    private val progress = ProgressBar(context)
    private val actionsRow = LinearLayout(context).apply { orientation = HORIZONTAL }
    private val insertButton: TextView

    private var mode: WritingMode = WritingMode.TONE
    private var targetLanguageCode: String = "es"

    init {
        orientation = VERTICAL
        val pad = ViewStyling.dp(context, 10)
        setPadding(pad, pad, pad, pad)

        val header = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL }
        val back = ViewStyling.iconButton(context, R.drawable.ic_arrow_back, theme.keyText, theme.specialKeyBackground, theme, 34)
        back.setOnClickListener { onBackRequested?.invoke() }
        header.addView(back)
        addView(header, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewStyling.dp(context, 40)))

        originalText.apply {
            textSize = 13f
            setPadding(0, ViewStyling.dp(context, 4), 0, ViewStyling.dp(context, 8))
            maxLines = 3
        }
        addView(originalText)

        addView(actionsRow, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        progress.visibility = ProgressBar.GONE
        addView(progress, LayoutParams(ViewStyling.dp(context, 24), ViewStyling.dp(context, 24)).also { it.gravity = Gravity.CENTER_HORIZONTAL; it.topMargin = ViewStyling.dp(context, 8) })

        val resultScroll = ScrollView(context)
        resultText.apply { textSize = 14f; setPadding(0, ViewStyling.dp(context, 8), 0, ViewStyling.dp(context, 8)) }
        resultScroll.addView(resultText)
        addView(resultScroll, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        insertButton = ViewStyling.chip(context, "Insert", theme, emphasize = true).apply {
            visibility = TextView.GONE
            setOnClickListener { onInsert?.invoke(resultText.text.toString()) }
        }
        addView(insertButton, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.gravity = Gravity.END })
    }

    fun configure(mode: WritingMode, currentText: String, availableLanguages: List<Pair<String, String>> = emptyList()) {
        this.mode = mode
        originalText.setTextColor(theme.keyTextSecondary)
        originalText.text = if (currentText.isBlank()) "No text found in the current field." else "\u201C$currentText\u201D"
        resultText.setTextColor(theme.keyText)
        resultText.text = ""
        insertButton.visibility = TextView.GONE
        setBackgroundColor(theme.keyboardBackground)
        buildActions(availableLanguages)
    }

    private fun buildActions(availableLanguages: List<Pair<String, String>>) {
        actionsRow.removeAllViews()
        when (mode) {
            WritingMode.TRANSLATE -> {
                val langScroll = HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false }
                val langRow = LinearLayout(context).apply { orientation = HORIZONTAL }
                for ((code, name) in availableLanguages) {
                    val chip = ViewStyling.chip(context, name, theme, emphasize = code == targetLanguageCode)
                    chip.setOnClickListener {
                        targetLanguageCode = code
                        buildActions(availableLanguages)
                    }
                    langRow.addView(chip)
                }
                langScroll.addView(langRow)
                actionsRow.addView(langScroll, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                val go = ViewStyling.chip(context, "Translate", theme, emphasize = true)
                go.setOnClickListener { setLoading(true); onTranslateRequested?.invoke(targetLanguageCode) }
                actionsRow.addView(go)
            }
            WritingMode.GRAMMAR -> {
                val go = ViewStyling.chip(context, "Check grammar", theme, emphasize = true)
                go.setOnClickListener { setLoading(true); onGrammarCheckRequested?.invoke() }
                actionsRow.addView(go)
            }
            WritingMode.TONE -> {
                for (tone in RewriteTone.values()) {
                    val chip = ViewStyling.chip(context, tone.name.lowercase().replaceFirstChar { it.uppercase() }, theme)
                    chip.setOnClickListener { setLoading(true); onToneRequested?.invoke(tone) }
                    actionsRow.addView(chip)
                }
            }
        }
    }

    fun setLoading(loading: Boolean) {
        progress.visibility = if (loading) ProgressBar.VISIBLE else ProgressBar.GONE
    }

    fun showResult(text: String) {
        setLoading(false)
        resultText.setTextColor(theme.keyText)
        resultText.text = text
        insertButton.visibility = TextView.VISIBLE
    }

    fun showError(message: String) {
        setLoading(false)
        resultText.setTextColor(theme.suggestionAccentText)
        resultText.text = message
        insertButton.visibility = TextView.GONE
    }
}

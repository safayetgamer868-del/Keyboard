package com.typeflow.keyboard.core

import android.view.inputmethod.InputConnection

/**
 * A single reversible text edit made through [TextEditingController].
 *
 * Every edit the keyboard performs (typing a character, autocorrecting a
 * word, deleting, inserting a suggestion, applying a rewrite/translation) is
 * recorded here so Undo/Redo work uniformly across all of them, instead of
 * only undoing raw key presses.
 */
sealed class EditOperation {
    data class Insert(val text: String) : EditOperation()
    data class Delete(val deletedText: String) : EditOperation()
    data class Replace(val oldText: String, val newText: String) : EditOperation()
}

/**
 * Maintains an undo/redo stack of [EditOperation]s and can apply their
 * inverse directly on an [InputConnection]. This is a best-effort, in-session
 * history — it does not attempt to model an editor's own native undo stack,
 * since most Android editors don't expose one through InputConnection.
 */
class UndoRedoManager(private val maxDepth: Int = 100) {

    private val undoStack = ArrayDeque<EditOperation>()
    private val redoStack = ArrayDeque<EditOperation>()

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    fun record(operation: EditOperation) {
        undoStack.addLast(operation)
        if (undoStack.size > maxDepth) undoStack.removeFirst()
        redoStack.clear()
    }

    /** Called when the cursor moves to a different field/position outside our control. */
    fun reset() {
        undoStack.clear()
        redoStack.clear()
    }

    fun undo(ic: InputConnection?): Boolean {
        val op = undoStack.removeLastOrNull() ?: return false
        if (ic == null) return false
        ic.beginBatchEdit()
        try {
            when (op) {
                is EditOperation.Insert -> ic.deleteSurroundingText(op.text.length, 0)
                is EditOperation.Delete -> ic.commitText(op.deletedText, 1)
                is EditOperation.Replace -> {
                    ic.deleteSurroundingText(op.newText.length, 0)
                    ic.commitText(op.oldText, 1)
                }
            }
        } finally {
            ic.endBatchEdit()
        }
        redoStack.addLast(op)
        return true
    }

    fun redo(ic: InputConnection?): Boolean {
        val op = redoStack.removeLastOrNull() ?: return false
        if (ic == null) return false
        ic.beginBatchEdit()
        try {
            when (op) {
                is EditOperation.Insert -> ic.commitText(op.text, 1)
                is EditOperation.Delete -> ic.deleteSurroundingText(op.deletedText.length, 0)
                is EditOperation.Replace -> {
                    ic.deleteSurroundingText(op.oldText.length, 0)
                    ic.commitText(op.newText, 1)
                }
            }
        } finally {
            ic.endBatchEdit()
        }
        undoStack.addLast(op)
        return true
    }
}

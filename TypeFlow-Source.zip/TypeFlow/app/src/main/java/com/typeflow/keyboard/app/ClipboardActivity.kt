package com.typeflow.keyboard.app

import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.typeflow.keyboard.R
import com.typeflow.keyboard.clipboard.ClipboardItem
import com.typeflow.keyboard.clipboard.ClipboardStore

class ClipboardActivity : AppCompatActivity() {

    private val store by lazy { ClipboardStore(this) }
    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyLabel: TextView
    private var items: MutableList<ClipboardItem> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Clipboard"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ContextCompat.getColor(this@ClipboardActivity, R.color.tf_background))
        }

        val toolbarRow = AppUiKit.row(this)
        toolbarRow.addView(
            AppUiKit.rowTitle(this, "Recent items", "Swipe to delete \u00b7 pinned items are protected"),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        val clearButton = TextView(this).apply {
            text = "Clear unpinned"
            setTextColor(ContextCompat.getColor(this@ClipboardActivity, R.color.tf_danger))
            setOnClickListener {
                store.clearUnpinned()
                reload()
            }
        }
        toolbarRow.addView(clearButton)
        root.addView(toolbarRow)

        emptyLabel = TextView(this).apply {
            text = "Nothing copied yet."
            gravity = Gravity.CENTER
            setPadding(0, AppUiKit.dp(this@ClipboardActivity, 48), 0, 0)
        }
        root.addView(emptyLabel)

        recyclerView = RecyclerView(this).apply { layoutManager = LinearLayoutManager(this@ClipboardActivity) }
        root.addView(recyclerView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {
            override fun onMove(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder) = false

            override fun getSwipeDirs(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder): Int {
                val position = viewHolder.bindingAdapterPosition
                if (position < 0 || position >= items.size) return 0
                return if (items[position].pinned) 0 else (ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT)
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.bindingAdapterPosition
                if (position < 0 || position >= items.size) return
                store.delete(items[position].id)
                reload()
            }

            override fun onChildDraw(
                c: Canvas, recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder,
                dX: Float, dY: Float, actionState: Int, isCurrentlyActive: Boolean
            ) {
                val background = ColorDrawable(ContextCompat.getColor(this@ClipboardActivity, R.color.tf_danger))
                background.setBounds(
                    viewHolder.itemView.left, viewHolder.itemView.top,
                    viewHolder.itemView.right, viewHolder.itemView.bottom
                )
                background.draw(c)
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
            }
        })
        touchHelper.attachToRecyclerView(recyclerView)

        reload()
    }

    private fun reload() {
        items = store.getItems()
        emptyLabel.visibility = if (items.isEmpty()) TextView.VISIBLE else TextView.GONE
        recyclerView.adapter = Adapter()
    }

    private fun showEditDialog(item: ClipboardItem) {
        val input = EditText(this).apply { setText(item.text); setSelection(text.length) }
        AlertDialog.Builder(this)
            .setTitle("Edit item")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                store.edit(item.id, input.text.toString())
                reload()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private inner class Adapter : RecyclerView.Adapter<Adapter.Holder>() {
        inner class Holder(val row: LinearLayout, val thumb: ImageView, val text: TextView, val pin: ImageView, val edit: ImageView, val delete: ImageView) :
            RecyclerView.ViewHolder(row)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val row = LinearLayout(parent.context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(ContextCompat.getColor(parent.context, R.color.tf_surface))
                val pad = AppUiKit.dp(parent.context, 12)
                setPadding(pad, pad, pad, pad)
            }
            val thumb = ImageView(parent.context).apply {
                layoutParams = LinearLayout.LayoutParams(AppUiKit.dp(parent.context, 40), AppUiKit.dp(parent.context, 40))
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
            val text = TextView(parent.context).apply {
                maxLines = 3
                setPadding(AppUiKit.dp(parent.context, 10), 0, AppUiKit.dp(parent.context, 10), 0)
            }
            val pin = ImageView(parent.context).apply { layoutParams = LinearLayout.LayoutParams(AppUiKit.dp(parent.context, 24), AppUiKit.dp(parent.context, 24)) }
            val edit = ImageView(parent.context).apply { layoutParams = LinearLayout.LayoutParams(AppUiKit.dp(parent.context, 24), AppUiKit.dp(parent.context, 24)).also { it.marginStart = AppUiKit.dp(parent.context, 12) } }
            val delete = ImageView(parent.context).apply { layoutParams = LinearLayout.LayoutParams(AppUiKit.dp(parent.context, 24), AppUiKit.dp(parent.context, 24)).also { it.marginStart = AppUiKit.dp(parent.context, 12) } }
            row.addView(thumb)
            row.addView(text, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(pin)
            row.addView(edit)
            row.addView(delete)
            return Holder(row, thumb, text, pin, edit, delete)
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val item = items[position]
            holder.text.text = if (item.isScreenshot) "Screenshot \u00b7 ${item.text}" else item.text
            holder.text.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.tf_on_surface))

            if (item.isScreenshot && item.screenshotUri != null) {
                holder.thumb.visibility = ImageView.VISIBLE
                runCatching {
                    val path = item.screenshotUri.removePrefix("file://")
                    holder.thumb.setImageBitmap(BitmapFactory.decodeFile(path))
                }
            } else {
                holder.thumb.visibility = ImageView.GONE
            }

            holder.pin.setImageResource(if (item.pinned) R.drawable.ic_pin_filled else R.drawable.ic_pin_outline)
            holder.pin.setColorFilter(ContextCompat.getColor(holder.itemView.context, if (item.pinned) R.color.tf_accent else R.color.tf_on_surface_variant))
            holder.pin.setOnClickListener { store.togglePin(item.id); reload() }

            holder.edit.setImageResource(R.drawable.ic_edit)
            holder.edit.setColorFilter(ContextCompat.getColor(holder.itemView.context, R.color.tf_on_surface_variant))
            // Pinned items must remain editable — this was a bug in an earlier build and must not regress.
            holder.edit.visibility = if (item.isScreenshot) ImageView.GONE else ImageView.VISIBLE
            holder.edit.setOnClickListener { showEditDialog(item) }

            holder.delete.setImageResource(R.drawable.ic_delete)
            holder.delete.setColorFilter(ContextCompat.getColor(holder.itemView.context, R.color.tf_danger))
            holder.delete.setOnClickListener { store.forceDelete(item.id); reload() }
        }

        override fun getItemCount(): Int = items.size
    }
}

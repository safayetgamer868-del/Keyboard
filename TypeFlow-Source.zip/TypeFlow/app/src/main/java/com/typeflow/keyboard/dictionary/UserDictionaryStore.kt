package com.typeflow.keyboard.dictionary

import android.content.Context

/**
 * User-added words, kept separate per language so switching languages never
 * mixes vocabularies. Backed by SharedPreferences string sets — simple,
 * durable, and cheap for the modest word counts a personal dictionary needs.
 */
object UserDictionaryStore {

    private const val PREFS = "typeflow_user_dictionary"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun key(languageCode: String) = "words_$languageCode"

    fun words(context: Context, languageCode: String): Set<String> =
        prefs(context).getStringSet(key(languageCode), emptySet()) ?: emptySet()

    fun addWord(context: Context, languageCode: String, word: String) {
        val trimmed = word.trim().lowercase()
        if (trimmed.isEmpty()) return
        val updated = words(context, languageCode) + trimmed
        prefs(context).edit().putStringSet(key(languageCode), updated).apply()
    }

    fun removeWord(context: Context, languageCode: String, word: String) {
        val updated = words(context, languageCode) - word.trim().lowercase()
        prefs(context).edit().putStringSet(key(languageCode), updated).apply()
    }
}

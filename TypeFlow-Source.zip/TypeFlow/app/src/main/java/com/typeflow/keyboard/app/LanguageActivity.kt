package com.typeflow.keyboard.app

import android.os.Bundle
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.RadioButton
import androidx.appcompat.app.AppCompatActivity
import com.typeflow.keyboard.languages.LanguageManager
import com.typeflow.keyboard.settings.TypeFlowSettings

class LanguageActivity : AppCompatActivity() {

    private lateinit var listContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Languages"
        val (scroll, column) = AppUiKit.screen(this)
        setContentView(scroll)
        column.addView(AppUiKit.sectionTitle(this, "ENABLED LANGUAGES \u2014 TAP THE RADIO TO MAKE ONE ACTIVE"))
        listContainer = AppUiKit.card(this)
        column.addView(listContainer)
        rebuild()
    }

    private fun rebuild() {
        listContainer.removeAllViews()
        val enabled = TypeFlowSettings.getEnabledLanguages(this)
        val active = TypeFlowSettings.getActiveLanguage(this)
        LanguageManager.ALL.forEachIndexed { index, language ->
            val row = AppUiKit.row(this)
            val radio = RadioButton(this).apply {
                isChecked = language.code == active
                isEnabled = language.code in enabled
                setOnClickListener {
                    TypeFlowSettings.setActiveLanguage(this@LanguageActivity, language.code)
                    rebuild()
                }
            }
            val checkbox = CheckBox(this).apply {
                isChecked = language.code in enabled
                setOnCheckedChangeListener { _, isChecked ->
                    val updated = enabled.toMutableSet()
                    if (isChecked) updated.add(language.code) else {
                        if (updated.size > 1) updated.remove(language.code) else return@setOnCheckedChangeListener
                    }
                    TypeFlowSettings.setEnabledLanguages(this@LanguageActivity, updated)
                    if (language.code == active && !isChecked) {
                        TypeFlowSettings.setActiveLanguage(this@LanguageActivity, updated.first())
                    }
                    rebuild()
                }
            }
            row.addView(checkbox)
            row.addView(
                AppUiKit.rowTitle(this, language.displayName, language.nativeName),
                LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also {
                    it.marginStart = AppUiKit.dp(this, 8)
                }
            )
            row.addView(radio)
            listContainer.addView(row)
            if (index != LanguageManager.ALL.lastIndex) listContainer.addView(AppUiKit.divider(this))
        }
    }
}

package com.typeflow.keyboard.writing

data class GrammarIssue(
    val start: Int,
    val end: Int,
    val message: String,
    val suggestion: String
)

/** Isolated, replaceable grammar-checking backend. [RuleBasedGrammarProvider] is the local, shipped implementation. */
interface GrammarProvider {
    fun check(text: String): List<GrammarIssue>
}

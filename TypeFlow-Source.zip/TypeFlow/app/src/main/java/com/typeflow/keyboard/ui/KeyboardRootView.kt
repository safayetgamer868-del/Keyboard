package com.typeflow.keyboard.ui

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import com.typeflow.keyboard.R
import com.typeflow.keyboard.settings.TypeFlowSettings
import com.typeflow.keyboard.themes.KeyboardTheme

/**
 * Top-level view the IME shows: suggestion bar + a content area that swaps
 * between the main key surface and one overlay panel at a time (tools,
 * emoji, clipboard, writing tools, GIFs). Also owns the one-handed side
 * controls and the floating-mode drag handle.
 */
class KeyboardRootView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {

    val keyboardView = KeyboardView(context)
    val suggestionBar = SuggestionBarView(context)
    val toolsGrid = ToolsGridView(context)
    val emojiPicker = EmojiPickerView(context)
    val clipboardPanel = ClipboardQuickPanel(context)
    val writingPanel = WritingToolPanel(context)
    val gifPicker = GifPickerView(context)

    private val dragHandle = FrameLayout(context)
    private val oneHandedControls = LinearLayout(context)
    private val contentArea = FrameLayout(context)

    var onFloatingDrag: ((dx: Float, dy: Float) -> Unit)? = null
    var onFloatingDragEnd: (() -> Unit)? = null
    var onOneHandedFlip: (() -> Unit)? = null
    var onOneHandedExit: (() -> Unit)? = null

    private var lastRawX = 0f
    private var lastRawY = 0f

    init {
        orientation = VERTICAL

        dragHandle.visibility = FrameLayout.GONE
        dragHandle.setBackgroundColor(0x22FFFFFF)
        val handleBar = android.view.View(context).apply { setBackgroundColor(0x66FFFFFF.toInt()) }
        dragHandle.addView(handleBar, FrameLayout.LayoutParams(ViewStyling.dp(context, 40), ViewStyling.dp(context, 4)).also { it.gravity = Gravity.CENTER })
        dragHandle.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lastRawX = event.rawX; lastRawY = event.rawY }
                MotionEvent.ACTION_MOVE -> {
                    onFloatingDrag?.invoke(event.rawX - lastRawX, event.rawY - lastRawY)
                    lastRawX = event.rawX; lastRawY = event.rawY
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onFloatingDragEnd?.invoke()
            }
            true
        }
        addView(dragHandle, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewStyling.dp(context, 22)))

        oneHandedControls.orientation = HORIZONTAL
        oneHandedControls.visibility = GONE
        oneHandedControls.gravity = Gravity.CENTER_VERTICAL
        addView(oneHandedControls, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewStyling.dp(context, 28)))

        addView(suggestionBar, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewStyling.dp(context, 44)))

        contentArea.addView(keyboardView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        for (panel in listOf(toolsGrid, emojiPicker, clipboardPanel, writingPanel, gifPicker)) {
            panel.visibility = FrameLayout.GONE
            contentArea.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        addView(contentArea, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        buildOneHandedControls()
    }

    private fun buildOneHandedControls() {
        oneHandedControls.removeAllViews()
        val flip = ViewStyling.iconButton(context, R.drawable.ic_one_handed, keyboardView.theme.keyText, keyboardView.theme.specialKeyBackground, keyboardView.theme, 26)
        flip.setOnClickListener { onOneHandedFlip?.invoke() }
        val exit = ViewStyling.iconButton(context, R.drawable.ic_close, keyboardView.theme.keyText, keyboardView.theme.specialKeyBackground, keyboardView.theme, 26)
        exit.setOnClickListener { onOneHandedExit?.invoke() }
        oneHandedControls.addView(flip, LayoutParams(ViewStyling.dp(context, 26), ViewStyling.dp(context, 26)).also { it.marginStart = ViewStyling.dp(context, 8) })
        oneHandedControls.addView(exit, LayoutParams(ViewStyling.dp(context, 26), ViewStyling.dp(context, 26)).also { it.marginStart = ViewStyling.dp(context, 8) })
    }

    fun applyTheme(theme: KeyboardTheme) {
        keyboardView.theme = theme
        suggestionBar.theme = theme
        toolsGrid.theme = theme
        emojiPicker.theme = theme
        clipboardPanel.theme = theme
        writingPanel.theme = theme
        gifPicker.theme = theme
        setBackgroundColor(theme.keyboardBackground)
        buildOneHandedControls()
    }

    fun setFloatingMode(enabled: Boolean) {
        dragHandle.visibility = if (enabled) FrameLayout.VISIBLE else FrameLayout.GONE
    }

    fun setOneHandedMode(mode: String) {
        keyboardView.oneHandedMode = mode
        oneHandedControls.visibility = if (mode != TypeFlowSettings.ONE_HANDED_OFF) VISIBLE else GONE
    }

    private fun showOnly(view: android.view.View) {
        keyboardView.visibility = if (view === keyboardView) FrameLayout.VISIBLE else FrameLayout.GONE
        toolsGrid.visibility = if (view === toolsGrid) FrameLayout.VISIBLE else FrameLayout.GONE
        emojiPicker.visibility = if (view === emojiPicker) FrameLayout.VISIBLE else FrameLayout.GONE
        clipboardPanel.visibility = if (view === clipboardPanel) FrameLayout.VISIBLE else FrameLayout.GONE
        writingPanel.visibility = if (view === writingPanel) FrameLayout.VISIBLE else FrameLayout.GONE
        gifPicker.visibility = if (view === gifPicker) FrameLayout.VISIBLE else FrameLayout.GONE
    }

    fun showKeys() = showOnly(keyboardView)
    fun showTools(canUndo: Boolean, canRedo: Boolean) { toolsGrid.refresh(canUndo, canRedo); showOnly(toolsGrid) }
    fun showEmoji() { emojiPicker.refresh(); showOnly(emojiPicker) }
    fun showClipboard() { clipboardPanel.refresh(); showOnly(clipboardPanel) }
    fun showGif() { gifPicker.reset(); showOnly(gifPicker) }
    fun showWriting(mode: WritingMode, currentText: String, languages: List<Pair<String, String>>) {
        writingPanel.configure(mode, currentText, languages)
        showOnly(writingPanel)
    }
}

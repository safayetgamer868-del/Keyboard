package com.typeflow.keyboard.writing

/**
 * Real, deterministic text transformations per tone — not a static canned
 * response. Each tone applies a genuinely different set of rewrite rules to
 * whatever text is passed in. This is explicitly a local/rule-based provider;
 * [ToneRewriteProvider] is the seam a future LLM-backed provider plugs into.
 */
class TemplateToneProvider : ToneRewriteProvider {

    private val contractionsExpanded = mapOf(
        "don't" to "do not", "can't" to "cannot", "won't" to "will not", "i'm" to "I am",
        "it's" to "it is", "that's" to "that is", "you're" to "you are", "i've" to "I have",
        "we're" to "we are", "isn't" to "is not", "aren't" to "are not", "didn't" to "did not",
        "wasn't" to "was not", "haven't" to "have not", "gonna" to "going to", "wanna" to "want to"
    )
    private val contractionsCasual = mapOf(
        "do not" to "don't", "cannot" to "can't", "will not" to "won't", "I am" to "I'm",
        "it is" to "it's", "that is" to "that's", "you are" to "you're", "I have" to "I've",
        "we are" to "we're", "is not" to "isn't", "are not" to "aren't"
    )
    private val fillerWords = listOf(
        "just ", "really ", "very ", "actually ", "basically ", "honestly ", "kind of ", "sort of "
    )
    private val wordyPhrases = mapOf(
        "in order to" to "to", "at this point in time" to "now", "due to the fact that" to "because",
        "in the event that" to "if", "a large number of" to "many"
    )

    override fun rewrite(text: String, tone: RewriteTone): String {
        if (text.isBlank()) return text
        return when (tone) {
            RewriteTone.PROFESSIONAL -> professional(text)
            RewriteTone.FRIENDLY -> friendly(text)
            RewriteTone.CASUAL -> casual(text)
            RewriteTone.CONCISE -> concise(text)
        }
    }

    private fun professional(text: String): String {
        var result = replaceWords(text, contractionsExpanded)
        result = result.replace(Regex("!+"), ".")
        result = capitalizeSentences(result)
        if (result.isNotEmpty() && result.last() !in ".!?") result += "."
        return result.trim()
    }

    private fun friendly(text: String): String {
        var result = capitalizeSentences(text)
        if (result.isNotEmpty() && result.last() !in "!?") {
            result = result.trimEnd('.') + "!"
        }
        return result.trim()
    }

    private fun casual(text: String): String {
        var result = replaceWords(text, contractionsCasual)
        result = result.trim().trimEnd('.')
        return result
    }

    private fun concise(text: String): String {
        var result = text
        wordyPhrases.forEach { (long, short) -> result = result.replace(long, short, ignoreCase = true) }
        fillerWords.forEach { filler -> result = result.replace(filler, "", ignoreCase = true) }
        result = result.replace(Regex(" {2,}"), " ")
        return capitalizeSentences(result).trim()
    }

    private fun replaceWords(text: String, map: Map<String, String>): String {
        var result = text
        for ((from, to) in map) {
            result = Regex("\\b${Regex.escape(from)}\\b", RegexOption.IGNORE_CASE).replace(result, to)
        }
        return result
    }

    private fun capitalizeSentences(text: String): String {
        if (text.isEmpty()) return text
        val chars = text.toCharArray()
        var capitalizeNext = true
        for (i in chars.indices) {
            if (capitalizeNext && chars[i].isLetter()) {
                chars[i] = chars[i].uppercaseChar()
                capitalizeNext = false
            } else if (chars[i] in ".!?") {
                capitalizeNext = true
            } else if (!chars[i].isWhitespace() && capitalizeNext && !chars[i].isLetter()) {
                // punctuation right after sentence end (e.g. quote) — keep waiting for a letter
            }
        }
        return String(chars)
    }
}

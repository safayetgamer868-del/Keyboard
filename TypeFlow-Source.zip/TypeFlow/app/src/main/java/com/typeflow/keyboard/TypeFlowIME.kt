package com.typeflow.keyboard

import android.content.Intent
import android.content.SharedPreferences
import android.inputmethodservice.InputMethodService
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import com.typeflow.keyboard.app.MainActivity
import com.typeflow.keyboard.clipboard.ClipboardMonitor
import com.typeflow.keyboard.clipboard.ScreenshotWatcher
import com.typeflow.keyboard.core.KeyLayouts
import com.typeflow.keyboard.core.TextEditingController
import com.typeflow.keyboard.core.UndoRedoManager
import com.typeflow.keyboard.dictionary.DictionaryProvider
import com.typeflow.keyboard.gif.TenorGifProvider
import com.typeflow.keyboard.glide.GlideTypingEngine
import com.typeflow.keyboard.languages.LanguageManager
import com.typeflow.keyboard.settings.TypeFlowSettings
import com.typeflow.keyboard.suggestions.AutoCorrectEngine
import com.typeflow.keyboard.suggestions.SuggestionEngine
import com.typeflow.keyboard.themes.ThemeManager
import com.typeflow.keyboard.ui.FloatingKeyboardController
import com.typeflow.keyboard.ui.KeyboardActionListener
import com.typeflow.keyboard.ui.KeyboardMode
import com.typeflow.keyboard.ui.KeyboardRootView
import com.typeflow.keyboard.ui.ToolAction
import com.typeflow.keyboard.ui.WritingMode
import com.typeflow.keyboard.voice.VoiceState
import com.typeflow.keyboard.voice.VoiceTypingManager
import com.typeflow.keyboard.writing.GrammarIssue
import com.typeflow.keyboard.writing.HttpTranslationProvider
import com.typeflow.keyboard.writing.RuleBasedGrammarProvider
import com.typeflow.keyboard.writing.TemplateToneProvider
import com.typeflow.keyboard.writing.TranslationResult

class TypeFlowIME : InputMethodService(), KeyboardActionListener {

    private lateinit var rootView: KeyboardRootView
    private lateinit var themeManager: ThemeManager
    private val undoRedo = UndoRedoManager()
    private val textEditor = TextEditingController(undoRedo)
    private val suggestionEngine = SuggestionEngine()
    private val autoCorrectEngine = AutoCorrectEngine()
    private val grammarProvider = RuleBasedGrammarProvider()
    private val toneProvider = TemplateToneProvider()
    private lateinit var translationProvider: HttpTranslationProvider
    private lateinit var gifProvider: TenorGifProvider
    private lateinit var clipboardMonitor: ClipboardMonitor
    private lateinit var screenshotWatcher: ScreenshotWatcher
    private lateinit var floatingController: FloatingKeyboardController
    private var voiceManager: VoiceTypingManager? = null

    /** Captured original text (and its before/after cursor lengths) while a writing-tool panel is open. */
    private var pendingWritingBeforeLen = 0
    private var pendingWritingAfterLen = 0
    private var pendingWritingOriginal = ""

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        applySettingsToView()
    }

    private fun ic(): InputConnection? = currentInputConnection

    override fun onCreate() {
        super.onCreate()
        themeManager = ThemeManager(this)
        translationProvider = HttpTranslationProvider(this)
        gifProvider = TenorGifProvider(this)
        clipboardMonitor = ClipboardMonitor(this)
        screenshotWatcher = ScreenshotWatcher(this)
        floatingController = FloatingKeyboardController(this)
        TypeFlowSettings.registerListener(this, prefsListener)
    }

    override fun onDestroy() {
        TypeFlowSettings.unregisterListener(this, prefsListener)
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        rootView = KeyboardRootView(this)
        rootView.keyboardView.actionListener = this
        rootView.keyboardView.setLayoutRows(KeyLayouts.qwertyRows())

        rootView.toolsGrid.onAction = { action -> handleToolAction(action) }
        rootView.emojiPicker.onEmojiPicked = { emoji -> textEditor.commitText(ic(), emoji) }
        rootView.emojiPicker.onBackRequested = { rootView.showKeys() }
        rootView.emojiPicker.onBackspace = { textEditor.deleteBeforeCursor(ic(), 1) }
        rootView.clipboardPanel.onInsert = { text -> textEditor.commitText(ic(), text); rootView.showKeys() }
        rootView.clipboardPanel.onBackRequested = { rootView.showKeys() }
        rootView.gifPicker.provider = gifProvider
        rootView.gifPicker.onBackRequested = { rootView.showKeys() }
        rootView.gifPicker.onGifPicked = { gif -> textEditor.commitText(ic(), gif.fullUrl); rootView.showKeys() }
        rootView.writingPanel.onBackRequested = { rootView.showKeys() }
        rootView.writingPanel.onInsert = { newText -> applyWritingResult(newText) }
        rootView.writingPanel.onTranslateRequested = { targetCode -> runTranslate(targetCode) }
        rootView.writingPanel.onGrammarCheckRequested = { runGrammarCheck() }
        rootView.writingPanel.onToneRequested = { tone -> rootView.writingPanel.showResult(toneProvider.rewrite(pendingWritingOriginal, tone)) }

        rootView.onOneHandedFlip = {
            val next = when (TypeFlowSettings.getOneHandedMode(this)) {
                TypeFlowSettings.ONE_HANDED_LEFT -> TypeFlowSettings.ONE_HANDED_RIGHT
                else -> TypeFlowSettings.ONE_HANDED_LEFT
            }
            TypeFlowSettings.setOneHandedMode(this, next)
        }
        rootView.onOneHandedExit = { TypeFlowSettings.setOneHandedMode(this, TypeFlowSettings.ONE_HANDED_OFF) }
        rootView.onFloatingDrag = { dx, dy -> floatingController.moveBy(dx, dy) }
        rootView.onFloatingDragEnd = { floatingController.persistCurrentPosition() }

        applySettingsToView()
        return rootView
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        undoRedo.reset()
        rootView.showKeys()
        applySettingsToView()
        clipboardMonitor.start()
        screenshotWatcher.start()
        updateSuggestions()

        if (TypeFlowSettings.isFloatingEnabled(this)) {
            val metrics = resources.displayMetrics
            window?.window?.let { w ->
                floatingController.enable(w, (metrics.widthPixels * 0.9f).toInt(), (metrics.heightPixels * 0.42f).toInt())
            }
        }
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        clipboardMonitor.stop()
        screenshotWatcher.stop()
        voiceManager?.stop()
        if (TypeFlowSettings.isFloatingEnabled(this)) {
            window?.window?.let { floatingController.disable(it) }
        }
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        // A selection jump we didn't just cause ourselves (user tapped elsewhere) invalidates our undo history,
        // since it no longer refers to a contiguous edit at the current cursor.
        if (kotlin.math.abs(newSelStart - oldSelEnd) > 1) {
            undoRedo.reset()
        }
        updateSuggestions()
    }

    private fun applySettingsToView() {
        if (!::rootView.isInitialized) return
        val theme = themeManager.current()
        rootView.applyTheme(theme)
        rootView.keyboardView.numberRowEnabled = TypeFlowSettings.isNumberRowEnabled(this)
        rootView.keyboardView.heightPercent = TypeFlowSettings.getHeightPercent(this)
        rootView.keyboardView.glideTypingEnabled = TypeFlowSettings.isGlideTypingEnabled(this)
        rootView.keyboardView.soundEnabled = TypeFlowSettings.isKeySoundEnabled(this)
        rootView.keyboardView.vibrateEnabled = TypeFlowSettings.isKeyVibrateEnabled(this)
        rootView.setOneHandedMode(TypeFlowSettings.getOneHandedMode(this))
        rootView.setFloatingMode(TypeFlowSettings.isFloatingEnabled(this))
    }

    // ------------------------------------------------------------ KeyboardActionListener

    override fun onCharacter(char: String) {
        textEditor.commitText(ic(), char)
        updateSuggestions()
    }

    override fun onShiftTapped() { /* visual state already handled by KeyboardView */ }
    override fun onShiftDoubleTapped() { /* caps lock — no text-side effect needed */ }

    override fun onBackspaceTick() {
        textEditor.deleteBeforeCursor(ic(), 1)
        updateSuggestions()
    }

    override fun onEnter() {
        val info = currentInputEditorInfo
        val action = info?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
        val noEnterFlag = info?.imeOptions?.and(EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (info != null && action != null && action != EditorInfo.IME_ACTION_NONE && !noEnterFlag) {
            ic()?.performEditorAction(action)
        } else {
            ic()?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic()?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
        undoRedo.reset() // a newline usually starts a logically new edit region
    }

    override fun onSpace() {
        applyPendingAutoCorrect()
        textEditor.commitText(ic(), " ")
        updateSuggestions()
    }

    override fun onSwitchToNumbers() { rootView.suggestionBar.clear() }
    override fun onSwitchToLetters() { updateSuggestions() }
    override fun onSwitchToSymbols() { rootView.keyboardView.mode = KeyboardMode.LETTERS }

    override fun onEmojiRequested() { rootView.showEmoji() }
    override fun onToolsRequested() { rootView.showTools(textEditor.canUndo(), textEditor.canRedo()) }

    override fun onLanguageSwitchRequested() {
        LanguageManager.cycleActive(this)
        updateSuggestions()
    }

    override fun onSymbol(value: String) {
        textEditor.commitText(ic(), value)
        updateSuggestions()
    }

    override fun onGlideWordCommitted(keySequence: String) {
        val language = LanguageManager.active(this)
        val dictionary = DictionaryProvider.wordsFor(this, language)
        val candidates = GlideTypingEngine.candidatesFor(keySequence, dictionary, maxResults = 1)
        val best = candidates.firstOrNull() ?: return // honest: no invented word when nothing matches well
        textEditor.commitText(ic(), "$best ")
        updateSuggestions()
    }

    override fun onKeyPreview(label: String?) { /* reserved for a future floating key-preview bubble */ }

    // ------------------------------------------------------------ tools

    private fun handleToolAction(action: ToolAction) {
        when (action) {
            ToolAction.UNDO -> { textEditor.undo(ic()); updateSuggestions() }
            ToolAction.REDO -> { textEditor.redo(ic()); updateSuggestions() }
            ToolAction.CLIPBOARD -> rootView.showClipboard()
            ToolAction.TRANSLATE -> openWriting(WritingMode.TRANSLATE)
            ToolAction.GRAMMAR -> openWriting(WritingMode.GRAMMAR)
            ToolAction.TONE -> openWriting(WritingMode.TONE)
            ToolAction.GIF -> rootView.showGif()
            ToolAction.VOICE -> startVoiceTyping()
            ToolAction.SETTINGS -> openAppSettings()
            ToolAction.BACK -> rootView.showKeys()
        }
    }

    private fun openAppSettings() {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        startActivity(intent)
    }

    private fun startVoiceTyping() {
        rootView.showKeys()
        if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
            != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            val intent = Intent(this, com.typeflow.keyboard.ime.PermissionActivity::class.java).apply {
                putExtra(com.typeflow.keyboard.ime.PermissionActivity.EXTRA_PERMISSION, android.Manifest.permission.RECORD_AUDIO)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            rootView.suggestionBar.setSuggestions(listOf("Grant microphone access, then try Voice again"), null) {}
            return
        }
        val manager = VoiceTypingManager(this) { state ->
            when (state) {
                is VoiceState.Listening -> rootView.suggestionBar.setSuggestions(listOf("Listening\u2026"), null) {}
                is VoiceState.Result -> {
                    textEditor.commitText(ic(), state.text + " ")
                    updateSuggestions()
                }
                is VoiceState.Error -> rootView.suggestionBar.setSuggestions(listOf(state.message), null) {}
                else -> Unit
            }
        }
        voiceManager = manager
        manager.start()
    }

    // ------------------------------------------------------------ writing tools

    private fun openWriting(mode: WritingMode) {
        val connection = ic()
        val before = connection?.getTextBeforeCursor(2000, 0)?.toString().orEmpty()
        val after = connection?.getTextAfterCursor(2000, 0)?.toString().orEmpty()
        pendingWritingBeforeLen = before.length
        pendingWritingAfterLen = after.length
        pendingWritingOriginal = before + after

        val languageOptions = LanguageManager.ALL
            .filterNot { it.code == LanguageManager.active(this).code }
            .map { it.code to it.displayName }
        rootView.showWriting(mode, pendingWritingOriginal, languageOptions)
    }

    private fun runTranslate(targetCode: String) {
        translationProvider.translate(pendingWritingOriginal, targetCode) { result ->
            when (result) {
                is TranslationResult.Success -> rootView.writingPanel.showResult(result.translatedText)
                is TranslationResult.Error -> rootView.writingPanel.showError(result.message)
            }
        }
    }

    private fun runGrammarCheck() {
        val issues = grammarProvider.check(pendingWritingOriginal)
        if (issues.isEmpty()) {
            rootView.writingPanel.showResult(pendingWritingOriginal)
            return
        }
        rootView.writingPanel.showResult(applyGrammarFixes(pendingWritingOriginal, issues))
    }

    /** Applies every fix from the end of the text backward so earlier offsets stay valid. */
    private fun applyGrammarFixes(text: String, issues: List<GrammarIssue>): String {
        var result = text
        for (issue in issues.sortedByDescending { it.start }) {
            if (issue.start in 0..result.length && issue.end in issue.start..result.length) {
                result = result.substring(0, issue.start) + issue.suggestion + result.substring(issue.end)
            }
        }
        return result
    }

    private fun applyWritingResult(newText: String) {
        textEditor.replaceSurroundingText(ic(), pendingWritingBeforeLen, pendingWritingAfterLen, pendingWritingOriginal, newText)
        rootView.showKeys()
        updateSuggestions()
    }

    // ------------------------------------------------------------ suggestions / autocorrect

    private fun applyPendingAutoCorrect() {
        val connection = ic() ?: return
        val currentWord = currentWordBeforeCursor(connection)
        if (currentWord.isBlank()) return
        val language = LanguageManager.active(this)
        val correction = autoCorrectEngine.correctionFor(this, language, currentWord) ?: return
        textEditor.replaceBeforeCursor(connection, currentWord.length, correction)
    }

    private fun updateSuggestions() {
        if (!::rootView.isInitialized) return
        val connection = ic()
        if (connection == null) {
            rootView.suggestionBar.clear()
            return
        }
        if (!TypeFlowSettings.isSuggestionsEnabled(this)) {
            rootView.suggestionBar.clear()
            return
        }
        val language = LanguageManager.active(this)
        val currentWord = currentWordBeforeCursor(connection)
        val previousWord = if (currentWord.isBlank()) wordBeforeCurrentWord(connection) else null
        val suggestions = suggestionEngine.suggest(this, language, currentWord, previousWord)
        val autocorrectPreview = if (currentWord.isNotBlank()) autoCorrectEngine.correctionFor(this, language, currentWord) else null

        rootView.suggestionBar.setSuggestions(suggestions, autocorrectPreview) { picked ->
            if (currentWord.isNotBlank()) {
                textEditor.replaceBeforeCursor(connection, currentWord.length, "$picked ")
            } else {
                textEditor.commitText(connection, "$picked ")
            }
            updateSuggestions()
        }
    }

    private fun currentWordBeforeCursor(connection: InputConnection): String {
        val text = connection.getTextBeforeCursor(64, 0)?.toString().orEmpty()
        val match = Regex("[\\p{L}']+$").find(text)
        return match?.value.orEmpty()
    }

    private fun wordBeforeCurrentWord(connection: InputConnection): String? {
        val text = connection.getTextBeforeCursor(128, 0)?.toString().orEmpty().trimEnd()
        val match = Regex("[\\p{L}']+$").find(text)
        return match?.value
    }
}

package com.typeflow.keyboard.suggestions

import android.content.Context
import com.typeflow.keyboard.languages.Language

/**
 * A pluggable source of suggestion candidates. [LocalDictionaryProvider] is
 * the shipped implementation; the interface exists so a future on-device ML
 * model can be dropped in without touching the keyboard or suggestion bar.
 */
interface SuggestionProvider {
    /**
     * @param currentWord the word currently being typed (may be empty right after a space)
     * @param previousWord the word before it, for next-word prediction
     */
    fun suggestionsFor(
        context: Context,
        language: Language,
        currentWord: String,
        previousWord: String?
    ): List<String>
}

/** Coordinates the active [SuggestionProvider] and exposes a simple facade to the IME. */
class SuggestionEngine(private val provider: SuggestionProvider = LocalDictionaryProvider()) {

    fun suggest(
        context: Context,
        language: Language,
        currentWord: String,
        previousWord: String?,
        maxResults: Int = 3
    ): List<String> = provider.suggestionsFor(context, language, currentWord, previousWord).take(maxResults)
}

package com.typeflow.keyboard.writing

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.typeflow.keyboard.settings.TypeFlowSettings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Calls a user-configured LibreTranslate-compatible HTTP endpoint
 * (`POST {endpoint}/translate`, JSON body `{q, source, target, format}`).
 *
 * No endpoint or API key is hardcoded — translation only works once the user
 * sets a real endpoint in Settings > Writing Assistance, so this never fakes
 * a result or silently returns the input text as if it were translated.
 */
class HttpTranslationProvider(private val context: Context) : TranslationProvider {

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun translate(text: String, targetLanguageCode: String, callback: (TranslationResult) -> Unit) {
        val endpoint = TypeFlowSettings.getTranslateEndpoint(context).trim()
        if (endpoint.isEmpty()) {
            deliver(callback, TranslationResult.Error("No translation server is configured. Add one in Settings > Writing Assistance."))
            return
        }
        if (text.isBlank()) {
            deliver(callback, TranslationResult.Error("Nothing to translate."))
            return
        }

        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                val url = URL(endpoint.trimEnd('/') + "/translate")
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 8000
                    readTimeout = 8000
                    setRequestProperty("Content-Type", "application/json")
                }
                val body = JSONObject().apply {
                    put("q", text)
                    put("source", "auto")
                    put("target", targetLanguageCode)
                    put("format", "text")
                }
                connection.outputStream.use { it.write(body.toString().toByteArray()) }

                val code = connection.responseCode
                if (code in 200..299) {
                    val response = connection.inputStream.bufferedReader().readText()
                    val translated = JSONObject(response).optString("translatedText", "")
                    if (translated.isNotEmpty()) {
                        deliver(callback, TranslationResult.Success(translated))
                    } else {
                        deliver(callback, TranslationResult.Error("Translation server returned an empty result."))
                    }
                } else {
                    deliver(callback, TranslationResult.Error("Translation server error (HTTP $code)."))
                }
            } catch (t: Throwable) {
                deliver(callback, TranslationResult.Error("Couldn't reach the translation server: ${t.message ?: "unknown error"}"))
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun deliver(callback: (TranslationResult) -> Unit, result: TranslationResult) {
        mainHandler.post { callback(result) }
    }
}

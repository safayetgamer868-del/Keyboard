package com.typeflow.keyboard.ui

/** Everything the keyboard's key layer can ask the IME to do. Keeps KeyboardView free of InputConnection logic. */
interface KeyboardActionListener {
    fun onCharacter(char: String)
    fun onShiftTapped()
    fun onShiftDoubleTapped()
    fun onBackspaceTick()
    fun onEnter()
    fun onSpace()
    fun onSwitchToNumbers()
    fun onSwitchToLetters()
    fun onSwitchToSymbols()
    fun onEmojiRequested()
    fun onToolsRequested()
    fun onLanguageSwitchRequested()
    fun onSymbol(value: String)
    fun onGlideWordCommitted(word: String)
    fun onKeyPreview(label: String?)
}

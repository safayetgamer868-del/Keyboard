package com.typeflow.keyboard.gif

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.typeflow.keyboard.settings.TypeFlowSettings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/**
 * Real Tenor v2 API client (`https://tenor.googleapis.com/v2/search`).
 * Requires the user's own API key (Settings > Emoji & GIFs) — no key is
 * bundled with the app, and no results are fabricated when it's missing or
 * the network call fails; the caller gets a clear [GifSearchResponse.Error].
 */
class TenorGifProvider(private val context: Context) : GifProvider {

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun search(query: String, callback: (GifSearchResponse) -> Unit) {
        val apiKey = TypeFlowSettings.getGifApiKey(context).trim()
        if (apiKey.isEmpty()) {
            deliver(callback, GifSearchResponse.Error("No Tenor API key set. Add one in Settings > Emoji & GIFs."))
            return
        }

        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                val encodedQuery = URLEncoder.encode(query, "UTF-8")
                val url = URL(
                    "https://tenor.googleapis.com/v2/search?q=$encodedQuery&key=$apiKey&client_key=typeflow&limit=24&media_filter=tinygif"
                )
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 8000
                    readTimeout = 8000
                }
                val code = connection.responseCode
                if (code !in 200..299) {
                    deliver(callback, GifSearchResponse.Error("GIF search failed (HTTP $code)."))
                    return@execute
                }
                val body = connection.inputStream.bufferedReader().readText()
                val root = JSONObject(body)
                val results = root.optJSONArray("results") ?: return@execute deliver(
                    callback, GifSearchResponse.Success(emptyList())
                )
                val parsed = mutableListOf<GifResult>()
                for (i in 0 until results.length()) {
                    val item = results.getJSONObject(i)
                    val mediaFormats = item.optJSONObject("media_formats") ?: continue
                    val tiny = mediaFormats.optJSONObject("tinygif")
                    val full = mediaFormats.optJSONObject("gif") ?: tiny
                    val previewUrl = tiny?.optString("url") ?: continue
                    val fullUrl = full?.optString("url") ?: previewUrl
                    parsed.add(GifResult(id = item.optString("id", i.toString()), previewUrl = previewUrl, fullUrl = fullUrl))
                }
                deliver(callback, GifSearchResponse.Success(parsed))
            } catch (t: Throwable) {
                deliver(callback, GifSearchResponse.Error("Couldn't reach Tenor: ${t.message ?: "unknown error"}"))
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun deliver(callback: (GifSearchResponse) -> Unit, response: GifSearchResponse) {
        mainHandler.post { callback(response) }
    }
}

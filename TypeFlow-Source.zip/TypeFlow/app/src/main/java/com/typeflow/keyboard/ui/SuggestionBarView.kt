package com.typeflow.keyboard.ui

import android.content.Context
import android.util.AttributeSet
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import com.typeflow.keyboard.themes.KeyboardTheme

/**
 * The strip above the keys showing live suggestions/next-word predictions
 * and, when relevant, an autocorrect preview. Tapping any chip inserts it.
 */
class SuggestionBarView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : HorizontalScrollView(context, attrs) {

    private val row = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        val pad = ViewStyling.dp(context, 6)
        setPadding(pad, pad, pad, pad)
    }

    var theme: KeyboardTheme = com.typeflow.keyboard.themes.ThemeRepository.MIDNIGHT
        set(value) { field = value; setBackgroundColor(value.suggestionBarBackground) }

    init {
        isHorizontalScrollBarEnabled = false
        addView(
            row,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT)
        )
        setBackgroundColor(theme.suggestionBarBackground)
    }

    fun setSuggestions(suggestions: List<String>, autocorrectPreview: String?, onPick: (String) -> Unit) {
        row.removeAllViews()
        scrollTo(0, 0)

        if (autocorrectPreview != null) {
            val chip = ViewStyling.chip(context, "\u2192 $autocorrectPreview", theme, emphasize = true)
            chip.setOnClickListener { onPick(autocorrectPreview) }
            row.addView(chip)
        }

        for (word in suggestions) {
            val chip = ViewStyling.chip(context, word, theme)
            chip.setOnClickListener { onPick(word) }
            row.addView(chip)
        }
    }

    fun clear() {
        row.removeAllViews()
    }
}

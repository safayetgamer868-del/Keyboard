package com.typeflow.keyboard.ui

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.core.view.setPadding
import com.typeflow.keyboard.themes.KeyboardTheme

/** Small shared helpers so every panel button/chip looks consistent without a Button's default chrome. */
object ViewStyling {

    fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    fun pillBackground(theme: KeyboardTheme, fill: Int, radiusDp: Int = 18): android.graphics.drawable.Drawable {
        val shape = GradientDrawable().apply {
            cornerRadius = radiusDp.toFloat()
            setColor(fill)
        }
        val mask = GradientDrawable().apply {
            cornerRadius = radiusDp.toFloat()
            setColor(android.graphics.Color.WHITE)
        }
        return RippleDrawable(android.content.res.ColorStateList.valueOf(theme.accent and 0x55FFFFFF), shape, mask)
    }

    fun circleBackground(theme: KeyboardTheme, fill: Int): android.graphics.drawable.Drawable {
        val shape = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fill)
        }
        val mask = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(android.graphics.Color.WHITE)
        }
        return RippleDrawable(android.content.res.ColorStateList.valueOf(theme.accent and 0x55FFFFFF), shape, mask)
    }

    fun iconButton(context: Context, iconRes: Int, tint: Int, backgroundFill: Int, theme: KeyboardTheme, sizeDp: Int = 40): ImageView {
        return ImageView(context).apply {
            val d = ContextCompat.getDrawable(context, iconRes)!!.mutate()
            DrawableCompat.setTint(d, tint)
            setImageDrawable(d)
            val size = dp(context, sizeDp)
            layoutParams = android.view.ViewGroup.MarginLayoutParams(size, size)
            background = circleBackground(theme, backgroundFill)
            setPadding(dp(context, 8))
            scaleType = ImageView.ScaleType.FIT_CENTER
            isClickable = true
            isFocusable = true
        }
    }

    fun chip(context: Context, text: String, theme: KeyboardTheme, emphasize: Boolean = false): TextView {
        return TextView(context).apply {
            this.text = text
            setTextColor(if (emphasize) theme.suggestionAccentText else theme.suggestionText)
            textSize = 15f
            setPadding(dp(context, 14), dp(context, 8), dp(context, 14), dp(context, 8))
            background = pillBackground(theme, if (emphasize) (theme.accent and 0x22FFFFFF) else android.graphics.Color.TRANSPARENT)
            isClickable = true
            isFocusable = true
            maxLines = 1
        }
    }

    fun label(context: Context, text: String, theme: KeyboardTheme, sizeSp: Float = 12f): TextView {
        return TextView(context).apply {
            this.text = text
            setTextColor(theme.keyTextSecondary)
            textSize = sizeSp
            gravity = android.view.Gravity.CENTER
        }
    }
}

package com.typeflow.keyboard.themes

import androidx.annotation.ColorInt

/**
 * A fully self-contained visual style for the keyboard.
 *
 * Every color/metric the keyboard renders with comes from a [KeyboardTheme]
 * instance — no colors are hardcoded in [com.typeflow.keyboard.ui.KeyboardView]
 * or elsewhere, so adding a new theme never requires touching keyboard logic.
 */
data class KeyboardTheme(
    val id: String,
    val displayName: String,
    val isDark: Boolean,
    @ColorInt val keyboardBackground: Int,
    @ColorInt val keyBackground: Int,
    @ColorInt val keyBackgroundPressed: Int,
    @ColorInt val specialKeyBackground: Int,
    @ColorInt val specialKeyBackgroundPressed: Int,
    @ColorInt val keyText: Int,
    @ColorInt val keyTextSecondary: Int,
    @ColorInt val accent: Int,
    @ColorInt val suggestionBarBackground: Int,
    @ColorInt val suggestionText: Int,
    @ColorInt val suggestionAccentText: Int,
    @ColorInt val divider: Int,
    /** 0 = square keys, 1 = fully pill-shaped keys. */
    val keyCornerRadiusDp: Float = 6f,
    /** 0f = fully transparent keys, 1f = fully opaque. */
    val keyOpacity: Float = 1f,
    /** 0f = fully transparent keyboard background, 1f = fully opaque. */
    val keyboardOpacity: Float = 1f,
    val showKeyBorders: Boolean = false,
    @ColorInt val keyBorderColor: Int = keyBackground
) {
    companion object {
        const val CUSTOM_ID_PREFIX = "custom_"
    }
}

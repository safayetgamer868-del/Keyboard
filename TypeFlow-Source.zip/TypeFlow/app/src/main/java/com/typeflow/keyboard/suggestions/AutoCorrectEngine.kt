package com.typeflow.keyboard.suggestions

import android.content.Context
import com.typeflow.keyboard.dictionary.DictionaryProvider
import com.typeflow.keyboard.languages.Language
import com.typeflow.keyboard.settings.TypeFlowSettings
import kotlin.math.min

/**
 * Dictionary + edit-distance based autocorrect. Deliberately conservative by
 * default (max edit distance 1, same starting letter) so it doesn't mangle
 * names or intentional words; "aggressive" mode widens the search.
 */
class AutoCorrectEngine {

    /**
     * Returns a correction for [word], or null if none applies (word already
     * known, too short, capitalized like a proper noun, or no close match).
     */
    fun correctionFor(context: Context, language: Language, word: String): String? {
        if (!TypeFlowSettings.isAutoCorrectEnabled(context)) return null
        if (word.length < 3) return null
        if (word.firstOrNull()?.isUpperCase() == true) return null // avoid mangling names/proper nouns
        if (word.any { it.isDigit() }) return null

        val lower = word.lowercase()
        val dictionary = DictionaryProvider.wordsFor(context, language)
        if (dictionary.contains(lower)) return null // already a real word — leave it alone

        val maxDistance = if (TypeFlowSettings.isAutoCorrectAggressive(context)) 2 else 1
        var best: String? = null
        var bestDistance = Int.MAX_VALUE
        var bestRank = Int.MAX_VALUE

        for ((rank, candidate) in dictionary.withIndex()) {
            if (candidate.isEmpty() || candidate[0] != lower[0]) continue
            if (Math.abs(candidate.length - lower.length) > maxDistance) continue
            val distance = levenshtein(lower, candidate, maxDistance)
            if (distance in 1..maxDistance && (distance < bestDistance || (distance == bestDistance && rank < bestRank))) {
                best = candidate
                bestDistance = distance
                bestRank = rank
            }
        }
        return best
    }

    /** Bounded Levenshtein distance; returns maxDistance + 1 early once exceeded (cheap short-circuit). */
    private fun levenshtein(a: String, b: String, maxDistance: Int): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) {
            var rowMin = Int.MAX_VALUE
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[i][j] = min(min(dp[i - 1][j] + 1, dp[i][j - 1] + 1), dp[i - 1][j - 1] + cost)
                rowMin = min(rowMin, dp[i][j])
            }
            if (rowMin > maxDistance) return maxDistance + 1
        }
        return dp[a.length][b.length]
    }
}

package com.typeflow.keyboard.ui

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.typeflow.keyboard.R
import com.typeflow.keyboard.gif.BitmapLoader
import com.typeflow.keyboard.gif.GifProvider
import com.typeflow.keyboard.gif.GifResult
import com.typeflow.keyboard.gif.GifSearchResponse
import com.typeflow.keyboard.themes.KeyboardTheme

/** Real GIF search UI backed by [GifProvider] — shows a clear message instead of fake results when unavailable. */
class GifPickerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {

    var theme: KeyboardTheme = com.typeflow.keyboard.themes.ThemeRepository.MIDNIGHT
        set(value) { field = value; setBackgroundColor(value.keyboardBackground) }

    var provider: GifProvider? = null
    var onGifPicked: ((GifResult) -> Unit)? = null
    var onBackRequested: (() -> Unit)? = null

    private val searchField: EditText
    private val recyclerView = RecyclerView(context)
    private val statusText: TextView

    init {
        orientation = VERTICAL
        setBackgroundColor(theme.keyboardBackground)

        val header = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL }
        val back = ViewStyling.iconButton(context, R.drawable.ic_arrow_back, theme.keyText, theme.specialKeyBackground, theme, 34)
        back.setOnClickListener { onBackRequested?.invoke() }
        searchField = EditText(context).apply {
            hint = "Search GIFs"
            setSingleLine()
            setTextColor(theme.keyText)
            setHintTextColor(theme.keyTextSecondary)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, _, _ -> performSearch(); true }
        }
        header.addView(back, LayoutParams(ViewStyling.dp(context, 34), ViewStyling.dp(context, 34)).also { it.marginStart = ViewStyling.dp(context, 8) })
        header.addView(searchField, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also { it.marginStart = ViewStyling.dp(context, 8); it.marginEnd = ViewStyling.dp(context, 8) })
        addView(header, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewStyling.dp(context, 44)))

        statusText = TextView(context).apply {
            gravity = Gravity.CENTER
            setPadding(ViewStyling.dp(context, 16), ViewStyling.dp(context, 16), ViewStyling.dp(context, 16), ViewStyling.dp(context, 16))
        }
        addView(statusText, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        recyclerView.layoutManager = GridLayoutManager(context, 3)
        addView(recyclerView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    fun reset() {
        statusText.setTextColor(theme.keyTextSecondary)
        statusText.text = "Search for a GIF above."
        recyclerView.adapter = null
    }

    private fun performSearch() {
        val query = searchField.text.toString().trim()
        if (query.isEmpty()) return
        statusText.text = "Searching\u2026"
        statusText.setTextColor(theme.keyTextSecondary)
        provider?.search(query) { response ->
            when (response) {
                is GifSearchResponse.Success -> {
                    if (response.results.isEmpty()) {
                        statusText.text = "No results for \u201C$query\u201D."
                        recyclerView.adapter = null
                    } else {
                        statusText.text = ""
                        recyclerView.adapter = Adapter(response.results) { onGifPicked?.invoke(it) }
                    }
                }
                is GifSearchResponse.Error -> {
                    statusText.setTextColor(theme.suggestionAccentText)
                    statusText.text = response.message
                    recyclerView.adapter = null
                }
            }
        } ?: run {
            statusText.text = "GIF provider is not configured."
        }
    }

    private class Adapter(private val results: List<GifResult>, private val onPick: (GifResult) -> Unit) :
        RecyclerView.Adapter<Adapter.Holder>() {

        class Holder(val image: ImageView) : RecyclerView.ViewHolder(image)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val image = ImageView(parent.context).apply {
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewStyling.dp(parent.context, 90))
                scaleType = ImageView.ScaleType.CENTER_CROP
                setPadding(4, 4, 4, 4)
            }
            return Holder(image)
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val item = results[position]
            holder.image.setImageDrawable(null)
            BitmapLoader.load(item.previewUrl) { bmp -> holder.image.setImageBitmap(bmp) }
            holder.image.setOnClickListener { onPick(item) }
        }

        override fun getItemCount(): Int = results.size
    }
}

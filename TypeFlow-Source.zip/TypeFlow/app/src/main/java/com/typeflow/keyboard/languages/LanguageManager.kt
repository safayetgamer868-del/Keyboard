package com.typeflow.keyboard.languages

import android.content.Context
import com.typeflow.keyboard.settings.TypeFlowSettings

/**
 * Registry of supported languages. QWERTY is the only physical layout
 * shipped today, but each [Language] carries its own dictionary asset and is
 * looked up independently, so adding a new one (or a new [LayoutKind]) never
 * requires touching keyboard rendering code.
 */
object LanguageManager {

    val ALL: List<Language> = listOf(
        Language("en", "English", "English", LayoutKind.QWERTY, "dict/en.txt"),
        Language("es", "Spanish", "Español", LayoutKind.QWERTY, "dict/es.txt"),
        Language("fr", "French", "Français", LayoutKind.QWERTY, "dict/fr.txt"),
        Language("de", "German", "Deutsch", LayoutKind.QWERTY, "dict/de.txt"),
        Language("pt", "Portuguese", "Português", LayoutKind.QWERTY, "dict/pt.txt"),
        Language("bn", "Bengali (Latin)", "Bangla", LayoutKind.QWERTY, "dict/bn.txt")
    )

    fun byCode(code: String): Language = ALL.firstOrNull { it.code == code } ?: ALL.first()

    fun enabled(context: Context): List<Language> {
        val codes = TypeFlowSettings.getEnabledLanguages(context)
        val matched = ALL.filter { it.code in codes }
        return matched.ifEmpty { listOf(ALL.first()) }
    }

    fun active(context: Context): Language = byCode(TypeFlowSettings.getActiveLanguage(context))

    fun setActive(context: Context, code: String) {
        TypeFlowSettings.setActiveLanguage(context, code)
    }

    /** Cycles to the next enabled language (used by the globe/SwitchLanguage key). */
    fun cycleActive(context: Context): Language {
        val enabledList = enabled(context)
        val currentIndex = enabledList.indexOfFirst { it.code == active(context).code }
        val next = enabledList[(currentIndex + 1).mod(enabledList.size)]
        setActive(context, next.code)
        return next
    }
}

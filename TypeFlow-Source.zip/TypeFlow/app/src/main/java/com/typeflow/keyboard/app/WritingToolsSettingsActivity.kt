package com.typeflow.keyboard.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.typeflow.keyboard.settings.TypeFlowSettings

class WritingToolsSettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Writing assistance"
        val (scroll, column) = AppUiKit.screen(this)
        setContentView(scroll)

        column.addView(AppUiKit.sectionTitle(this, "TRANSLATION"))
        val translateCard = AppUiKit.card(this)
        translateCard.addView(
            AppUiKit.textFieldRow(
                this, "Translation server URL",
                TypeFlowSettings.getTranslateEndpoint(this),
                "e.g. https://your-libretranslate-server.example"
            ) { TypeFlowSettings.setTranslateEndpoint(this, it) }
        )
        column.addView(translateCard)
        column.addView(
            AppUiKit.sectionTitle(
                this,
                "TypeFlow doesn't bundle a translation backend or key. Point this at any LibreTranslate-compatible server you run or trust."
            )
        )

        column.addView(AppUiKit.sectionTitle(this, "GIFS"))
        val gifCard = AppUiKit.card(this)
        gifCard.addView(
            AppUiKit.textFieldRow(
                this, "Tenor API key",
                TypeFlowSettings.getGifApiKey(this),
                "Paste your own Tenor API key"
            ) { TypeFlowSettings.setGifApiKey(this, it) }
        )
        column.addView(gifCard)
        column.addView(
            AppUiKit.sectionTitle(this, "Get a free key from Google's Tenor API console; GIF search won't work without one.")
        )
    }
}

package com.typeflow.keyboard.gif

data class GifResult(val id: String, val previewUrl: String, val fullUrl: String)

sealed class GifSearchResponse {
    data class Success(val results: List<GifResult>) : GifSearchResponse()
    data class Error(val message: String) : GifSearchResponse()
}

/** Isolated, replaceable GIF search backend. [TenorGifProvider] is the shipped implementation. */
interface GifProvider {
    fun search(query: String, callback: (GifSearchResponse) -> Unit)
}

package com.typeflow.keyboard.core

import android.os.Handler
import android.os.Looper

/**
 * Generic press-and-hold repeater: tap fires [onTick] once immediately on
 * release (handled by the caller), while a hold starts repeating [onTick]
 * after [initialDelayMs], gradually speeding up down to [minIntervalMs].
 *
 * Used for hold-to-delete, but written generically so any key (e.g. arrow
 * navigation) can reuse it.
 */
class HoldRepeater(
    private val initialDelayMs: Long = 420,
    private val startIntervalMs: Long = 110,
    private val minIntervalMs: Long = 35,
    private val accelerationStep: Long = 8,
    private val onTick: () -> Unit
) {
    private val handler = Handler(Looper.getMainLooper())
    private var currentInterval = startIntervalMs
    private var running = false

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (!running) return
            onTick()
            currentInterval = (currentInterval - accelerationStep).coerceAtLeast(minIntervalMs)
            handler.postDelayed(this, currentInterval)
        }
    }

    /** Call on ACTION_DOWN. Does not fire immediately — the caller handles the single tap itself. */
    fun start() {
        stop()
        running = true
        currentInterval = startIntervalMs
        handler.postDelayed(tickRunnable, initialDelayMs)
    }

    /** Call on ACTION_UP / ACTION_CANCEL. Stops immediately, no trailing tick. */
    fun stop() {
        running = false
        handler.removeCallbacks(tickRunnable)
    }

    fun isRunning(): Boolean = running
}

package com.typeflow.keyboard.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.SoundEffectConstants
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import com.typeflow.keyboard.R
import com.typeflow.keyboard.core.HoldRepeater
import com.typeflow.keyboard.core.KeyAction
import com.typeflow.keyboard.core.KeyLayouts
import com.typeflow.keyboard.core.KeyboardKey
import com.typeflow.keyboard.core.KeyboardRow
import com.typeflow.keyboard.glide.GlideGestureTracker
import com.typeflow.keyboard.glide.GlideTypingEngine
import com.typeflow.keyboard.glide.KeyPosition
import com.typeflow.keyboard.settings.TypeFlowSettings
import com.typeflow.keyboard.themes.KeyboardTheme
import kotlin.math.max
import kotlin.math.min

enum class KeyboardMode { LETTERS, SYMBOLS }

/**
 * Renders and drives the actual key surface: QWERTY/symbols rows, the
 * optional number row, shift/caps, hold-to-delete, glide typing and
 * one-handed compression. Deliberately Canvas-drawn (not a grid of
 * android.widget.Button) so it can look and feel like a commercial keyboard
 * and stay cheap to redraw on every key press.
 *
 * Resize contract: [KeyboardMetrics.BASE_KEY_HEIGHT_DP] and every key's width
 * weight are constant. The only thing [heightPercent] changes is the padding
 * above/below/between rows — never a key's own width or height.
 */
class KeyboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private data class PositionedKey(val key: KeyboardKey, val bounds: RectF, val label: String?)

    var actionListener: KeyboardActionListener? = null
    var theme: KeyboardTheme = com.typeflow.keyboard.themes.ThemeRepository.MIDNIGHT
        set(value) { field = value; invalidate() }

    var mode: KeyboardMode = KeyboardMode.LETTERS
        set(value) { field = value; rebuildLayout(); invalidate() }

    var numberRowEnabled: Boolean = true
        set(value) { field = value; rebuildLayout(); invalidate() }

    var glideTypingEnabled: Boolean = true

    var heightPercent: Float = 0.5f
        set(value) { field = value.coerceIn(0f, 1f); requestLayout(); rebuildLayout(); invalidate() }

    /** off | left | right — see TypeFlowSettings.ONE_HANDED_*. */
    var oneHandedMode: String = TypeFlowSettings.ONE_HANDED_OFF
        set(value) { field = value; rebuildLayout(); invalidate() }

    var shiftState: ShiftState = ShiftState.NONE
        set(value) { field = value; rebuildLayout(); invalidate() }

    var soundEnabled: Boolean = false
    var vibrateEnabled: Boolean = true

    private val density get() = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private var rows: List<KeyboardRow> = KeyLayouts.qwertyRows()
    private var positionedRows: List<List<PositionedKey>> = emptyList()

    private var pressedKey: PositionedKey? = null
    private var holdRepeater: HoldRepeater? = null
    private var glideTracker: GlideGestureTracker? = null
    private var isCurrentlyGliding = false
    private var lastShiftTapTime = 0L

    private val keyBgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val keyBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT
    }
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val iconCache = HashMap<Int, Drawable>()

    init {
        isClickable = true
        isFocusable = false
        glideTracker = GlideGestureTracker(minGlideDistancePx = dp(28f))
    }

    fun setLayoutRows(newRows: List<KeyboardRow>) {
        rows = newRows
        rebuildLayout()
        invalidate()
    }

    // ---------------------------------------------------------------- layout

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val height = totalHeightPx(width)
        setMeasuredDimension(width, height)
    }

    private fun rowCount(): Int {
        val letterRows = KeyLayouts.qwertyRows().size
        val extra = if (mode == KeyboardMode.LETTERS && numberRowEnabled) 1 else 0
        return if (mode == KeyboardMode.LETTERS) letterRows + extra else KeyLayouts.symbolsRows().size
    }

    private fun totalHeightPx(@Suppress("UNUSED_PARAMETER") widthPx: Int): Int {
        val keyH = dp(KeyboardMetrics.BASE_KEY_HEIGHT_DP)
        val gap = dp(KeyboardMetrics.MIN_ROW_GAP_DP) +
            dp(KeyboardMetrics.MAX_EXTRA_ROW_GAP_DP) * heightPercent
        val edgePad = dp(KeyboardMetrics.MIN_EDGE_PADDING_DP) +
            dp(KeyboardMetrics.MAX_EXTRA_EDGE_PADDING_DP) * heightPercent
        val rowsN = rowCount()
        val height = edgePad * 2 + rowsN * keyH + (rowsN - 1) * gap
        return height.toInt()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuildLayout()
    }

    private fun activeRows(): List<KeyboardRow> {
        val base = if (mode == KeyboardMode.LETTERS) KeyLayouts.qwertyRows() else KeyLayouts.symbolsRows()
        return if (mode == KeyboardMode.LETTERS && numberRowEnabled) {
            listOf(KeyLayouts.numberRow()) + base
        } else base
    }

    private fun rebuildLayout() {
        if (width == 0 || height == 0) return
        val keyH = dp(KeyboardMetrics.BASE_KEY_HEIGHT_DP)
        val gap = dp(KeyboardMetrics.MIN_ROW_GAP_DP) +
            dp(KeyboardMetrics.MAX_EXTRA_ROW_GAP_DP) * heightPercent
        val edgePad = dp(KeyboardMetrics.MIN_EDGE_PADDING_DP) +
            dp(KeyboardMetrics.MAX_EXTRA_EDGE_PADDING_DP) * heightPercent
        val sidePad = dp(KeyboardMetrics.SIDE_PADDING_DP)
        val keyMargin = dp(KeyboardMetrics.KEY_HORIZONTAL_MARGIN_DP)

        // One-handed mode compresses the usable width and anchors it to a side;
        // within that width, per-key ratios are identical to normal mode.
        val compressionFactor = if (oneHandedMode != TypeFlowSettings.ONE_HANDED_OFF) 0.78f else 1f
        val usableWidth = (width - sidePad * 2) * compressionFactor
        val leftOffset = when (oneHandedMode) {
            TypeFlowSettings.ONE_HANDED_LEFT -> sidePad
            TypeFlowSettings.ONE_HANDED_RIGHT -> width - sidePad - usableWidth
            else -> sidePad
        }

        val allRows = activeRows()
        val result = mutableListOf<List<PositionedKey>>()
        var y = edgePad
        for (row in allRows) {
            val totalWeight = row.keys.sumOf { it.widthWeight.toDouble() }.toFloat()
            var x = leftOffset
            val rowKeys = mutableListOf<PositionedKey>()
            for (key in row.keys) {
                val keyWidth = (usableWidth * (key.widthWeight / totalWeight))
                val bounds = RectF(x + keyMargin, y, x + keyWidth - keyMargin, y + keyH)
                rowKeys.add(PositionedKey(key, bounds, labelFor(key)))
                x += keyWidth
            }
            result.add(rowKeys)
            y += keyH + gap
        }
        positionedRows = result
    }

    private fun labelFor(key: KeyboardKey): String? = when (val a = key.action) {
        is KeyAction.Character -> if (shiftState != ShiftState.NONE) a.upper else a.lower
        is KeyAction.Symbol -> a.value
        else -> null
    }

    private fun iconFor(action: KeyAction): Int? = when (action) {
        is KeyAction.Shift -> if (shiftState == ShiftState.CAPS_LOCK) R.drawable.ic_shift_locked else R.drawable.ic_shift
        KeyAction.Backspace -> R.drawable.ic_backspace
        KeyAction.Enter -> R.drawable.ic_enter
        KeyAction.SwitchLanguage -> R.drawable.ic_globe
        KeyAction.Emoji -> R.drawable.ic_emoji
        KeyAction.Tools -> R.drawable.ic_tools
        else -> null
    }

    // ---------------------------------------------------------------- draw

    override fun onDraw(canvas: Canvas) {
        bgPaint.color = theme.keyboardBackground
        bgPaint.alpha = (theme.keyboardOpacity * 255).toInt()
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        val radius = dp(theme.keyCornerRadiusDp)
        for (row in positionedRows) {
            for (pk in row) {
                val pressed = pk === pressedKey
                val isSpecial = pk.key.isSpecial
                val bg = when {
                    isSpecial && pressed -> theme.specialKeyBackgroundPressed
                    isSpecial -> theme.specialKeyBackground
                    pressed -> theme.keyBackgroundPressed
                    else -> theme.keyBackground
                }
                keyBgPaint.color = bg
                keyBgPaint.alpha = (theme.keyOpacity * 255).toInt()
                canvas.drawRoundRect(pk.bounds, radius, radius, keyBgPaint)

                if (theme.showKeyBorders) {
                    keyBorderPaint.color = theme.keyBorderColor
                    keyBorderPaint.strokeWidth = dp(1f)
                    canvas.drawRoundRect(pk.bounds, radius, radius, keyBorderPaint)
                }

                val icon = iconFor(pk.key.action)
                if (icon != null) {
                    drawIcon(canvas, icon, pk.bounds, if (isSpecial) theme.keyTextSecondary else theme.keyText)
                } else if (pk.key.action == KeyAction.Space) {
                    // Intentionally blank — a bare space key needs no label or icon.
                } else if (pk.label != null) {
                    textPaint.color = if (isSpecial) theme.keyTextSecondary else theme.keyText
                    textPaint.textSize = dp(20f)
                    val fm = textPaint.fontMetrics
                    val ty = pk.bounds.centerY() - (fm.ascent + fm.descent) / 2
                    canvas.drawText(pk.label, pk.bounds.centerX(), ty, textPaint)
                }
            }
        }
    }

    private fun drawIcon(canvas: Canvas, resId: Int, bounds: RectF, tint: Int) {
        val drawable = iconCache.getOrPut(resId) {
            val d = ContextCompat.getDrawable(context, resId)!!.mutate()
            DrawableCompat.wrap(d)
        }
        DrawableCompat.setTint(drawable, tint)
        val size = dp(22f).toInt()
        val cx = bounds.centerX().toInt()
        val cy = bounds.centerY().toInt()
        drawable.setBounds(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2)
        drawable.draw(canvas)
    }

    // ---------------------------------------------------------------- touch

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> handleDown(x, y)
            MotionEvent.ACTION_MOVE -> handleMove(x, y)
            MotionEvent.ACTION_UP -> handleUp(x, y)
            MotionEvent.ACTION_CANCEL -> handleCancel()
        }
        return true
    }

    private fun findKeyAt(x: Float, y: Float): PositionedKey? {
        for (row in positionedRows) {
            for (pk in row) {
                // Extend hit-testing slightly beyond the drawn gap so adjacent taps don't feel like misses.
                if (x >= pk.bounds.left - dp(2f) && x <= pk.bounds.right + dp(2f) &&
                    y >= pk.bounds.top && y <= pk.bounds.bottom
                ) return pk
            }
        }
        return null
    }

    private fun handleDown(x: Float, y: Float) {
        val key = findKeyAt(x, y) ?: return
        pressedKey = key
        performFeedback()
        actionListener?.onKeyPreview(key.label)
        invalidate()

        if (key.key.action == KeyAction.Backspace) {
            actionListener?.onBackspaceTick() // tap = delete one immediately
            holdRepeater = HoldRepeater { actionListener?.onBackspaceTick() }.also { it.start() }
        }

        val isLetterKey = key.key.action is KeyAction.Character
        glideTracker?.start(x, y, onLetterKey = isLetterKey && glideTypingEnabled)
        isCurrentlyGliding = false
    }

    private fun handleMove(x: Float, y: Float) {
        glideTracker?.addPoint(x, y)
        if (!isCurrentlyGliding && glideTracker?.isGlide(currentLetterKeyPositions()) == true) {
            isCurrentlyGliding = true
            holdRepeater?.stop()
            pressedKey = null
            invalidate()
        }
        if (!isCurrentlyGliding) {
            val key = findKeyAt(x, y)
            if (key !== pressedKey && key?.key?.action != KeyAction.Backspace) {
                // Moving off the original key cancels it, matching standard soft-keyboard feel.
                pressedKey = null
                invalidate()
            }
        }
    }

    private fun handleUp(x: Float, y: Float) {
        holdRepeater?.stop()
        holdRepeater = null

        if (isCurrentlyGliding) {
            val seq = GlideTypingEngine.decodeKeySequence(glideTracker!!.path(), currentLetterKeyPositions())
            if (seq.length >= 2) {
                actionListener?.onGlideWordCommitted(seq) // IME resolves against the dictionary
            }
            isCurrentlyGliding = false
            pressedKey = null
            actionListener?.onKeyPreview(null)
            invalidate()
            return
        }

        val key = pressedKey ?: findKeyAt(x, y)
        pressedKey = null
        actionListener?.onKeyPreview(null)
        invalidate()
        if (key == null) return
        if (key.key.action == KeyAction.Backspace) return // already handled on DOWN + hold ticks

        dispatch(key.key.action)
    }

    private fun handleCancel() {
        holdRepeater?.stop()
        holdRepeater = null
        isCurrentlyGliding = false
        pressedKey = null
        actionListener?.onKeyPreview(null)
        invalidate()
    }

    private fun currentLetterKeyPositions(): List<KeyPosition> {
        val positions = mutableListOf<KeyPosition>()
        for (row in positionedRows) {
            for (pk in row) {
                val action = pk.key.action
                if (action is KeyAction.Character) {
                    positions.add(KeyPosition(action.lower.first(), pk.bounds.centerX(), pk.bounds.centerY()))
                }
            }
        }
        return positions
    }

    private fun dispatch(action: KeyAction) {
        when (action) {
            is KeyAction.Character -> {
                val text = if (shiftState != ShiftState.NONE) action.upper else action.lower
                actionListener?.onCharacter(text)
                if (shiftState == ShiftState.SHIFT) shiftState = ShiftState.NONE
            }
            is KeyAction.Symbol -> actionListener?.onSymbol(action.value)
            KeyAction.Shift -> {
                val now = System.currentTimeMillis()
                if (now - lastShiftTapTime < 350) {
                    shiftState = if (shiftState == ShiftState.CAPS_LOCK) ShiftState.NONE else ShiftState.CAPS_LOCK
                    actionListener?.onShiftDoubleTapped()
                } else {
                    shiftState = if (shiftState == ShiftState.NONE) ShiftState.SHIFT else ShiftState.NONE
                    actionListener?.onShiftTapped()
                }
                lastShiftTapTime = now
            }
            KeyAction.Enter -> actionListener?.onEnter()
            KeyAction.Space -> actionListener?.onSpace()
            KeyAction.SwitchToNumbers -> { mode = KeyboardMode.SYMBOLS; actionListener?.onSwitchToNumbers() }
            KeyAction.SwitchToLetters -> { mode = KeyboardMode.LETTERS; actionListener?.onSwitchToLetters() }
            KeyAction.SwitchToSymbols -> actionListener?.onSwitchToSymbols()
            KeyAction.Emoji -> actionListener?.onEmojiRequested()
            KeyAction.Tools -> actionListener?.onToolsRequested()
            KeyAction.SwitchLanguage -> actionListener?.onLanguageSwitchRequested()
            KeyAction.Backspace -> Unit
        }
    }

    private fun performFeedback() {
        if (vibrateEnabled) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        if (soundEnabled) playSoundEffect(SoundEffectConstants.CLICK)
    }

    /** Sets an externally-resolved word/char (e.g. from autocorrect) — kept for API symmetry with future callers. */
    fun clampHeightPercent(value: Float): Float = max(0f, min(1f, value))
}

package com.typeflow.keyboard.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.util.AttributeSet
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.typeflow.keyboard.R
import com.typeflow.keyboard.clipboard.ClipboardItem
import com.typeflow.keyboard.clipboard.ClipboardStore
import com.typeflow.keyboard.themes.KeyboardTheme
import java.io.File

/**
 * Compact, keyboard-side clipboard view: recent items only, tap to insert,
 * with a pin toggle. Full management (edit/delete history) intentionally
 * lives in the TypeFlow app, not here — see product requirement.
 */
class ClipboardQuickPanel @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {

    var theme: KeyboardTheme = com.typeflow.keyboard.themes.ThemeRepository.MIDNIGHT
        set(value) { field = value; setBackgroundColor(value.keyboardBackground) }

    var onInsert: ((String) -> Unit)? = null
    var onBackRequested: (() -> Unit)? = null

    private val recyclerView = RecyclerView(context)
    private val store = ClipboardStore(context)

    init {
        orientation = VERTICAL
        setBackgroundColor(theme.keyboardBackground)

        val header = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL }
        val back = ViewStyling.iconButton(context, R.drawable.ic_arrow_back, theme.keyText, theme.specialKeyBackground, theme, 34)
        back.setOnClickListener { onBackRequested?.invoke() }
        val title = TextView(context).apply {
            text = "Clipboard"
            setTextColor(theme.keyText)
            textSize = 14f
            setPadding(ViewStyling.dp(context, 8), 0, 0, 0)
        }
        header.addView(back, LayoutParams(ViewStyling.dp(context, 34), ViewStyling.dp(context, 34)).also { it.marginStart = ViewStyling.dp(context, 8) })
        header.addView(title)
        addView(header, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewStyling.dp(context, 40)))

        recyclerView.layoutManager = LinearLayoutManager(context)
        addView(recyclerView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    fun refresh() {
        val items = store.getItems().take(25)
        recyclerView.adapter = Adapter(items, theme, store) { text -> onInsert?.invoke(text) }
    }

    private class Adapter(
        private val items: List<ClipboardItem>,
        private val theme: KeyboardTheme,
        private val store: ClipboardStore,
        private val onPick: (String) -> Unit
    ) : RecyclerView.Adapter<Adapter.Holder>() {

        class Holder(val row: LinearLayout, val text: TextView, val thumb: ImageView, val pin: ImageView) : RecyclerView.ViewHolder(row)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val row = LinearLayout(parent.context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val pad = ViewStyling.dp(parent.context, 10)
                setPadding(pad, pad, pad, pad)
            }
            val thumb = ImageView(parent.context).apply {
                layoutParams = LayoutParams(ViewStyling.dp(parent.context, 36), ViewStyling.dp(parent.context, 36))
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
            val text = TextView(parent.context).apply {
                maxLines = 2
                textSize = 14f
                setPadding(ViewStyling.dp(parent.context, 10), 0, ViewStyling.dp(parent.context, 10), 0)
            }
            val pin = ImageView(parent.context).apply {
                layoutParams = LayoutParams(ViewStyling.dp(parent.context, 22), ViewStyling.dp(parent.context, 22))
            }
            row.addView(thumb)
            row.addView(text, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(pin)
            return Holder(row, text, thumb, pin)
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val item = items[position]
            holder.text.setTextColor(theme.keyText)
            holder.text.text = if (item.isScreenshot) "Screenshot" else item.text
            holder.row.setBackgroundColor(theme.keyBackground)

            if (item.isScreenshot && item.screenshotUri != null) {
                holder.thumb.visibility = ImageView.VISIBLE
                try {
                    val path = item.screenshotUri.removePrefix("file://")
                    val bmp = BitmapFactory.decodeFile(path)
                    holder.thumb.setImageBitmap(bmp)
                } catch (_: Throwable) {
                    holder.thumb.setImageDrawable(null)
                }
            } else {
                holder.thumb.visibility = ImageView.GONE
            }

            val pinIcon = if (item.pinned) R.drawable.ic_pin_filled else R.drawable.ic_pin_outline
            val pinDrawable = androidx.core.content.ContextCompat.getDrawable(holder.pin.context, pinIcon)!!.mutate()
            androidx.core.graphics.drawable.DrawableCompat.setTint(pinDrawable, if (item.pinned) theme.accent else theme.keyTextSecondary)
            holder.pin.setImageDrawable(pinDrawable)
            holder.pin.setOnClickListener { store.togglePin(item.id) }

            holder.row.setOnClickListener {
                if (!item.isScreenshot) onPick(item.text)
            }
        }

        override fun getItemCount(): Int = items.size
    }
}

package com.typeflow.keyboard.ui

enum class ShiftState { NONE, SHIFT, CAPS_LOCK }

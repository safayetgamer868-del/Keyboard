package com.typeflow.keyboard.app

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.typeflow.keyboard.settings.TypeFlowSettings
import com.typeflow.keyboard.themes.KeyboardTheme
import com.typeflow.keyboard.themes.ThemeRepository

class ThemeActivity : AppCompatActivity() {

    private lateinit var listContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Themes"
        val (scroll, column) = AppUiKit.screen(this)
        setContentView(scroll)
        column.addView(AppUiKit.sectionTitle(this, "BUILT-IN THEMES"))
        listContainer = AppUiKit.card(this)
        column.addView(listContainer)
        rebuild()
    }

    private fun rebuild() {
        listContainer.removeAllViews()
        val activeId = TypeFlowSettings.getThemeId(this)
        val themes = ThemeRepository.allThemes(this)
        themes.forEachIndexed { index, theme ->
            listContainer.addView(themeRow(theme, theme.id == activeId))
            if (index != themes.lastIndex) listContainer.addView(AppUiKit.divider(this))
        }
    }

    private fun themeRow(theme: KeyboardTheme, selected: Boolean): LinearLayout {
        val row = AppUiKit.row(this)
        row.isClickable = true
        row.setOnClickListener {
            TypeFlowSettings.setThemeId(this, theme.id)
            rebuild()
        }

        val preview = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(AppUiKit.dp(this@ThemeActivity, 56), AppUiKit.dp(this@ThemeActivity, 36))
            val bg = GradientDrawable().apply {
                cornerRadius = AppUiKit.dp(this@ThemeActivity, 8).toFloat()
                setColor(theme.keyboardBackground)
            }
            background = bg
            gravity = Gravity.CENTER
            val swatch = GradientDrawable().apply {
                cornerRadius = AppUiKit.dp(this@ThemeActivity, 4).toFloat()
                setColor(theme.accent)
            }
            addView(
                android.widget.ImageView(this@ThemeActivity).apply { background = swatch },
                LinearLayout.LayoutParams(AppUiKit.dp(this@ThemeActivity, 18), AppUiKit.dp(this@ThemeActivity, 18))
            )
        }
        row.addView(preview, LinearLayout.LayoutParams(AppUiKit.dp(this, 56), AppUiKit.dp(this, 36)).also { it.marginEnd = AppUiKit.dp(this, 14) })
        row.addView(
            AppUiKit.rowTitle(this, theme.displayName, if (theme.isDark) "Dark" else "Light"),
            LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        if (selected) {
            row.addView(
                TextView(this).apply {
                    text = "\u2713"
                    textSize = 18f
                    setTextColor(theme.accent)
                }
            )
        }
        return row
    }
}

package com.typeflow.keyboard.app

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.typeflow.keyboard.R
import com.typeflow.keyboard.settings.TypeFlowSettings
import com.typeflow.keyboard.themes.KeyboardTheme
import com.typeflow.keyboard.themes.ThemeRepository

/**
 * SwiftKey-inspired theme gallery: large visual previews, two-column cards,
 * clear selected state, and a live System Dynamic option.
 */
class ThemeActivity : AppCompatActivity() {

    private lateinit var grid: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Themes"

        val (scroll, column) = AppUiKit.screen(this)
        setContentView(scroll)

        column.addView(AppUiKit.sectionTitle(this, "KEYBOARD THEMES"))
        val intro = TextView(this).apply {
            text = "Pick a built-in style. System Dynamic follows your phone's colors."
            setTextColor(ContextCompat.getColor(this@ThemeActivity, R.color.tf_on_surface_variant))
            textSize = 13f
            setPadding(AppUiKit.dp(this@ThemeActivity, 4), 0, AppUiKit.dp(this@ThemeActivity, 4), AppUiKit.dp(this@ThemeActivity, 12))
        }
        column.addView(intro)

        grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        column.addView(grid)
        rebuild()
    }

    private fun rebuild() {
        grid.removeAllViews()
        val activeId = TypeFlowSettings.getThemeId(this)
        val themes = ThemeRepository.allThemes(this)

        themes.chunked(2).forEachIndexed { rowIndex, pair ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.TOP
            }
            pair.forEachIndexed { index, theme ->
                val card = themeCard(theme, theme.id == activeId)
                row.addView(
                    card,
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also {
                        it.marginEnd = if (index == 0) AppUiKit.dp(this, 6) else 0
                        it.marginStart = if (index == 1) AppUiKit.dp(this, 6) else 0
                    }
                )
            }
            if (pair.size == 1) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f).also {
                    it.marginStart = AppUiKit.dp(this, 6)
                })
            }
            grid.addView(row)
            if (rowIndex != themes.chunked(2).lastIndex) {
                grid.addView(View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(1, AppUiKit.dp(this@ThemeActivity, 10))
                })
            }
        }
    }

    private fun themeCard(theme: KeyboardTheme, selected: Boolean): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                AppUiKit.dp(this@ThemeActivity, 10),
                AppUiKit.dp(this@ThemeActivity, 10),
                AppUiKit.dp(this@ThemeActivity, 10),
                AppUiKit.dp(this@ThemeActivity, 10)
            )
            isClickable = true
            isFocusable = true
            background = GradientDrawable().apply {
                cornerRadius = AppUiKit.dp(this@ThemeActivity, 18).toFloat()
                setColor(ContextCompat.getColor(this@ThemeActivity, R.color.tf_surface))
                if (selected) setStroke(AppUiKit.dp(this@ThemeActivity, 2), theme.accent)
            }
            elevation = AppUiKit.dp(this@ThemeActivity, 2).toFloat()
            setOnClickListener {
                TypeFlowSettings.setThemeId(this@ThemeActivity, theme.id)
                rebuild()
            }
        }

        card.addView(keyboardPreview(theme), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            AppUiKit.dp(this, 112)
        ))

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, AppUiKit.dp(this@ThemeActivity, 9), 0, 0)
        }
        titleRow.addView(
            TextView(this@ThemeActivity).apply {
                text = theme.displayName
                textSize = 14f
                setTextColor(ContextCompat.getColor(this@ThemeActivity, R.color.tf_on_surface))
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        if (selected) {
            titleRow.addView(ImageView(this@ThemeActivity).apply {
                setImageResource(R.drawable.ic_check)
                setColorFilter(theme.accent)
                contentDescription = "Selected"
            }, LinearLayout.LayoutParams(AppUiKit.dp(this, 20), AppUiKit.dp(this, 20)))
        }
        card.addView(titleRow)
        card.addView(TextView(this).apply {
            text = when {
                theme.id == "system" -> "Dynamic"
                theme.isDark -> "Dark"
                else -> "Light"
            }
            textSize = 11f
            setTextColor(ContextCompat.getColor(this@ThemeActivity, R.color.tf_on_surface_variant))
            setPadding(0, AppUiKit.dp(this@ThemeActivity, 2), 0, 0)
        })
        return card
    }

    private fun keyboardPreview(theme: KeyboardTheme): View {
        val preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(
                AppUiKit.dp(this@ThemeActivity, 6),
                AppUiKit.dp(this@ThemeActivity, 7),
                AppUiKit.dp(this@ThemeActivity, 6),
                AppUiKit.dp(this@ThemeActivity, 7)
            )
            background = GradientDrawable().apply {
                cornerRadius = AppUiKit.dp(this@ThemeActivity, 12).toFloat()
                setColor(theme.keyboardBackground)
            }
        }

        val rows = listOf(
            listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"),
            listOf("A", "S", "D", "F", "G", "H", "J", "K", "L"),
            listOf("Z", "X", "C", "V", "B", "N", "M")
        )
        rows.forEach { letters ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            letters.forEach { letter ->
                val key = TextView(this@ThemeActivity).apply {
                    text = letter
                    textSize = 7f
                    gravity = Gravity.CENTER
                    setTextColor(theme.keyText)
                    background = GradientDrawable().apply {
                        cornerRadius = AppUiKit.dp(this@ThemeActivity, 5).toFloat()
                        setColor(theme.keyBackground)
                        if (theme.showKeyBorders) {
                            setStroke(AppUiKit.dp(this@ThemeActivity, 1), theme.keyBorderColor)
                        }
                    }
                }
                row.addView(key, LinearLayout.LayoutParams(0, AppUiKit.dp(this, 24), 1f).also {
                    it.setMargins(AppUiKit.dp(this@ThemeActivity, 2), AppUiKit.dp(this@ThemeActivity, 2), AppUiKit.dp(this@ThemeActivity, 2), AppUiKit.dp(this@ThemeActivity, 2))
                })
            }
            preview.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        return preview
    }
}

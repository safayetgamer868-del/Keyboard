package com.typeflow.keyboard.core

/**
 * Static row definitions for every supported layout. Each row's key widths
 * are fixed ratios — the only thing that ever changes with the "keyboard
 * size" setting is the *height* of the whole keyboard (see KeyboardView),
 * never these per-key proportions.
 */
object KeyLayouts {

    private fun charKey(lower: String, upper: String = lower.uppercase()) =
        KeyboardKey(KeyAction.Character(lower, upper))

    fun qwertyRows(): List<KeyboardRow> = listOf(
        KeyboardRow(listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p").map { charKey(it) }),
        KeyboardRow(listOf("a", "s", "d", "f", "g", "h", "j", "k", "l").map { charKey(it) }),
        KeyboardRow(
            listOf(KeyboardKey(KeyAction.Shift, widthWeight = 1.5f, isSpecial = true)) +
                listOf("z", "x", "c", "v", "b", "n", "m").map { charKey(it) } +
                listOf(KeyboardKey(KeyAction.Backspace, widthWeight = 1.5f, isSpecial = true))
        ),
        KeyboardRow(
            listOf(
                KeyboardKey(KeyAction.SwitchToNumbers, widthWeight = 1.3f, isSpecial = true),
                KeyboardKey(KeyAction.Emoji, widthWeight = 1f, isSpecial = true),
                KeyboardKey(KeyAction.SwitchLanguage, widthWeight = 1f, isSpecial = true),
                KeyboardKey(KeyAction.Space, widthWeight = 4.4f, isSpecial = false),
                KeyboardKey(KeyAction.Tools, widthWeight = 1f, isSpecial = true),
                KeyboardKey(KeyAction.Enter, widthWeight = 1.5f, isSpecial = true)
            )
        )
    )

    fun numberRow(): KeyboardRow = KeyboardRow(
        listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0").map {
            KeyboardKey(KeyAction.Symbol(it))
        }
    )

    fun symbolsRows(): List<KeyboardRow> = listOf(
        KeyboardRow(listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0").map { KeyboardKey(KeyAction.Symbol(it)) }),
        KeyboardRow(listOf("@", "#", "$", "_", "&", "-", "+", "(", ")", "/").map { KeyboardKey(KeyAction.Symbol(it)) }),
        KeyboardRow(
            listOf(KeyboardKey(KeyAction.SwitchToLetters, widthWeight = 1.5f, isSpecial = true)) +
                listOf("*", "\"", "'", ":", ";", "!", "?").map { KeyboardKey(KeyAction.Symbol(it)) } +
                listOf(KeyboardKey(KeyAction.Backspace, widthWeight = 1.5f, isSpecial = true))
        ),
        KeyboardRow(
            listOf(
                KeyboardKey(KeyAction.SwitchToLetters, widthWeight = 1.3f, isSpecial = true),
                KeyboardKey(KeyAction.Emoji, widthWeight = 1f, isSpecial = true),
                KeyboardKey(KeyAction.Symbol(","), widthWeight = 1f),
                KeyboardKey(KeyAction.Space, widthWeight = 3.4f),
                KeyboardKey(KeyAction.Symbol("."), widthWeight = 1f),
                KeyboardKey(KeyAction.Tools, widthWeight = 1f, isSpecial = true),
                KeyboardKey(KeyAction.Enter, widthWeight = 1.5f, isSpecial = true)
            )
        )
    )
}

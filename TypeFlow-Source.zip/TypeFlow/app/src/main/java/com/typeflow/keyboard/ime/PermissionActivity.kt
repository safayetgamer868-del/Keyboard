package com.typeflow.keyboard.ime

import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.core.app.ActivityCompat

/**
 * A [android.inputmethodservice.InputMethodService] can't call
 * requestPermissions itself, so when the keyboard needs a runtime permission
 * it hasn't been granted yet (e.g. the microphone for voice typing), it
 * launches this transparent activity to ask for it, then the user simply
 * retries the action in the keyboard.
 */
class PermissionActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val permission = intent.getStringExtra(EXTRA_PERMISSION)
        if (permission == null) {
            finish()
            return
        }
        ActivityCompat.requestPermissions(this, arrayOf(permission), REQUEST_CODE)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        Toast.makeText(
            this,
            if (granted) "Permission granted \u2014 try that again." else "Permission denied.",
            Toast.LENGTH_SHORT
        ).show()
        finish()
    }

    companion object {
        const val EXTRA_PERMISSION = "extra_permission"
        private const val REQUEST_CODE = 4201
    }
}

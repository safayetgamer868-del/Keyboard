package com.typeflow.keyboard.glide

import kotlin.math.hypot

/** The on-screen center of one letter key, used to map gesture points to keys. */
data class KeyPosition(val char: Char, val centerX: Float, val centerY: Float)

/**
 * Converts a raw glide gesture into ranked word candidates.
 *
 * Real (non-mocked) two-stage algorithm:
 *  1. [decodeKeySequence] reduces the sampled touch path to the sequence of
 *     letter keys it passed nearest to (collapsing consecutive repeats, so a
 *     slow moment over one key doesn't spam it).
 *  2. [candidatesFor] scores dictionary words by how well they fit as an
 *     ordered subsequence of that key sequence — a word that explains most of
 *     the path with the least leftover noise wins, with the frequency-ranked
 *     dictionary order breaking ties.
 */
object GlideTypingEngine {

    fun decodeKeySequence(points: List<Pair<Float, Float>>, keys: List<KeyPosition>): String {
        if (keys.isEmpty() || points.isEmpty()) return ""
        val seq = StringBuilder()
        var last: Char? = null
        for ((x, y) in points) {
            val nearest = keys.minByOrNull { hypot((it.centerX - x).toDouble(), (it.centerY - y).toDouble()) }
                ?: continue
            if (nearest.char != last) {
                seq.append(nearest.char)
                last = nearest.char
            }
        }
        return seq.toString()
    }

    fun candidatesFor(keySequence: String, dictionary: List<String>, maxResults: Int = 5): List<String> {
        if (keySequence.length < 2) return emptyList()
        val seq = keySequence.lowercase()

        data class Scored(val word: String, val score: Double, val rank: Int)

        val scored = mutableListOf<Scored>()
        for ((rank, word) in dictionary.withIndex()) {
            if (word.length < 2 || word.length > seq.length) continue
            if (word.first() != seq.first()) continue
            if (!isOrderedSubsequence(word, seq)) continue
            val coverage = word.length.toDouble() / seq.length
            val endBonus = if (word.last() == seq.last()) 0.15 else 0.0
            scored.add(Scored(word, coverage + endBonus, rank))
        }

        return scored
            .sortedWith(compareByDescending<Scored> { it.score }.thenBy { it.rank })
            .map { it.word }
            .distinct()
            .take(maxResults)
    }

    /** True if every letter of [word] appears in [seq], in order (extra letters in seq are allowed — gesture noise). */
    private fun isOrderedSubsequence(word: String, seq: String): Boolean {
        var w = 0
        var s = 0
        while (w < word.length && s < seq.length) {
            if (word[w] == seq[s]) w++
            s++
        }
        return w == word.length
    }
}

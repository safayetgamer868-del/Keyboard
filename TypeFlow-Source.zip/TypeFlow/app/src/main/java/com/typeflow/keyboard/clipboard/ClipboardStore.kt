package com.typeflow.keyboard.clipboard

import android.content.Context
import com.typeflow.keyboard.settings.TypeFlowSettings
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Persists clipboard text history and screenshot references.
 *
 * Lives mainly for the app's Clipboard screen (per the product requirement
 * that this NOT become a big in-keyboard panel) but is also read by the
 * keyboard's compact clipboard tool so a recent item can be inserted quickly.
 */
class ClipboardStore(private val context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("typeflow_clipboard", Context.MODE_PRIVATE)
    private val key = "items"

    fun getItems(): MutableList<ClipboardItem> {
        val array = JSONArray(prefs.getString(key, "[]") ?: "[]")
        val result = mutableListOf<ClipboardItem>()
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            result.add(
                ClipboardItem(
                    id = o.getLong("id"),
                    text = o.optString("text", ""),
                    timestamp = o.optLong("timestamp", 0L),
                    isScreenshot = o.optBoolean("screenshot", false),
                    pinned = o.optBoolean("pinned", false),
                    screenshotUri = o.optString("screenshotUri", null).ifEmpty { null }
                )
            )
        }
        return result
    }

    private fun save(items: List<ClipboardItem>) {
        val array = JSONArray()
        items.forEach { item ->
            array.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("text", item.text)
                    put("timestamp", item.timestamp)
                    put("screenshot", item.isScreenshot)
                    put("pinned", item.pinned)
                    if (item.screenshotUri != null) put("screenshotUri", item.screenshotUri)
                }
            )
        }
        prefs.edit().putString(key, array.toString()).apply()
    }

    /** Adds a copied text entry, moving an existing duplicate to the top instead of creating a second copy. */
    fun add(text: String, screenshot: Boolean = false, screenshotUri: String? = null) {
        if (text.isBlank() && screenshotUri == null) return
        val items = getItems()
        items.removeAll { it.text == text && it.screenshotUri == screenshotUri }
        items.add(0, ClipboardItem(System.currentTimeMillis(), text, isScreenshot = screenshot, screenshotUri = screenshotUri))

        val max = TypeFlowSettings.getClipboardMaxItems(context)
        val pinned = items.filter { it.pinned }
        val unpinned = items.filterNot { it.pinned }
        val trimmedUnpinned = unpinned.take((max - pinned.size).coerceAtLeast(0))
        val overflow = unpinned.drop(trimmedUnpinned.size)
        overflow.forEach { removed -> removed.screenshotUri?.let(::deleteScreenshotFile) }

        save((pinned + trimmedUnpinned).sortedByDescending { it.timestamp })
    }

    /** Swipe-to-delete: refuses to remove a pinned item. */
    fun delete(id: Long) {
        val target = getItems().firstOrNull { it.id == id } ?: return
        if (target.pinned) return
        target.screenshotUri?.let(::deleteScreenshotFile)
        save(getItems().filterNot { it.id == id })
    }

    /** Explicit delete: works even on a pinned item, per the pin contract. */
    fun forceDelete(id: Long) {
        val target = getItems().firstOrNull { it.id == id } ?: return
        target.screenshotUri?.let(::deleteScreenshotFile)
        save(getItems().filterNot { it.id == id })
    }

    fun togglePin(id: Long) {
        save(getItems().map { if (it.id == id) it.copy(pinned = !it.pinned) else it })
    }

    /** Pinned items stay fully editable — this was a bug in an earlier build and must not regress. */
    fun edit(id: Long, newText: String) {
        if (newText.isBlank()) return
        save(getItems().map { if (it.id == id) it.copy(text = newText) else it })
    }

    fun clearUnpinned() {
        getItems().filterNot { it.pinned }.forEach { it.screenshotUri?.let(::deleteScreenshotFile) }
        save(getItems().filter { it.pinned })
    }

    private fun deleteScreenshotFile(uriString: String) {
        try {
            val path = uriString.removePrefix("file://")
            val file = File(path)
            if (file.exists()) file.delete()
        } catch (_: Throwable) {
            // Best-effort cleanup only; a missing/already-deleted file is not an error for the user.
        }
    }
}

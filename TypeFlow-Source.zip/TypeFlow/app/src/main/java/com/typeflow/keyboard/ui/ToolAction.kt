package com.typeflow.keyboard.ui

enum class ToolAction { UNDO, REDO, CLIPBOARD, TRANSLATE, GRAMMAR, TONE, VOICE, GIF, SETTINGS, BACK }

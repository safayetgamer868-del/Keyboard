package com.typeflow.keyboard.gif

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import java.net.URL
import java.util.concurrent.Executors

/** Minimal async image loader for GIF thumbnails — no third-party image library dependency required. */
object BitmapLoader {
    private val executor = Executors.newFixedThreadPool(3)
    private val mainHandler = Handler(Looper.getMainLooper())

    fun load(url: String, onLoaded: (Bitmap?) -> Unit) {
        executor.execute {
            val bitmap = try {
                URL(url).openStream().use { BitmapFactory.decodeStream(it) }
            } catch (_: Throwable) {
                null
            }
            mainHandler.post { onLoaded(bitmap) }
        }
    }
}

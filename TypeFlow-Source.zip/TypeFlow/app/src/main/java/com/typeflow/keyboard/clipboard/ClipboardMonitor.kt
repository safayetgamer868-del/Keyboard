package com.typeflow.keyboard.clipboard

import android.content.ClipboardManager
import android.content.Context

/**
 * Listens for system clipboard changes while the keyboard or app is active
 * and records new plain-text copies into [ClipboardStore]. Registered from
 * both the IME (while an input view is shown) and the app (while visible),
 * since Android only delivers clipboard-change callbacks to a listening,
 * foreground-ish process.
 */
class ClipboardMonitor(private val context: Context) {

    private val clipboardManager =
        context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    private val store = ClipboardStore(context)
    private var lastSeenText: String? = null

    private val listener = ClipboardManager.OnPrimaryClipChangedListener {
        val clip = clipboardManager.primaryClip ?: return@OnPrimaryClipChangedListener
        if (clip.itemCount == 0) return@OnPrimaryClipChangedListener
        val text = clip.getItemAt(0).coerceToText(context)?.toString() ?: return@OnPrimaryClipChangedListener
        if (text.isBlank() || text == lastSeenText) return@OnPrimaryClipChangedListener
        lastSeenText = text
        store.add(text)
    }

    fun start() {
        clipboardManager.addPrimaryClipChangedListener(listener)
    }

    fun stop() {
        clipboardManager.removePrimaryClipChangedListener(listener)
    }
}

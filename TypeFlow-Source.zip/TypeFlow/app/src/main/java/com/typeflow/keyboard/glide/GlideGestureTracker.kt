package com.typeflow.keyboard.glide

import kotlin.math.hypot

/**
 * Tracks a single in-progress touch gesture and decides, using real movement
 * data (not a coin flip), whether it should be treated as a glide versus an
 * ordinary tap: it must start on a letter key, travel far enough, and cross
 * more than one distinct key.
 */
class GlideGestureTracker(private val minGlideDistancePx: Float, private val minKeysCrossed: Int = 2) {

    private val points = mutableListOf<Pair<Float, Float>>()
    private var startX = 0f
    private var startY = 0f
    private var startedOnLetterKey = false
    private var totalDistance = 0f

    fun start(x: Float, y: Float, onLetterKey: Boolean) {
        points.clear()
        points.add(x to y)
        startX = x
        startY = y
        startedOnLetterKey = onLetterKey
        totalDistance = 0f
    }

    fun addPoint(x: Float, y: Float) {
        val (lastX, lastY) = points.lastOrNull() ?: (x to y)
        totalDistance += hypot((x - lastX).toDouble(), (y - lastY).toDouble()).toFloat()
        points.add(x to y)
    }

    fun isGlide(keys: List<KeyPosition>): Boolean {
        if (!startedOnLetterKey) return false
        if (totalDistance < minGlideDistancePx) return false
        val distinctKeys = GlideTypingEngine.decodeKeySequence(points, keys).toSet()
        return distinctKeys.size >= minKeysCrossed
    }

    fun path(): List<Pair<Float, Float>> = points.toList()

    fun reset() {
        points.clear()
        totalDistance = 0f
        startedOnLetterKey = false
    }
}

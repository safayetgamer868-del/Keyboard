package com.typeflow.keyboard.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.typeflow.keyboard.R
import com.typeflow.keyboard.TypeFlowIME

class MainActivity : AppCompatActivity() {

    private lateinit var statusRow: android.widget.LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = getString(R.string.app_name)
        val (scroll, column) = AppUiKit.screen(this)
        setContentView(scroll)

        val card = AppUiKit.card(this)
        statusRow = AppUiKit.row(this)
        card.addView(statusRow)
        card.addView(AppUiKit.divider(this))
        val enableButtonRow = AppUiKit.row(this)
        enableButtonRow.addView(
            AppUiKit.primaryButton(this, "Enable / choose TypeFlow") { openImeSettings() },
            android.widget.LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        card.addView(enableButtonRow)
        column.addView(card)

        column.addView(AppUiKit.sectionTitle(this, "KEYBOARD"))
        column.addView(sectionCard(
            AppUiKit.clickableRow(this, "Keyboard behavior", "Size, number row, autocorrect, glide, sound") {
                startActivity(Intent(this, KeyboardSettingsActivity::class.java))
            },
            AppUiKit.clickableRow(this, "Themes", "Choose a built-in look") {
                startActivity(Intent(this, ThemeActivity::class.java))
            },
            AppUiKit.clickableRow(this, "Languages", "Enable languages and switch the active one") {
                startActivity(Intent(this, LanguageActivity::class.java))
            },
            AppUiKit.clickableRow(this, "Dictionary", "Manage your personal words") {
                startActivity(Intent(this, DictionaryActivity::class.java))
            }
        ))

        column.addView(AppUiKit.sectionTitle(this, "CONTENT"))
        column.addView(sectionCard(
            AppUiKit.clickableRow(this, "Clipboard", "History, pinned items, screenshots") {
                startActivity(Intent(this, ClipboardActivity::class.java))
            },
            AppUiKit.clickableRow(this, "Writing assistance", "Translate server and GIF search key") {
                startActivity(Intent(this, WritingToolsSettingsActivity::class.java))
            }
        ))

        column.addView(AppUiKit.sectionTitle(this, "ABOUT"))
        column.addView(sectionCard(
            AppUiKit.clickableRow(this, "About TypeFlow", "Version and platform notes") {
                startActivity(Intent(this, AboutActivity::class.java))
            }
        ))
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun sectionCard(vararg rows: android.view.View): android.widget.LinearLayout {
        val card = AppUiKit.card(this)
        rows.forEachIndexed { index, row ->
            card.addView(row)
            if (index != rows.lastIndex) card.addView(AppUiKit.divider(this))
        }
        return card
    }

    private fun refreshStatus() {
        statusRow.removeAllViews()
        val enabled = isImeEnabled()
        val selected = isImeSelected()
        val title = when {
            selected -> "TypeFlow is active"
            enabled -> "TypeFlow is enabled, but not selected"
            else -> "TypeFlow is not enabled yet"
        }
        val subtitle = when {
            selected -> "You're all set."
            enabled -> "Switch to it from your keyboard's input-method picker."
            else -> "Enable it below, then select it as your keyboard."
        }
        val icon = android.widget.ImageView(this).apply {
            setImageResource(if (selected) R.drawable.ic_status_on else R.drawable.ic_status_off)
            val tint = ContextCompat.getColor(this@MainActivity, if (selected) R.color.tf_success else R.color.tf_on_surface_variant)
            setColorFilter(tint)
            layoutParams = android.widget.LinearLayout.LayoutParams(AppUiKit.dp(this@MainActivity, 28), AppUiKit.dp(this@MainActivity, 28))
        }
        statusRow.addView(icon)
        statusRow.addView(
            AppUiKit.rowTitle(this, title, subtitle),
            android.widget.LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also {
                it.marginStart = AppUiKit.dp(this, 12)
            }
        )
    }

    private fun isImeEnabled(): Boolean {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val id = ComponentName(this, TypeFlowIME::class.java).flattenToShortString()
        return imm.enabledInputMethodList.any { it.id == id }
    }

    private fun isImeSelected(): Boolean {
        val current = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        val id = ComponentName(this, TypeFlowIME::class.java).flattenToShortString()
        return current == id
    }

    private fun openImeSettings() {
        startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
    }
}

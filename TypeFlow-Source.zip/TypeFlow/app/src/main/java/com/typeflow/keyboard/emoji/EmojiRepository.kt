package com.typeflow.keyboard.emoji

import android.content.Context

/** Tracks recently-used emoji so the "Recent" category is real, not decorative. */
object EmojiRepository {

    private const val PREFS = "typeflow_emoji"
    private const val KEY_RECENT = "recent_emojis"
    private const val MAX_RECENT = 32

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun recent(context: Context): List<String> {
        val stored = prefs(context).getString(KEY_RECENT, "") ?: ""
        return if (stored.isEmpty()) emptyList() else stored.split("\u0001")
    }

    fun recordUsage(context: Context, emoji: String) {
        val updated = (listOf(emoji) + recent(context).filterNot { it == emoji }).take(MAX_RECENT)
        prefs(context).edit().putString(KEY_RECENT, updated.joinToString("\u0001")).apply()
    }

    fun allCategoriesWithRecent(context: Context): List<EmojiCategory> {
        val recentList = recent(context)
        val recentCategory = EmojiCategory("recent", "Recent", recentList)
        return if (recentList.isEmpty()) EmojiData.categories else listOf(recentCategory) + EmojiData.categories
    }
}

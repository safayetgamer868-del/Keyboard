package com.typeflow.keyboard.core

/** What a key does when pressed. Layouts are just lists of [KeyboardKey]. */
sealed class KeyAction {
    data class Character(val lower: String, val upper: String) : KeyAction()
    object Shift : KeyAction()
    object Backspace : KeyAction()
    object Enter : KeyAction()
    object Space : KeyAction()
    object SwitchToNumbers : KeyAction()
    object SwitchToLetters : KeyAction()
    object SwitchToSymbols : KeyAction()
    object Emoji : KeyAction()
    object Tools : KeyAction()
    object SwitchLanguage : KeyAction()
    data class Symbol(val value: String) : KeyAction()
}

/**
 * A single key, described purely in terms of the fraction of the row's width
 * it occupies. Widths are fixed per layout so that resizing the keyboard
 * (height only) never touches these ratios — see [com.typeflow.keyboard.ui.KeyboardView].
 */
data class KeyboardKey(
    val action: KeyAction,
    val widthWeight: Float = 1f,
    val isSpecial: Boolean = false
)

data class KeyboardRow(val keys: List<KeyboardKey>)

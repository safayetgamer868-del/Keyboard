package com.typeflow.keyboard.clipboard

data class ClipboardItem(
    val id: Long,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isScreenshot: Boolean = false,
    val pinned: Boolean = false,
    val screenshotUri: String? = null
)

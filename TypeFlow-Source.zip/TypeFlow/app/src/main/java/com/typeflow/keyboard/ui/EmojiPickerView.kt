package com.typeflow.keyboard.ui

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.typeflow.keyboard.R
import com.typeflow.keyboard.emoji.EmojiCategory
import com.typeflow.keyboard.emoji.EmojiRepository
import com.typeflow.keyboard.themes.KeyboardTheme

/** Real emoji keyboard: category tabs + scrolling grid + a working Recent category, backed by [EmojiRepository]. */
class EmojiPickerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {

    var theme: KeyboardTheme = com.typeflow.keyboard.themes.ThemeRepository.MIDNIGHT
        set(value) { field = value; setBackgroundColor(value.keyboardBackground); adapter?.theme = value }

    var onEmojiPicked: ((String) -> Unit)? = null
    var onBackRequested: (() -> Unit)? = null
    var onBackspace: (() -> Unit)? = null

    private val tabsScroll = HorizontalScrollView(context)
    private val tabsRow = LinearLayout(context).apply { orientation = HORIZONTAL }
    private val recyclerView = RecyclerView(context)
    private var adapter: EmojiAdapter? = null
    private var categories: List<EmojiCategory> = emptyList()

    init {
        orientation = VERTICAL

        val header = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val backButton = ViewStyling.iconButton(context, R.drawable.ic_arrow_back, theme.keyText, theme.specialKeyBackground, theme, 34)
        backButton.setOnClickListener { onBackRequested?.invoke() }
        val backspaceButton = ViewStyling.iconButton(context, R.drawable.ic_backspace, theme.keyText, theme.specialKeyBackground, theme, 34)
        backspaceButton.setOnClickListener { onBackspace?.invoke() }
        val spacer = android.view.View(context)
        header.addView(backButton, LayoutParams(ViewStyling.dp(context, 34), ViewStyling.dp(context, 34)).also { it.marginStart = ViewStyling.dp(context, 8) })
        header.addView(spacer, LayoutParams(0, 1, 1f))
        header.addView(backspaceButton, LayoutParams(ViewStyling.dp(context, 34), ViewStyling.dp(context, 34)).also { it.marginEnd = ViewStyling.dp(context, 8) })
        addView(header, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewStyling.dp(context, 40)))

        tabsScroll.isHorizontalScrollBarEnabled = false
        tabsScroll.addView(tabsRow, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        addView(tabsScroll, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewStyling.dp(context, 40)))

        recyclerView.layoutManager = GridLayoutManager(context, 8)
        addView(recyclerView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setBackgroundColor(theme.keyboardBackground)
    }

    fun refresh() {
        categories = EmojiRepository.allCategoriesWithRecent(context)
        buildTabs()
        showCategory(0)
    }

    private fun buildTabs() {
        tabsRow.removeAllViews()
        categories.forEachIndexed { index, category ->
            val tab = TextView(context).apply {
                text = category.label.take(1)
                setTextColor(theme.keyTextSecondary)
                textSize = 16f
                gravity = Gravity.CENTER
                setPadding(ViewStyling.dp(context, 12), 0, ViewStyling.dp(context, 12), 0)
                setOnClickListener { showCategory(index) }
            }
            tabsRow.addView(tab, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
    }

    private fun showCategory(index: Int) {
        val category = categories.getOrNull(index) ?: return
        adapter = EmojiAdapter(category.emojis, theme) { emoji ->
            EmojiRepository.recordUsage(context, emoji)
            onEmojiPicked?.invoke(emoji)
        }
        recyclerView.adapter = adapter
    }

    private class EmojiAdapter(
        private val emojis: List<String>,
        var theme: KeyboardTheme,
        private val onPick: (String) -> Unit
    ) : RecyclerView.Adapter<EmojiAdapter.Holder>() {

        class Holder(val textView: TextView) : RecyclerView.ViewHolder(textView)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val tv = TextView(parent.context).apply {
                textSize = 24f
                gravity = Gravity.CENTER
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewStyling.dp(parent.context, 44))
            }
            return Holder(tv)
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val emoji = emojis[position]
            holder.textView.text = emoji
            holder.textView.setOnClickListener { onPick(emoji) }
        }

        override fun getItemCount(): Int = emojis.size
    }
}

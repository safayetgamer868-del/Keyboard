package com.typeflow.keyboard.languages

/** A selectable keyboard language: which row layout it uses and where its dictionary asset lives. */
data class Language(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val layout: LayoutKind,
    val dictionaryAsset: String
)

enum class LayoutKind { QWERTY }

package com.typeflow.keyboard.app

import android.os.Bundle
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.typeflow.keyboard.dictionary.DictionaryProvider
import com.typeflow.keyboard.dictionary.UserDictionaryStore
import com.typeflow.keyboard.languages.LanguageManager
import com.typeflow.keyboard.settings.TypeFlowSettings

class DictionaryActivity : AppCompatActivity() {

    private lateinit var listContainer: LinearLayout
    private lateinit var inputField: EditText
    private val language get() = LanguageManager.active(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Dictionary"
        val (scroll, column) = AppUiKit.screen(this)
        setContentView(scroll)

        column.addView(AppUiKit.sectionTitle(this, "ADD A WORD \u2014 ${language.displayName.uppercase()}"))
        val addCard = AppUiKit.card(this)
        val addRow = AppUiKit.row(this)
        inputField = EditText(this).apply { hint = "New word" }
        addRow.addView(inputField, LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addRow.addView(
            AppUiKit.primaryButton(this, "Add") { addWord() },
            LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT).also {
                it.marginStart = AppUiKit.dp(this, 10)
            }
        )
        addCard.addView(addRow)
        column.addView(addCard)

        column.addView(AppUiKit.sectionTitle(this, "YOUR WORDS"))
        listContainer = AppUiKit.card(this)
        column.addView(listContainer)
        rebuild()
    }

    private fun addWord() {
        val word = inputField.text.toString().trim()
        if (word.isEmpty()) return
        UserDictionaryStore.addWord(this, language.code, word)
        DictionaryProvider.invalidate(language.code)
        inputField.setText("")
        rebuild()
    }

    private fun rebuild() {
        listContainer.removeAllViews()
        val words = UserDictionaryStore.words(this, language.code).sorted()
        if (words.isEmpty()) {
            listContainer.addView(
                TextView(this).apply {
                    text = "No custom words yet."
                    setPadding(AppUiKit.dp(this@DictionaryActivity, 16), AppUiKit.dp(this@DictionaryActivity, 16), AppUiKit.dp(this@DictionaryActivity, 16), AppUiKit.dp(this@DictionaryActivity, 16))
                }
            )
            return
        }
        words.forEachIndexed { index, word ->
            val row = AppUiKit.row(this)
            row.addView(
                AppUiKit.rowTitle(this, word),
                LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            val remove = TextView(this).apply {
                text = "Remove"
                setTextColor(resources.getColor(com.typeflow.keyboard.R.color.tf_danger, theme))
                setOnClickListener {
                    UserDictionaryStore.removeWord(this@DictionaryActivity, language.code, word)
                    DictionaryProvider.invalidate(language.code)
                    rebuild()
                }
            }
            row.addView(remove)
            listContainer.addView(row)
            if (index != words.lastIndex) listContainer.addView(AppUiKit.divider(this))
        }
    }
}

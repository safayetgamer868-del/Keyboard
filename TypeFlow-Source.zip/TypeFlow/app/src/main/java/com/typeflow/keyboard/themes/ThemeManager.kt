package com.typeflow.keyboard.themes

import android.content.Context
import com.typeflow.keyboard.settings.TypeFlowSettings

/**
 * Thin convenience layer over [ThemeRepository] + [TypeFlowSettings] so callers
 * don't need to know both the active theme id and how to resolve it.
 */
class ThemeManager(private val context: Context) {

    fun current(): KeyboardTheme =
        ThemeRepository.findById(context, TypeFlowSettings.getThemeId(context))

    fun setCurrent(themeId: String) {
        TypeFlowSettings.setThemeId(context, themeId)
    }

    fun all(): List<KeyboardTheme> = ThemeRepository.allThemes(context)
}

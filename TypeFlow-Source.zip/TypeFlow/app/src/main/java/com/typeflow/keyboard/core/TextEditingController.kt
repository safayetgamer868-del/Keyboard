package com.typeflow.keyboard.core

import android.view.inputmethod.InputConnection

/**
 * Single choke point through which the IME mutates the editor's text.
 *
 * Centralizing commits/deletes here means Undo/Redo, autocorrect-revert, and
 * future features never fall out of sync with what actually happened to the
 * text — every mutation is recorded in [undoRedo] as it's applied.
 */
class TextEditingController(private val undoRedo: UndoRedoManager) {

    fun commitText(ic: InputConnection?, text: String) {
        if (ic == null || text.isEmpty()) return
        ic.commitText(text, 1)
        undoRedo.record(EditOperation.Insert(text))
    }

    /** Deletes [count] characters before the cursor, recording them for undo. */
    fun deleteBeforeCursor(ic: InputConnection?, count: Int = 1) {
        if (ic == null || count <= 0) return
        val deleted = ic.getTextBeforeCursor(count, 0)?.toString().orEmpty()
        if (deleted.isEmpty()) return
        ic.deleteSurroundingText(deleted.length, 0)
        undoRedo.record(EditOperation.Delete(deleted))
    }

    /** Replaces the [oldLength] characters before the cursor with [newText] (e.g. autocorrect, suggestions, rewrites). */
    fun replaceBeforeCursor(ic: InputConnection?, oldLength: Int, newText: String) {
        if (ic == null) return
        val old = ic.getTextBeforeCursor(oldLength, 0)?.toString().orEmpty()
        ic.beginBatchEdit()
        if (old.isNotEmpty()) ic.deleteSurroundingText(old.length, 0)
        ic.commitText(newText, 1)
        ic.endBatchEdit()
        undoRedo.record(EditOperation.Replace(old, newText))
    }

    /**
     * Replaces a whole captured region (used by translate/grammar/tone "Insert")
     * spanning [beforeLen] chars before the cursor and [afterLen] chars after it.
     */
    fun replaceSurroundingText(ic: InputConnection?, beforeLen: Int, afterLen: Int, oldFullText: String, newText: String) {
        if (ic == null) return
        ic.beginBatchEdit()
        ic.deleteSurroundingText(beforeLen, afterLen)
        ic.commitText(newText, 1)
        ic.endBatchEdit()
        undoRedo.record(EditOperation.Replace(oldFullText, newText))
    }

    fun undo(ic: InputConnection?): Boolean = undoRedo.undo(ic)
    fun redo(ic: InputConnection?): Boolean = undoRedo.redo(ic)
    fun canUndo(): Boolean = undoRedo.canUndo
    fun canRedo(): Boolean = undoRedo.canRedo
    fun resetHistory() = undoRedo.reset()
}

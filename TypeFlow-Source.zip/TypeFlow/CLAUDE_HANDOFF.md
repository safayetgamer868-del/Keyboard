# TypeFlow — Implementation Report

This replaces the previous `CLAUDE_HANDOFF_ORIGINAL.md` / `RECOVERY_NOTES_ORIGINAL.md`
baseline docs (kept for history). This report reflects the current state of
the project after the full implementation pass.

## 1. What was recovered from the APK / baseline

The reconstructed source baseline (from `TypeFlow-Claude-Recovered-Source.zip`)
was a skeleton: `TypeFlowIME` (basic key commit only, no themes/resize/etc.),
a `MainActivity` placeholder with no real UI, and a working `ClipboardStore` /
`ClipboardItem` pair (pin/unpin/edit/delete, pinned-items-stay-editable) plus
a `TextActions` helper for basic InputConnection calls. Everything else
described in the requirements (themes, resize, number row, emoji, one-handed,
floating, undo/redo, translation, grammar, tone, autocorrect, glide typing,
suggestions, voice typing, dictionary, languages, GIFs, a real settings app)
did not exist in the recovered baseline and was built from scratch.

The clipboard pin/edit/delete logic and its "pinned items must remain
editable" contract were preserved and extended (screenshot support, a
clipboard monitor, configurable max size) rather than rewritten.

## 2. Architecture

```
com.typeflow.keyboard/
  TypeFlowIME.kt          — InputMethodService; wires everything together
  app/                    — MainActivity + 6 settings screens (real, functional UI)
  ime/PermissionActivity.kt — transparent runtime-permission bridge for the IME
  core/                   — key model, layouts, undo/redo, hold-repeat, text editing
  ui/                     — KeyboardView (canvas-drawn keys) + all panels (suggestions,
                             emoji, clipboard, tools grid, writing tools, GIF, floating/one-handed)
  themes/                 — KeyboardTheme model + 6 built-in themes + custom theme persistence
  settings/               — TypeFlowSettings (single source of truth, SharedPreferences)
  clipboard/              — store, system-clipboard monitor, MediaStore screenshot watcher
  dictionary/             — built-in wordlists (assets) + user dictionary
  suggestions/            — SuggestionProvider interface, local dictionary provider, autocorrect
  glide/                  — gesture tracking + path-to-word decoding/scoring
  voice/                  — Android SpeechRecognizer wrapper
  writing/                — Translation / Grammar / Tone: interface + real local/HTTP implementation each
  gif/                    — GifProvider interface + real Tenor v2 client
  languages/              — language registry + active/enabled state
```

Every replaceable backend (translation, grammar, tone, GIFs, suggestions) is
behind an interface with exactly one local or HTTP implementation shipped, so
a better engine can be swapped in later without touching the keyboard or UI.

## 3. What's implemented and real (not mocked)

- **Themes**: 6 built-in themes (Midnight, Daylight, Ocean, Sunset, Glass,
  High Contrast) covering background/key/text/accent/border/radius/opacity;
  `ThemeRepository` also persists custom themes as JSON, though the UI to
  *create* one isn't exposed yet (see Limitations).
- **Resize**: strictly height-only. Key width/height and all row proportions
  are fixed constants (`KeyboardMetrics`); the height slider only changes the
  padding above/below/between rows. No key is ever stretched or rescaled by it.
- **Number row**: persisted toggle, added/removed as a real extra row.
- **Emoji keyboard**: 7 categories + a real "Recent" category backed by usage
  tracking, RecyclerView grid, vector UI icons (no Unicode/emoji as controls).
- **One-handed mode**: left/right/off, compresses width while keeping the
  same per-key ratios; persisted; flip/exit controls shown while active.
- **Floating keyboard**: real IME window-attribute manipulation (position,
  size, drag handle) via `FloatingKeyboardController` — not just a visual
  style. Documented platform-limitation caveat below.
- **Undo/redo**: a real operation-log (`UndoRedoManager`) recording every
  commit/delete/replace the keyboard performs (typing, autocorrect,
  suggestions, writing-tool inserts) and reverting them through
  `InputConnection`.
- **Translation**: `HttpTranslationProvider` calls a real, user-configured
  LibreTranslate-compatible endpoint. No key/endpoint is bundled — translation
  is inert until the user sets a server in Settings, and errors are shown as
  errors, never faked.
- **Grammar check**: `RuleBasedGrammarProvider` — real regex-based detection
  (double spaces, repeated words, lowercase "I", sentence capitalization)
  with corrections applied back into the text.
- **Tone rewrite**: `TemplateToneProvider` — genuine per-tone text
  transformations (contraction expansion/contraction, filler-word removal,
  wordy-phrase shortening, capitalization/punctuation normalization) for
  Professional/Friendly/Casual/Concise. Explicitly local/rule-based, not a
  static canned string.
- **Clipboard**: history + pin/unpin/edit/delete lives in the app
  (`ClipboardActivity`, swipe-to-delete via `ItemTouchHelper`, pinned items
  protected from swipe and still editable); a compact recent-items panel in
  the keyboard for quick insert. No clipboard search, per spec.
- **Screenshots**: `ScreenshotWatcher` observes MediaStore for new screenshots
  and copies them into app-private storage (not fake text entries), gated
  behind an explicit settings toggle + runtime permission request.
- **Autocorrect**: dictionary + bounded-Levenshtein correction, conservative
  by default (won't touch capitalized/short/digit-containing words), with an
  "aggressive" setting for a wider edit-distance search.
- **Glide typing**: real two-stage algorithm — path reduced to a key
  sequence, then dictionary words scored as ordered subsequences of that
  sequence (coverage + end-letter bonus), not a fake/random word picker. If
  nothing scores well, nothing is inserted (no invented word).
- **Suggestions**: prefix matching against a frequency-ranked local
  dictionary (671 English / 100–160 word lists for es/fr/de/pt/bn) plus a
  small, honestly-scoped set of common next-word pairs. Tapping a suggestion
  replaces the current word.
- **Voice typing**: real `SpeechRecognizer` integration with permission
  handling (keyboard can't request permissions itself, so it launches a
  transparent `PermissionActivity`) and explicit error states when
  unavailable.
- **Dictionary**: per-language user word add/remove, feeding suggestions,
  autocorrect and glide scoring immediately (cache invalidation on edit).
- **Languages**: 6 languages registered (en/es/fr/de/pt/bn-latin), each with
  its own dictionary asset; enable/disable and active-language switching
  persist; the language ("globe") key cycles the active one.
- **GIFs**: `TenorGifProvider` — real Tenor v2 search calls using a
  user-supplied API key (Settings > Writing assistance), with a lightweight
  built-in async thumbnail loader (no bundled image library). No API key
  shipped, no fabricated results.
- **Hold-to-delete**: tap = one char immediately; hold triggers `HoldRepeater`
  (delay, then accelerating repeat) that stops the instant the finger lifts.
- **Settings app**: `MainActivity` (status + IME-enable shortcut) plus six
  real settings screens (Keyboard behavior, Themes, Languages, Dictionary,
  Clipboard, Writing assistance) and an About screen — no placeholder
  screens or dead switches.
- **Icons**: every UI control (backspace, shift, enter, globe, emoji, tools,
  undo/redo, translate, grammar, tone, mic, GIF, pin, edit, delete, etc.) is
  a real vector drawable. Emoji characters only ever appear inside the emoji
  picker itself.

## 4. Known limitations (stated honestly, not hidden)

- **Not built/compiled.** This sandbox has no Android SDK, Gradle, or
  network access (`dl.google.com` / Maven / Gradle services all returned
  403/blocked), so the project could not be assembled or run here. Open it in
  Android Studio (or run `./gradlew assembleDebug` with a normal internet
  connection) to build and fix any environment-specific issues a real
  compiler surfaces — the code was written and manually double-checked
  (package/import consistency, resource references, brace/paren balance) but
  has not been verified by an actual Kotlin/AGP build.
- **Floating mode** manipulates the IME's own window attributes, which is the
  real mechanism available to an `InputMethodService` — but Android versions,
  OEM skins, and individual apps/games can restrict or override IME window
  behavior. This is a platform limitation no app can fully bypass; TypeFlow
  degrades to normal docked mode rather than pretending it always works.
- **Custom theme creation UI** isn't built yet — `ThemeRepository` already
  supports saving/loading custom themes, but `ThemeActivity` currently only
  lists and applies the 6 built-ins.
- **Translation/GIFs require the user's own server/API key** by design (no
  bundled credentials) — they're inert until configured, which is the
  correct behavior per the requirements, but worth knowing before testing.
- **Grammar/tone/translate tools operate on a captured text window** (up to
  2000 characters before/after the cursor) rather than a fully editor-aware
  document model, since that's what `InputConnection` exposes. Insert
  replaces that whole captured window.
- **Language layouts**: all 6 languages currently share the QWERTY physical
  layout (only the dictionary changes per language) — no AZERTY/QWERTZ/etc.
  yet, though `LayoutKind` exists for adding one.

## 5. Build

Not run in this environment (no SDK/Gradle/network access). The wrapper
*properties* file is included (`gradle/wrapper/gradle-wrapper.properties`,
pinned to Gradle 8.5.2-compatible Gradle 8.7), but the wrapper *jar* and
`gradlew`/`gradlew.bat` scripts are not — generating the jar requires running
Gradle once, which needs network access this environment doesn't have.
Opening the project in Android Studio will offer to regenerate the wrapper
automatically on sync; alternatively run `gradle wrapper` once yourself with
a normal Gradle install, or use your own `gradlew`.

Expected command once the wrapper (or a local Gradle) is available:

```
./gradlew assembleDebug
```

APK output path (once built): `app/build/outputs/apk/debug/app-debug.apk`

# TypeFlow Theme Mod — 2.1

Changes in this mod:

- Added a SwiftKey-inspired built-in theme gallery with larger visual previews and a two-column layout.
- Added built-in themes: System Dynamic, Midnight, Daylight, Ocean, Sunset, Lavender, Forest, Rose, Carbon, Arctic, Neon, Glass, and High Contrast.
- Added `System Dynamic` keyboard theme. On Android 12+, it reads the device Monet/system palette and follows light/dark mode.
- Changed the default TypeFlow keyboard theme from Midnight to System Dynamic.
- Added Android 12+ dynamic system colors for the TypeFlow app UI (background, surfaces, text, accent and dividers), with existing static fallbacks on older Android versions.
- Theme selection uses a real vector check icon instead of a Unicode decoration.

Build note:
This is the modified source project. The current environment does not contain a complete Android SDK/Gradle build toolchain, so an APK was not generated here.

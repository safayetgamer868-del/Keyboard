# TypeFlow Recovery Package

This is a reconstruction package prepared from the uploaded `TypeFlow.apk` plus known TypeFlow source context from the prior project state.

## Important
This is **NOT the original source project**. The APK is a compiled artifact. Original Kotlin formatting, comments, Gradle files, project history, and any source not recoverable from compiled resources are unavailable.

## Included
- `TypeFlow-original.apk` — untouched uploaded APK for reference/decompilation.
- Reconstructed Gradle project under `app/`.
- Reconstructed baseline classes known from the previous TypeFlow source state.
- `RECOVERY_NOTES.md` and `CLAUDE_HANDOFF.md`.

## Known APK baseline
Package: `com.typeflow.keyboard`
The uploaded APK contains 5 DEX files and bundled Kotlin/AndroidX components. The original APK exposed a TypeFlow input method service; the previous known source state contained `KeyboardEngine`, `KeyboardLayout`, `TypeFlowPrefs`, `TextActions`, `ClipboardStore`, `ClipboardItem`, and `TypeFlowIME`.

## Do not treat as finished
The reconstructed `KeyboardEngine` is only a baseline. It intentionally does not claim to implement the full production requirements. Claude should inspect the APK and this project, then rebuild the architecture properly.

# Claude Handoff — TypeFlow

You are receiving a reconstructed TypeFlow source baseline because the original Gradle source was lost and only the APK survived.

1. Inspect the entire project and `TypeFlow-original.apk` first.
2. Treat the APK as a behavioral/reference artifact, not as original source.
3. Preserve recoverable existing behavior where appropriate.
4. Replace weak/reconstructed pieces with clean production architecture.
5. Build and fix all errors instead of merely describing fixes.

## Required product direction
- Production-quality Android IME, not a demo.
- SwiftKey-level polished theme/customization system.
- Keyboard resize changes ONLY keyboard height; never key width/size/spacing.
- Number-row toggle.
- Full emoji keyboard.
- One-handed mode.
- Gboard-style floating mode where Android IME/platform APIs permit it.
- Undo/redo.
- Translation, grammar check, tone rewrite through real/provider-based integrations; never fake functionality.
- App-side clipboard history, not a large keyboard clipboard panel; no clipboard search.
- Persist copied text and recent screenshots; use real URI/file storage for screenshots.
- Tap clipboard item to use/paste; long press for pin/unpin, edit, delete; swipe right deletes only unpinned items; pinned items remain editable.
- Auto Correct.
- Glide Typing.
- Suggestions/prediction.
- Voice Typing.
- Dictionary.
- Languages.
- GIFs.
- Hold-delete with initial delay, repeat, acceleration, immediate stop on release.
- Fast typing must commit immediately without artificial debounce or dropped rapid input.
- Proper vector icons; do not use Unicode decorative symbols as UI icons. Emoji characters are allowed inside the emoji keyboard.
- MainActivity/settings app-side UI.

## Critical implementation rule
Do not tell the user to manually create dozens of files or paste code. Work directly in the supplied project, then build/test/fix.

## Important known weakness
The baseline `ClipboardStore` currently represents screenshot URI data but does not implement actual screenshot capture/persistence. Implement this properly.
